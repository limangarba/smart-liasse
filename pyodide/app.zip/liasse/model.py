"""Chargement du modele compile (modele.json) et corrections apportees aux formules du modele d'origine."""
import json
import os
import re
import datetime
import copy

from .formula import parse_formula, CELL_RE, col2num, num2col

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "modele.json")

BAL = "Balance std"


def _deser(v):
    if isinstance(v, dict) and "d" in v:
        return datetime.date.fromisoformat(v["d"])
    return v


def shift_ast(node, colmap, sheet_filter):
    """Decale les references de colonnes (ex. F->D, G->E) pour les feuilles donnees."""
    k = node[0]
    if k == "ref":
        sh, addr = node[1], node[2]
        if sh in sheet_filter:
            m = CELL_RE.fullmatch(addr)
            col = m.group(1)
            new = colmap[sh].get(col, col)
            return ("ref", sh, new + m.group(2))
        return node
    if k == "rng":
        _, sh, r1, c1, r2, c2 = node
        if sh in sheet_filter:
            cm = colmap[sh]
            c1n = col2num(cm.get(num2col(c1), num2col(c1)))
            c2n = col2num(cm.get(num2col(c2), num2col(c2)))
            return ("rng", sh, r1, c1n, r2, c2n)
        return node
    if k == "bin":
        return ("bin", node[1], shift_ast(node[2], colmap, sheet_filter), shift_ast(node[3], colmap, sheet_filter))
    if k == "neg":
        return ("neg", shift_ast(node[1], colmap, sheet_filter))
    if k == "fn":
        return ("fn", node[1], [shift_ast(a, colmap, sheet_filter) for a in node[2]])
    return node


def uses_sheet(node, sheets):
    k = node[0]
    if k in ("ref", "rng"):
        return node[1] in sheets
    if k == "bin":
        return uses_sheet(node[2], sheets) or uses_sheet(node[3], sheets)
    if k == "neg":
        return uses_sheet(node[1], sheets)
    if k == "fn":
        return any(uses_sheet(a, sheets) for a in node[2])
    return False


class Model:
    """Modele de liasse : constantes, formules (arbres), styles, geometrie."""

    def __init__(self, path=DATA):
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
        self.styles = raw["styles"]
        self.sheets = raw["sheets"]
        self.consts = {}
        self.formulas = {}
        self.texts_with_equal = {}
        for sh, s in self.sheets.items():
            for addr, c in s["cells"].items():
                if "f" in c:
                    try:
                        self.formulas[(sh, addr)] = parse_formula(c["f"], sh)
                    except Exception:
                        # texte commencant par "=" : on l'affiche tel quel (sans le signe =)
                        txt = c["f"].lstrip("=").strip()
                        self.consts[(sh, addr)] = txt
                elif "v" in c:
                    self.consts[(sh, addr)] = _deser(c["v"])
        self.leaf_rows = {}      # numero de compte -> [lignes]
        self.leaf_info = []      # (ligne, compte, libelle, code)
        self._prepare_balance()
        self._apply_corrections()

    # ------------------------------------------------------------------ balance
    def _prepare_balance(self):
        cells = self.sheets[BAL]["cells"]
        for r in range(5, 764):
            a = self.consts.get((BAL, f"A{r}"))
            fF = (BAL, f"F{r}") in self.formulas and not self._is_link(BAL, f"F{r}")
            fG = (BAL, f"G{r}") in self.formulas and not self._is_link(BAL, f"G{r}")
            if a is not None and str(a).strip() and not (fF or fG):
                acct = str(a).strip()
                if isinstance(a, float) and a.is_integer():
                    acct = str(int(a))
                lib = self.consts.get((BAL, f"B{r}"), "")
                code = self.consts.get((BAL, f"C{r}"), "")
                self.leaf_rows.setdefault(acct, []).append(r)
                self.leaf_info.append((r, acct, str(lib or "").strip(), str(code or "").strip()))
                # les cellules D/E/F/G deviennent des entrees (valeurs fournies par la balance importee)
                for col in "DEFG":
                    self.formulas.pop((BAL, f"{col}{r}"), None)
                    self.consts.pop((BAL, f"{col}{r}"), None)
            else:
                # lignes de sous-totaux : les colonnes N-1 (D/E) sont des constantes saisies dans le modele
                # d'origine ; on les remplace par la meme formule que N decalee (F->D, G->E)
                for src, dst in (("F", "D"), ("G", "E")):
                    key = (BAL, f"{src}{r}")
                    if key in self.formulas and not self._is_link(BAL, f"{src}{r}"):
                        self.formulas[(BAL, f"{dst}{r}")] = shift_ast(self.formulas[key], {BAL: {"F": "D", "G": "E"}}, {BAL})
                        self.consts.pop((BAL, f"{dst}{r}"), None)
                    elif key not in self.formulas:
                        # sous-total sans formule en N : on vide la constante N-1 eventuelle
                        pass
        # colonne H de la balance std : colonne de travail, on la neutralise
        for key in [k for k in list(self.formulas) if k[0] == BAL and k[1].startswith("H")]:
            self.formulas.pop(key, None)

    def _is_link(self, sh, addr):
        """Formule qui pointe vers une balance client (BG25...) -> cellule d'entree."""
        f = self.sheets[sh]["cells"].get(addr, {}).get("f", "")
        return "BG25" in f or "BG24" in f or "BG23" in f

    # ------------------------------------------------------------- corrections
    def set_formula(self, sheet, addr, text):
        self.formulas[(sheet, addr)] = parse_formula(text, sheet)
        self.consts.pop((sheet, addr), None)

    def _apply_corrections(self):
        from .corrections import apply
        apply(self)

    def shift_n1(self, sheet, src_col, dst_col, rows, extra_map=None):
        """Colonne N-1 = formule de la colonne N appliquee a la balance N-1."""
        colmap = {BAL: {"F": "D", "G": "E"}, "RESULTAT": {"H": "I"}}
        if extra_map:
            colmap.update(extra_map)
        sheets = set(colmap)
        for r in rows:
            key = (sheet, f"{src_col}{r}")
            if key in self.formulas and uses_sheet(self.formulas[key], sheets):
                self.formulas[(sheet, f"{dst_col}{r}")] = shift_ast(self.formulas[key], colmap, sheets)
                self.consts.pop((sheet, f"{dst_col}{r}"), None)


_MODEL = None


def get_model():
    global _MODEL
    if _MODEL is None:
        _MODEL = Model()
    return _MODEL
