"""Rendu PDF A4 (portrait / paysage) des grilles de pages avec ReportLab."""
import os
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "fonts")

_REG = False


def register_fonts():
    global _REG
    if _REG:
        return
    for name, f in (("LS", "LiberationSans-Regular.ttf"), ("LS-B", "LiberationSans-Bold.ttf"),
                    ("LS-I", "LiberationSans-Italic.ttf"), ("LS-BI", "LiberationSans-BoldItalic.ttf")):
        pdfmetrics.registerFont(TTFont(name, os.path.join(FONTS, f)))
    _REG = True


def font_name(st):
    b, i = bool(st.get("b")), bool(st.get("i"))
    return "LS-BI" if b and i else "LS-B" if b else "LS-I" if i else "LS"


BORDER_W = {"hair": 0.3, "thin": 0.55, "dotted": 0.5, "dashDot": 0.55, "dashDotDot": 0.55, "dashed": 0.55,
            "mediumDashed": 1.0, "mediumDashDot": 1.0, "mediumDashDotDot": 1.0, "slantDashDot": 1.0,
            "medium": 1.1, "thick": 1.7, "double": 0.5}
BORDER_RANK = {None: 0, "hair": 1, "dotted": 2, "dashDotDot": 3, "dashDot": 4, "dashed": 5, "thin": 6,
               "mediumDashDotDot": 7, "slantDashDot": 8, "mediumDashDot": 9, "mediumDashed": 10,
               "medium": 11, "double": 12, "thick": 13}

MARGIN = 26  # environ 9 mm


def page_size(orient):
    return landscape(A4) if orient == "L" else A4


def compute_edges(grid):
    """Retourne les segments de bordure (h: (i, j) / v: (i, j)) avec le style le plus fort."""
    merge_idx = grid.merge_at()
    H, V = {}, {}

    def put(d, k, style):
        if style and BORDER_RANK.get(style, 0) > BORDER_RANK.get(d.get(k), 0):
            d[k] = style

    for (i, j), c in grid.cells.items():
        st = c.st
        m = merge_idx.get((i, j))
        if m and (i, j) == (m[0], m[1]):
            # cellule d'ancrage d'une fusion : ses bordures valent pour le contour de la fusion
            i1, j1, i2, j2 = m
            for jj in range(j1, j2 + 1):
                put(H, (i1, jj), st.get("bt"))
                put(H, (i2 + 1, jj), st.get("bb") or _edge_style(grid, i2, jj, "bb"))
            for ii in range(i1, i2 + 1):
                put(V, (ii, j1), st.get("bl"))
                put(V, (ii, j2 + 1), st.get("br") or _edge_style(grid, ii, j2, "br"))
            continue
        if m:
            i1, j1, i2, j2 = m
            if i == i1:
                put(H, (i, j), st.get("bt"))
            if i == i2:
                put(H, (i + 1, j), st.get("bb"))
            if j == j1:
                put(V, (i, j), st.get("bl"))
            if j == j2:
                put(V, (i, j + 1), st.get("br"))
            continue
        put(H, (i, j), st.get("bt"))
        put(H, (i + 1, j), st.get("bb"))
        put(V, (i, j), st.get("bl"))
        put(V, (i, j + 1), st.get("br"))
    return H, V


def _edge_style(grid, i, j, key):
    c = grid.cells.get((i, j))
    return c.st.get(key) if c else None


def wrap_lines(text, font, size, width):
    lines = []
    for para in str(text).split("\n"):
        words = para.split(" ")
        cur = ""
        for w in words:
            t = (cur + " " + w) if cur else w
            if pdfmetrics.stringWidth(t, font, size) <= width or not cur:
                if not cur and pdfmetrics.stringWidth(w, font, size) > width:
                    # mot trop long : coupe caractere par caractere
                    piece = ""
                    for ch in w:
                        if pdfmetrics.stringWidth(piece + ch, font, size) > width and piece:
                            lines.append(piece)
                            piece = ch
                        else:
                            piece += ch
                    cur = piece
                else:
                    cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


class PdfWriter:
    def __init__(self, path_or_buf, title="Liasse", author=""):
        register_fonts()
        self.c = rl_canvas.Canvas(path_or_buf, pagesize=A4)
        self.c.setTitle(title)
        self.c.setAuthor(author)
        self.c.setCreator("Smart Liasse SYSCOHADA")

    def add_grid(self, grid):
        c = self.c
        pw, ph = page_size(grid.orient)
        c.setPageSize((pw, ph))
        tw, th = grid.size()
        if tw <= 0 or th <= 0:
            c.showPage()
            return
        aw, ah = pw - 2 * MARGIN, ph - 2 * MARGIN
        s = min(aw / tw, ah / th, 1.0)
        x0 = MARGIN + (aw - tw * s) / 2
        y0 = ph - MARGIN
        xs = [x0]
        for w in grid.cols:
            xs.append(xs[-1] + w * s)
        ys = [y0]
        for h in grid.rows:
            ys.append(ys[-1] - h * s)
        merge_idx = grid.merge_at()

        # 1. fonds
        for (i, j), cell in grid.cells.items():
            bg = cell.st.get("bg")
            m = merge_idx.get((i, j))
            if m and (i, j) != (m[0], m[1]):
                continue
            if bg:
                i2, j2 = (m[2], m[3]) if m else (i, j)
                c.setFillColor(_hex(bg))
                c.rect(xs[j], ys[i2 + 1], xs[j2 + 1] - xs[j], ys[i] - ys[i2 + 1], stroke=0, fill=1)

        # 2. textes
        self._spill = set()
        occupied = {pos for pos, cell in grid.cells.items() if cell.text}
        for pos in merge_idx:
            occupied.add(pos)
        for (i, j), cell in grid.cells.items():
            if not cell.text:
                continue
            m = merge_idx.get((i, j))
            if m and (i, j) != (m[0], m[1]):
                continue
            i2, j2 = (m[2], m[3]) if m else (i, j)
            self._draw_text(cell, i, j, i2, j2, xs, ys, s, grid, occupied, bool(m))

        # 3. bordures
        H, V = compute_edges(grid)
        c.setStrokeColorRGB(0, 0, 0)
        for (i, j), style in H.items():
            if i >= len(ys) or j + 1 >= len(xs):
                continue
            self._line(xs[j], ys[i], xs[j + 1], ys[i], style, s, horizontal=True)
        for (i, j), style in V.items():
            if i + 1 >= len(ys) or j >= len(xs) or (i, j) in self._spill:
                continue
            self._line(xs[j], ys[i], xs[j], ys[i + 1], style, s, horizontal=False)

        # 4. images et cadres de texte
        for (x, y, w, h, path) in grid.images:
            try:
                img = ImageReader(_gray_image(path))
                c.drawImage(img, x0 + x * s, y0 - (y + h) * s, w * s, h * s, preserveAspectRatio=True, mask="auto")
            except Exception:
                pass
        for tb in grid.textboxes:
            self._textbox(tb, x0, y0, s)
        c.showPage()

    # ------------------------------------------------------------------
    def _line(self, xa, ya, xb, yb, style, s, horizontal):
        c = self.c
        w = BORDER_W.get(style, 0.5) * max(s, 0.6)
        c.setLineWidth(w)
        if style == "dotted":
            c.setDash([0.6, 1.4])
        elif style in ("dashed", "mediumDashed"):
            c.setDash([3, 2])
        elif style in ("dashDot", "mediumDashDot", "slantDashDot"):
            c.setDash([3, 1.5, 0.8, 1.5])
        elif style in ("dashDotDot", "mediumDashDotDot"):
            c.setDash([3, 1.2, 0.8, 1.2, 0.8, 1.2])
        else:
            c.setDash([])
        if style == "double":
            d = 1.1 * max(s, 0.6)
            if horizontal:
                c.line(xa, ya + d / 2, xb, yb + d / 2)
                c.line(xa, ya - d / 2, xb, yb - d / 2)
            else:
                c.line(xa - d / 2, ya, xb - d / 2, yb)
                c.line(xa + d / 2, ya, xb + d / 2, yb)
        else:
            c.line(xa, ya, xb, yb)
        c.setDash([])

    def _draw_text(self, cell, i, j, i2, j2, xs, ys, s, grid, occupied, merged):
        c = self.c
        st = cell.st
        font = font_name(st)
        size = st["size"] * s
        text = cell.text
        ha = st.get("ha") or ("right" if cell.num else "left")
        if ha == "general":
            ha = "right" if cell.num else "left"
        if ha in ("centerContinuous", "distributed"):
            ha = "center"
        if ha in ("fill", "justify"):
            ha = "left"
        va = st.get("va") or "bottom"
        xl, xr = xs[j], xs[j2 + 1]
        yt, yb = ys[i], ys[i2 + 1]
        pad = 1.8 * s + (st.get("ind") or 0) * 6 * s
        c.setFillColorRGB(0, 0, 0)
        rot = st.get("rot") or 0
        if rot in (90, 180) or rot == 255:
            # texte vertical
            c.saveState()
            cx, cy = (xl + xr) / 2, (yt + yb) / 2
            c.translate(cx, cy)
            c.rotate(90)
            w_avail = (yt - yb) - 2 * pad
            fs = size
            while fs > 3 and pdfmetrics.stringWidth(text, font, fs) > w_avail:
                fs -= 0.3
            c.setFont(font, fs)
            c.drawCentredString(0, -fs * 0.35, text.replace("\n", " "))
            c.restoreState()
            return
        width = xr - xl - 2 * pad
        if st.get("wrap") or ("\n" in text and not cell.num):
            fs = size
            while True:
                lines = wrap_lines(text, font, fs, max(width, 5))
                lh = fs * 1.16
                if len(lines) * lh <= (yt - yb) - 1 or fs <= 4:
                    break
                fs -= 0.25
            lh = fs * 1.16
            total = len(lines) * lh
            if va == "top":
                y = yt - fs * 0.95 - 0.8 * s
            elif va in ("center", "distributed", "justify"):
                y = (yt + yb) / 2 + total / 2 - fs * 0.95
            else:
                y = yb + total - fs * 0.95 + 0.5 * s
            c.setFont(font, fs)
            for ln in lines:
                self._put(ln, font, fs, ha, xl + pad, xr - pad, y, st)
                y -= lh
            return
        text = text.replace("\n", " ")
        tw = pdfmetrics.stringWidth(text, font, size)
        # debordement sur les cellules vides voisines (comportement Excel)
        if tw > width and not cell.num and not merged:
            ncols = len(grid.cols)
            if ha == "left":
                k = j2 + 1
                while k < ncols and (i, k) not in occupied and tw > (xs[k] - xl - 2 * pad):
                    xr = xs[k + 1]
                    occupied.add((i, k))
                    k += 1
            elif ha == "right":
                k = j - 1
                while k >= 0 and (i, k) not in occupied and tw > (xr - xs[k + 1] - 2 * pad):
                    xl = xs[k]
                    occupied.add((i, k))
                    k -= 1
            elif ha == "center":
                k1, k2 = j - 1, j2 + 1
                while tw > (xr - xl - 2 * pad):
                    grew = False
                    if k1 >= 0 and (i, k1) not in occupied:
                        xl = xs[k1]
                        occupied.add((i, k1))
                        k1 -= 1
                        grew = True
                    if k2 < ncols and (i, k2) not in occupied:
                        xr = xs[k2 + 1]
                        occupied.add((i, k2))
                        k2 += 1
                        grew = True
                    if not grew:
                        break
            width = xr - xl - 2 * pad
            # les traits verticaux traverses par le texte debordant ne sont pas dessines (comme a l'ecran)
            if ha == "left":
                t0, t1 = xl + pad, xl + pad + min(tw, width)
            elif ha == "right":
                t0, t1 = xr - pad - min(tw, width), xr - pad
            else:
                t0, t1 = (xl + xr) / 2 - min(tw, width) / 2, (xl + xr) / 2 + min(tw, width) / 2
            for b in range(1, len(xs) - 1):
                if t0 + 1 < xs[b] < t1 - 1:
                    self._spill.add((i, b))
        fs = size
        if tw > width:
            while fs > max(3.5, size * 0.55) and pdfmetrics.stringWidth(text, font, fs) > width:
                fs -= 0.2
            if fs < size * 0.8:
                self.__dict__.setdefault("shrunk", []).append((getattr(self, "npage", 0), text, round(fs / size, 2), st.get("_addr")))
        if va == "top":
            y = yt - fs * 0.95 - 0.8 * s
        elif va in ("center", "distributed", "justify"):
            y = (yt + yb) / 2 - fs * 0.35
        else:
            y = yb + 2.0 * s + fs * 0.12
        c.setFont(font, fs)
        c.saveState()
        p = c.beginPath()
        p.rect(xl, yb - 1, xr - xl, yt - yb + 2 + fs)
        c.clipPath(p, stroke=0, fill=0)
        self._put(text, font, fs, ha, xl + pad, xr - pad, y, st)
        c.restoreState()

    def _put(self, text, font, fs, ha, xl, xr, y, st):
        c = self.c
        c.setFont(font, fs)
        w = pdfmetrics.stringWidth(text, font, fs)
        if ha == "center":
            x = (xl + xr) / 2 - w / 2
        elif ha == "right":
            x = xr - w
        else:
            x = xl
        c.drawString(x, y, text)
        if st.get("u"):
            c.setLineWidth(0.4)
            c.line(x, y - 1.2, x + w, y - 1.2)

    def _textbox(self, tb, x0, y0, s):
        c = self.c
        x = x0 + tb["x"] * s
        w = tb["w"] * s
        ytop = y0 - tb["y"] * s
        h = tb["h"] * s
        pad = tb.get("pad", 4) * s
        if tb.get("border"):
            c.setLineWidth(tb.get("border") * s)
            if tb.get("bg"):
                c.setFillColor(_hex(tb["bg"]))
                c.rect(x, ytop - h, w, h, stroke=1, fill=1)
            else:
                c.rect(x, ytop - h, w, h, stroke=1, fill=0)
        elif tb.get("bg"):
            c.setFillColor(_hex(tb["bg"]))
            c.rect(x, ytop - h, w, h, stroke=0, fill=1)
        c.setFillColorRGB(0, 0, 0)
        fs = tb.get("size", 9) * s
        paras = tb["paras"]
        # reduction automatique si le texte deborde
        while True:
            total = 0
            for p in paras:
                font = font_name({"b": p.get("b", tb.get("bold")), "i": p.get("i")})
                lines = wrap_lines(p["t"], font, fs * p.get("k", 1), w - 2 * pad)
                total += len(lines) * fs * p.get("k", 1) * 1.22 + p.get("gap", tb.get("gap", 3)) * s
            if total <= h - 2 * pad or fs <= 4:
                break
            fs -= 0.2
        y = ytop - pad
        if tb.get("valign") == "center":
            y = ytop - (h - total) / 2
        for p in paras:
            k = p.get("k", 1)
            font = font_name({"b": p.get("b", tb.get("bold")), "i": p.get("i")})
            f2 = fs * k
            lines = wrap_lines(p["t"], font, f2, w - 2 * pad)
            al = p.get("align", tb.get("align", "left"))
            for ln in lines:
                y -= f2 * 1.22
                if al == "justify" and ln is not lines[-1] and " " in ln:
                    self._justify(ln, font, f2, x + pad, x + w - pad, y + f2 * 0.25)
                else:
                    self._put(ln, font, f2, "center" if al == "center" else "right" if al == "right" else "left",
                              x + pad, x + w - pad, y + f2 * 0.25, {})
            y -= p.get("gap", tb.get("gap", 3)) * s
        if tb.get("rotate"):
            pass

    def _justify(self, line, font, fs, xl, xr, y):
        c = self.c
        words = line.split(" ")
        wsum = sum(pdfmetrics.stringWidth(w, font, fs) for w in words)
        gap = (xr - xl - wsum) / max(len(words) - 1, 1)
        if gap > fs * 1.2:
            self._put(line, font, fs, "left", xl, xr, y, {})
            return
        x = xl
        c.setFont(font, fs)
        for w in words:
            c.drawString(x, y, w)
            x += pdfmetrics.stringWidth(w, font, fs) + gap

    def save(self):
        self.c.save()


def _hex(h):
    from reportlab.lib.colors import HexColor
    return HexColor("#" + h)


_GRAY = {}


def _gray_image(path):
    """Images en niveaux de gris (impression noir et blanc exigee par la DGI)."""
    import io
    if path in _GRAY:
        return io.BytesIO(_GRAY[path])
    try:
        from PIL import Image
        import io
        im = Image.open(path).convert("RGBA")
        bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
        bg.alpha_composite(im)
        g = bg.convert("L")
        buf = io.BytesIO()
        g.save(buf, format="PNG")
        _GRAY[path] = buf.getvalue()
        return io.BytesIO(_GRAY[path])
    except Exception:
        return path
