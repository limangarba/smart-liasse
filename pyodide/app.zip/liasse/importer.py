"""Import de balances et de tableaux d'immobilisations depuis Excel (.xlsx, .xls) ou CSV."""
import csv
import io
import re
import datetime


def _num(v):
    from .nombres import num
    return num(v)


def read_table(filename, data):
    """Retourne une liste de lignes (listes de valeurs) de la premiere feuille non vide."""
    name = (filename or "").lower()
    if name.endswith(".csv") or name.endswith(".txt"):
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                text = data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        sample = text[:5000]
        delim = max([";", ",", "\t", "|"], key=lambda d: sample.count(d))
        return [row for row in csv.reader(io.StringIO(text), delimiter=delim)]
    if name.endswith(".xls"):
        try:
            import xlrd
        except ImportError:
            raise ValueError("Le format .xls nécessite le module xlrd. Enregistrez le fichier au format .xlsx ou installez xlrd.")
        book = xlrd.open_workbook(file_contents=data)
        best = []
        for sh in book.sheets():
            rows = [sh.row_values(i) for i in range(sh.nrows)]
            if len(rows) > len(best):
                best = rows
        return best
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
    best = []
    for ws in wb.worksheets:
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
        rows = [r for r in rows if any(v not in (None, "") for v in r)]
        if len(rows) > len(best):
            best = rows
    return best


KW = {
    "compte": ["compte", "n°", "numero", "numéro", "cpte", "code", "account"],
    "intitule": ["intitul", "libell", "désignation", "designation", "nom du compte", "label"],
    "debit": ["débit", "debit", "deb"],
    "credit": ["crédit", "credit", "cred"],
    "solde": ["solde"],
}


def is_account(v):
    if v is None:
        return False
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    return bool(re.fullmatch(r"[1-9]\d{1,11}", s.replace(" ", "")))


def analyse_balance(rows):
    """Detecte la ligne d'en-tete et propose un mapping de colonnes."""
    header_idx = None
    for i, r in enumerate(rows[:25]):
        txt = " ".join(str(x).lower() for x in r if x is not None)
        score = sum(1 for k in ("compte", "intitul", "libell", "débit", "debit", "crédit", "credit", "solde") if k in txt)
        if score >= 2:
            header_idx = i
            break
    ncols = max((len(r) for r in rows), default=0)
    data_rows = rows[header_idx + 1:] if header_idx is not None else rows
    # colonne compte : celle qui contient le plus de numeros de compte
    counts = [0] * ncols
    numeric = [0] * ncols
    texty = [0] * ncols
    for r in data_rows[:400]:
        for j in range(ncols):
            v = r[j] if j < len(r) else None
            if is_account(v):
                counts[j] += 1
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                numeric[j] += 1
            elif isinstance(v, str) and re.search(r"[A-Za-zÀ-ÿ]{3,}", v):
                texty[j] += 1
            elif isinstance(v, str) and re.fullmatch(r"[-\d\s.,() ]+", v.strip() or "x"):
                numeric[j] += 1
    col_compte = max(range(ncols), key=lambda j: counts[j]) if ncols else 0
    col_lib = None
    best = -1
    for j in range(ncols):
        if j != col_compte and texty[j] > best:
            best, col_lib = texty[j], j
    nums = [j for j in range(ncols) if j not in (col_compte, col_lib) and numeric[j] > 0]
    headers = []
    if header_idx is not None:
        headers = [str(x) if x is not None else "" for x in rows[header_idx]]
        # colonnes "solde" nommees dans l'en-tete
        hl = [h.lower() for h in headers]
        sold = [j for j in nums if j < len(hl) and "solde" in hl[j]]
        if len(sold) >= 2:
            nums = sold
    mapping = {"compte": col_compte, "intitule": col_lib, "debit": None, "credit": None, "solde": None}
    if len(nums) >= 2:
        mapping["debit"], mapping["credit"] = nums[-2], nums[-1]
    elif len(nums) == 1:
        mapping["solde"] = nums[0]
    preview = [["" if v is None else v for v in r] for r in data_rows[:12]]
    return {"header_row": header_idx, "headers": headers or [f"Colonne {j + 1}" for j in range(ncols)],
            "ncols": ncols, "mapping": mapping, "preview": preview}


def extract_balance(rows, mapping, header_row=None):
    data_rows = rows[header_row + 1:] if header_row is not None else rows
    cc, ci = mapping.get("compte"), mapping.get("intitule")
    cd, cr, cs = mapping.get("debit"), mapping.get("credit"), mapping.get("solde")
    acc = {}
    labels = {}
    for r in data_rows:
        def g(j):
            return r[j] if j is not None and j < len(r) else None
        a = g(cc)
        if not is_account(a):
            continue
        if isinstance(a, float):
            a = int(a)
        a = str(a).strip().replace(" ", "")
        if cs is not None:
            s = _num(g(cs))
        else:
            s = _num(g(cd)) - _num(g(cr))
        acc[a] = acc.get(a, 0.0) + s
        if a not in labels:
            labels[a] = str(g(ci) or "").strip()
    # suppression des comptes de totalisation (prefixes d'autres comptes presents)
    keys = sorted(acc)
    totals = set()
    for k in keys:
        for k2 in keys:
            if k2 != k and k2.startswith(k) and len(k2) > len(k):
                totals.add(k)
                break
    out = []
    for k in keys:
        if k in totals:
            continue
        s = round(acc[k], 2)
        out.append({"compte": k, "intitule": labels.get(k, ""), "sd": s if s > 0 else 0, "sc": -s if s < 0 else 0})
    return out, sorted(totals)


# --------------------------------------------------------- immobilisations
IMMO_KW = {
    "designation": ["désignation", "designation", "libell", "bien", "nature"],
    "compte": ["compte"],
    "reference": ["référence", "reference", "réf", "immatric", "n° inventaire"],
    "date_acquisition": ["date d'acq", "date acq", "acquisition", "date achat", "date"],
    "date_service": ["mise en service", "service"],
    "valeur": ["valeur d'origine", "valeur", "montant", "coût", "cout", "prix d'achat", "brut"],
    "taux": ["taux"],
    "duree": ["durée", "duree"],
    "amort_anterieur": ["antérieur", "anterieur", "cumul"],
    "date_cession": ["date de cession", "date cession", "sortie"],
    "prix_cession": ["prix de cession", "prix cession"],
}


def extract_immobilisations(rows):
    header_idx = None
    for i, r in enumerate(rows[:25]):
        txt = " ".join(str(x).lower() for x in r if x is not None)
        if sum(1 for k in ("désignation", "designation", "valeur", "taux", "date", "compte") if k in txt) >= 2:
            header_idx = i
            break
    if header_idx is None:
        raise ValueError("En-tête non reconnu : prévoir au moins les colonnes Désignation, Valeur, Taux, Date d'acquisition.")
    heads = [str(x or "").strip().lower() for x in rows[header_idx]]
    cols = {}
    for key, kws in IMMO_KW.items():
        for j, h in enumerate(heads):
            if j in cols.values():
                continue
            if any(k in h for k in kws):
                cols[key] = j
                break
    out = []
    for r in rows[header_idx + 1:]:
        def g(k):
            j = cols.get(k)
            return r[j] if j is not None and j < len(r) else None
        des = g("designation")
        val = _num(g("valeur"))
        if not des and not val:
            continue
        if isinstance(des, str) and des.strip().lower().startswith("total"):
            continue
        item = {"designation": str(des or "").strip(), "compte": str(g("compte") or "").replace(".0", "").strip(),
                "reference": str(g("reference") or "").strip(), "valeur": val}
        for k in ("date_acquisition", "date_service", "date_cession"):
            v = g(k)
            if isinstance(v, datetime.datetime):
                v = v.date()
            if isinstance(v, datetime.date):
                v = v.isoformat()
            item[k] = v or ""
        t = g("taux")
        if t not in (None, ""):
            t = _num(t)
            item["taux"] = t * 100 if 0 < t <= 1 else t
        d = g("duree")
        if d not in (None, "") and not item.get("taux"):
            item["duree"] = _num(d)
        if g("amort_anterieur") not in (None, ""):
            item["amort_anterieur"] = _num(g("amort_anterieur"))
        if g("prix_cession") not in (None, ""):
            item["prix_cession"] = _num(g("prix_cession"))
        out.append(item)
    return out


def extract_formations(rows):
    header = None
    for i, r in enumerate(rows[:25]):
        txt = " ".join(str(x).lower() for x in r if x is not None)
        if "montant" in txt and any(k in txt for k in ("libell", "formation", "organisme", "action", "désignation")):
            header = i
            break
    if header is None:
        raise ValueError("En-tête non reconnu : prévoir les colonnes Libellé (ou Formation), Organisme, Montant, Date, Catégorie.")
    heads = [str(x or "").strip().lower() for x in rows[header]]

    def col(*kws):
        for j, h in enumerate(heads):
            if any(k in h for k in kws):
                return j
        return None
    c = {"libelle": col("libell", "formation", "action", "désignation"), "organisme": col("organisme", "cabinet", "établissement", "etablissement", "bénéficiaire"),
         "montant": col("montant", "coût", "cout"), "date": col("date"), "categorie": col("catégorie", "categorie", "type"),
         "piece": col("pièce", "piece", "facture", "référence")}
    out = []
    for r in rows[header + 1:]:
        def g(k):
            j = c.get(k)
            return r[j] if j is not None and j < len(r) else None
        m = _num(g("montant"))
        if not m or str(g("libelle") or "").lower().startswith("total"):
            continue
        d = g("date")
        if isinstance(d, datetime.datetime):
            d = d.date()
        if isinstance(d, datetime.date):
            d = d.isoformat()
        cat = str(g("categorie") or "A").strip().upper()[:1] or "A"
        if cat not in "ABCDE":
            cat = "A"
        out.append({"categorie": cat, "date": d or "", "libelle": str(g("libelle") or "").strip(),
                    "organisme": str(g("organisme") or "").strip(), "piece": str(g("piece") or "").strip(), "montant": m})
    return out
