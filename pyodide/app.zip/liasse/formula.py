"""Mini moteur de formules Excel (sous-ensemble utilise par le modele de liasse).

Fonctions supportees : SUM, IF, IFERROR, MIN, MAX, INT, ROUND, ABS, AND, OR, NOT.
Operateurs : + - * / ^ & = <> < > <= >= et % postfixe.
Les formules sont compilees une fois en arbre (tuples) puis evaluees a la demande.
"""
import re
import math
import datetime


class XLError(Exception):
    def __init__(self, code="#VALUE!"):
        super().__init__(code)
        self.code = code

    def __repr__(self):
        return self.code


TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<str>"(?:[^"]|"")*")
  | (?P<ref>(?:(?:'(?:[^']|'')+'|[A-Za-z_][\w\.]*)!)?\$?[A-Za-z]{1,3}\$?\d+(?::(?:(?:'(?:[^']|'')+'|[A-Za-z_][\w\.]*)!)?\$?[A-Za-z]{1,3}\$?\d+)?)
  | (?P<err>\#REF!|\#DIV/0!|\#N/A|\#VALUE!|\#NAME\?)
  | (?P<num>\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+)
  | (?P<func>[A-Za-z][A-Za-z0-9\.]*(?=\())
  | (?P<bool>TRUE|FALSE)
  | (?P<op><>|<=|>=|[-+*/^&=<>%(),:;])
""", re.VERBOSE)

CELL_RE = re.compile(r"\$?([A-Za-z]{1,3})\$?(\d+)")


def col2num(c):
    n = 0
    for ch in c.upper():
        n = n * 26 + ord(ch) - 64
    return n


def num2col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def split_ref(ref, cur_sheet):
    if "!" in ref:
        sh, addr = ref.rsplit("!", 1)
        if sh.startswith("'"):
            sh = sh[1:-1].replace("''", "'")
    else:
        sh, addr = cur_sheet, ref
    return sh, addr


def tokenize(s):
    pos = 0
    out = []
    while pos < len(s):
        m = TOKEN_RE.match(s, pos)
        if not m:
            raise SyntaxError(f"Token inattendu a {pos}: {s[pos:pos+20]!r}")
        pos = m.end()
        kind = m.lastgroup
        if kind == "ws":
            continue
        out.append((kind, m.group()))
    return out


class Parser:
    """Descente recursive -> arbre de tuples."""

    def __init__(self, text, sheet):
        self.t = tokenize(text)
        self.i = 0
        self.sheet = sheet

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self, val=None):
        k, v = self.peek()
        if val is not None and v != val:
            raise SyntaxError(f"Attendu {val}, trouve {v}")
        self.i += 1
        return k, v

    def parse(self):
        node = self.comparison()
        if self.i != len(self.t):
            raise SyntaxError(f"Reste non analyse: {self.t[self.i:]}")
        return node

    def comparison(self):
        node = self.concat()
        while self.peek()[1] in ("=", "<>", "<", ">", "<=", ">="):
            op = self.take()[1]
            node = ("bin", op, node, self.concat())
        return node

    def concat(self):
        node = self.additive()
        while self.peek()[1] == "&":
            self.take()
            node = ("bin", "&", node, self.additive())
        return node

    def additive(self):
        node = self.term()
        while self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            node = ("bin", op, node, self.term())
        return node

    def term(self):
        node = self.power()
        while self.peek()[1] in ("*", "/"):
            op = self.take()[1]
            node = ("bin", op, node, self.power())
        return node

    def power(self):
        node = self.unary()
        while self.peek()[1] == "^":
            self.take()
            node = ("bin", "^", node, self.unary())
        return node

    def unary(self):
        k, v = self.peek()
        if v in ("+", "-"):
            self.take()
            operand = self.unary()
            return operand if v == "+" else ("neg", operand)
        return self.postfix()

    def postfix(self):
        node = self.primary()
        while self.peek()[1] == "%":
            self.take()
            node = ("bin", "/", node, ("num", 100.0))
        return node

    def primary(self):
        k, v = self.take()
        if k == "num":
            return ("num", float(v))
        if k == "str":
            return ("str", v[1:-1].replace('""', '"'))
        if k == "bool":
            return ("num", 1.0 if v == "TRUE" else 0.0)
        if k == "err":
            return ("err", v)
        if k == "ref":
            sh, addr = split_ref(v, self.sheet)
            if ":" in v:
                left, right = v.split(":", 1) if v.count("!") < 2 else (v[:v.index(":", v.index("!"))], v[v.index(":", v.index("!")) + 1:])
                sh, a = split_ref(left, self.sheet)
                b = split_ref(right, sh)[1]
                ma, mb = CELL_RE.fullmatch(a), CELL_RE.fullmatch(b)
                c1, r1 = col2num(ma.group(1)), int(ma.group(2))
                c2, r2 = col2num(mb.group(1)), int(mb.group(2))
                return ("rng", sh, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2))
            m = CELL_RE.fullmatch(addr)
            return ("ref", sh, m.group(1).upper() + m.group(2))
        if k == "func":
            name = v.upper()
            self.take("(")
            args = []
            if self.peek()[1] != ")":
                args.append(self.comparison())
                while self.peek()[1] in (",", ";"):
                    self.take()
                    if self.peek()[1] in (",", ";", ")"):
                        args.append(("num", 0.0))
                    else:
                        args.append(self.comparison())
            self.take(")")
            return ("fn", name, args)
        if v == "(":
            node = self.comparison()
            self.take(")")
            return node
        raise SyntaxError(f"Element inattendu {v!r}")


def parse_formula(text, sheet):
    return Parser(text.lstrip("="), sheet).parse()


def refs_of(node, acc=None):
    """Liste des references (feuille, adresse) et plages d'un arbre."""
    if acc is None:
        acc = []
    kind = node[0]
    if kind == "ref":
        acc.append(("ref", node[1], node[2]))
    elif kind == "rng":
        acc.append(node)
    elif kind == "bin":
        refs_of(node[2], acc)
        refs_of(node[3], acc)
    elif kind == "neg":
        refs_of(node[1], acc)
    elif kind == "fn":
        for a in node[2]:
            refs_of(a, acc)
    return acc


def _num(v):
    if isinstance(v, XLError):
        raise v
    if isinstance(v, datetime.date):
        if isinstance(v, datetime.datetime):
            v = v.date()
        return float((v - datetime.date(1899, 12, 30)).days)
    if v is None or v == "":
        return 0.0
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v.replace(" ", "").replace(",", "."))
        except ValueError:
            raise XLError("#VALUE!")
    return 0.0


def _truthy(v):
    if isinstance(v, XLError):
        raise v
    if isinstance(v, str):
        if v.upper() == "TRUE":
            return True
        if v.upper() == "FALSE":
            return False
        raise XLError("#VALUE!")
    return bool(_num(v))


class Evaluator:
    """Evalue des cellules a partir d'un dictionnaire {(feuille, adresse): valeur ou arbre}."""

    def __init__(self, cells, formulas):
        # cells : {(sheet, addr): constante}, formulas : {(sheet, addr): arbre}
        self.cells = cells
        self.formulas = formulas
        self.cache = {}
        self.stack = set()
        self.params = {}
        # index des cellules par feuille pour les plages
        self.by_sheet = {}
        for (sh, addr) in list(cells) + list(formulas):
            m = CELL_RE.fullmatch(addr)
            self.by_sheet.setdefault(sh, {})[(int(m.group(2)), col2num(m.group(1)))] = addr

    def set(self, sheet, addr, value):
        key = (sheet, addr)
        self.formulas.pop(key, None)
        self.cells[key] = value
        m = CELL_RE.fullmatch(addr)
        self.by_sheet.setdefault(sheet, {})[(int(m.group(2)), col2num(m.group(1)))] = addr
        self.cache.clear()

    def reset_cache(self):
        self.cache.clear()

    def get(self, sheet, addr):
        key = (sheet, addr)
        if key in self.cache:
            return self.cache[key]
        if key in self.formulas:
            if key in self.stack:
                return 0.0  # reference circulaire : on neutralise
            self.stack.add(key)
            try:
                v = self.eval(self.formulas[key])
            except XLError as e:
                v = e
            except ZeroDivisionError:
                v = XLError("#DIV/0!")
            finally:
                self.stack.discard(key)
            self.cache[key] = v
            return v
        v = self.cells.get(key)
        return v

    def range_values(self, node):
        _, sh, r1, c1, r2, c2 = node
        idx = self.by_sheet.get(sh, {})
        out = []
        # parcourt seulement les cellules existantes
        if (r2 - r1 + 1) * (c2 - c1 + 1) < len(idx):
            for r in range(r1, r2 + 1):
                for c in range(c1, c2 + 1):
                    a = idx.get((r, c))
                    if a:
                        out.append(self.get(sh, a))
        else:
            for (r, c), a in idx.items():
                if r1 <= r <= r2 and c1 <= c <= c2:
                    out.append(self.get(sh, a))
        return out

    def eval(self, n):
        k = n[0]
        if k == "num" or k == "str":
            return n[1]
        if k == "err":
            raise XLError(n[1])
        if k == "ref":
            v = self.get(n[1], n[2])
            if isinstance(v, XLError):
                raise v
            return v
        if k == "rng":
            # utilisation scalaire d'une plage (intersection implicite) : 1re cellule
            _, sh, r1, c1, r2, c2 = n
            v = self.get(sh, num2col(c1) + str(r1))
            if isinstance(v, XLError):
                raise v
            return v
        if k == "neg":
            return -_num(self.eval(n[1]))
        if k == "bin":
            op = n[1]
            a = self.eval(n[2])
            b = self.eval(n[3])
            if op == "+":
                return _num(a) + _num(b)
            if op == "-":
                return _num(a) - _num(b)
            if op == "*":
                return _num(a) * _num(b)
            if op == "/":
                d = _num(b)
                if d == 0:
                    raise XLError("#DIV/0!")
                return _num(a) / d
            if op == "^":
                return _num(a) ** _num(b)
            if op == "&":
                return _txt(a) + _txt(b)
            return _compare(op, a, b)
        if k == "fn":
            return self.call(n[1], n[2])
        raise XLError("#NAME?")

    def _flat(self, args):
        for a in args:
            if a[0] == "rng":
                for v in self.range_values(a):
                    if isinstance(v, XLError):
                        raise v
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        yield float(v)
            else:
                v = self.eval(a)
                if isinstance(v, str):
                    if v.strip() == "":
                        continue
                    yield _num(v)
                elif v is None:
                    continue
                else:
                    yield _num(v)

    def call(self, name, args):
        if name == "SUM":
            return sum(self._flat(args))
        if name == "MIN":
            vals = list(self._flat(args))
            return min(vals) if vals else 0.0
        if name == "MAX":
            vals = list(self._flat(args))
            return max(vals) if vals else 0.0
        if name == "IF":
            cond = _truthy(self.eval(args[0]))
            if cond:
                return self.eval(args[1]) if len(args) > 1 else True
            return self.eval(args[2]) if len(args) > 2 else False
        if name == "IFERROR":
            try:
                v = self.eval(args[0])
                if isinstance(v, XLError):
                    raise v
                return v
            except (XLError, ZeroDivisionError):
                return self.eval(args[1])
        if name == "INT":
            return float(math.floor(_num(self.eval(args[0]))))
        if name == "ABS":
            return abs(_num(self.eval(args[0])))
        if name == "ROUND":
            x = _num(self.eval(args[0]))
            d = int(_num(self.eval(args[1]))) if len(args) > 1 else 0
            f = 10 ** d
            return math.floor(abs(x) * f + 0.5) / f * (1 if x >= 0 else -1)
        if name == "AND":
            return all(_truthy(self.eval(a)) for a in args)
        if name == "OR":
            return any(_truthy(self.eval(a)) for a in args)
        if name == "PARAM":
            key = self.eval(args[0])
            v = self.params.get(key, 0.0)
            return 0.0 if v is None else v
        if name == "NOT":
            return not _truthy(self.eval(args[0]))
        if name == "ISTEXT":
            try:
                v = self.eval(args[0])
            except XLError:
                return False
            return isinstance(v, str) and v.strip() != ""
        if name == "N":
            try:
                v = self.eval(args[0])
            except XLError:
                return 0.0
            return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else 0.0
        raise XLError("#NAME?")


def _txt(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _compare(op, a, b):
    def norm(x):
        if x is None:
            return 0.0
        if isinstance(x, bool):
            return float(x)
        return x
    a, b = norm(a), norm(b)
    if isinstance(a, str) and isinstance(b, str):
        a, b = a.upper(), b.upper()
    elif isinstance(a, str) or isinstance(b, str):
        # Excel : texte > nombre ; egalite fausse
        if op == "=":
            return False
        if op == "<>":
            return True
        ta, tb = isinstance(a, str), isinstance(b, str)
        if op in ("<", "<="):
            return (not ta) and tb
        return ta and (not tb)
    if op == "=":
        return a == b
    if op == "<>":
        return a != b
    if op == "<":
        return a < b
    if op == ">":
        return a > b
    if op == "<=":
        return a <= b
    if op == ">=":
        return a >= b
    raise XLError("#VALUE!")
