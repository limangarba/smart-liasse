"""Serveur local de l'application Smart Liasse (interface web hors ligne)."""
import io
import json
import os
import re
import threading
import webbrowser
import datetime

from flask import Flask, jsonify, request, send_file, send_from_directory, abort, Response

from . import store, engine, book, xlsx, importer, report
from .model import get_model
from .pages import PLAN, PAGES
from .html_render import grid_html
from .immobilisations import POSTES, compute_register, to_date, poste_from_compte
from . import declarations as decl
from .custom import TEXTES_DEFAUT
from .corrections import JOURNAL
from .nombres import parse as parse_num

EDIT_LOCK = threading.RLock()
from .engine import PARAM_CELLS

HERE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(HERE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024
VERSION = "2.1"


@app.errorhandler(Exception)
def _erreur(e):
    """Toute erreur imprevue est renvoyee en clair a l'interface (au lieu d'une page 500 muette)."""
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        if e.code == 400 and request.path.startswith("/api/"):
            return jsonify({"erreur": "Requête incomplète : aucun fichier ou donnée reçue."}), 400
        return e
    import traceback
    traceback.print_exc()
    msg = str(e) or e.__class__.__name__
    if isinstance(e, (UnicodeDecodeError, json.JSONDecodeError)):
        msg = "Fichier illisible : format non reconnu."
    return jsonify({"erreur": f"Opération impossible : {msg}"}), 500


def _fichier():
    f = request.files.get("fichier")
    if not f or not f.filename:
        abort(400)
    return f


def load(did):
    d = store.get(did)
    if d is None:
        abort(404)
    return d


def compute(d):
    return engine.compute(d)


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ------------------------------------------------------------------ dossiers
@app.get("/api/dossiers")
def api_list():
    return jsonify(store.list_dossiers())


@app.post("/api/dossiers")
def api_create():
    body = request.get_json(force=True, silent=True) or {}
    try:
        annee = int(str(body.get("annee") or "").strip() or datetime.date.today().year - 1)
    except ValueError:
        annee = datetime.date.today().year - 1
    d = body.get("dossier") or {
        "identite": {"denomination": body.get("denomination") or "Nouvelle société", "nif": body.get("nif") or "",
                     "pays_siege": "06", "regime_fiscal": "1", "nb_etab_pays": "01", "nb_etab_hors": "00"},
        "exercice": {"annee": annee, "debut": f"{annee}-01-01", "fin": f"{annee}-12-31", "duree": 12,
                     "prec_fin": f"{annee - 1}-12-31", "prec_duree": 12},
        "balance_n": [], "balance_n1": [], "immobilisations": [], "params": {}, "cells": {},
        "textes": {}, "tap": {}, "tcfge": {}, "options": {},
    }
    d.pop("id", None)
    did = store.save(d)
    return jsonify({"id": did})


@app.get("/api/dossiers/<int:did>")
def api_get(did):
    return jsonify(load(did))


@app.put("/api/dossiers/<int:did>")
def api_put(did):
    body = request.get_json(force=True)
    with EDIT_LOCK:
        d = load(did)
        for k, v in body.items():
            if k == "id":
                continue
            d[k] = v
        store.save(d)
    return jsonify({"ok": True})


@app.delete("/api/dossiers/<int:did>")
def api_delete(did):
    store.delete(did)
    return jsonify({"ok": True})


@app.post("/api/dossiers/<int:did>/dupliquer")
def api_dup(did):
    d = load(did)
    d.pop("id", None)
    d.setdefault("identite", {})
    did2 = store.save(d)
    return jsonify({"id": did2})


@app.post("/api/dossiers/<int:did>/exercice-suivant")
def api_next(did):
    d = load(did)
    new = report.next_year(d)
    did2 = store.save(new)
    return jsonify({"id": did2})


@app.get("/api/dossiers/<int:did>/sauvegarde")
def api_backup(did):
    d = load(did)
    data = json.dumps(d, ensure_ascii=False, indent=1, default=str).encode("utf-8")
    name = _fname(d, "json")
    return send_file(io.BytesIO(data), mimetype="application/json", as_attachment=True, download_name=name)


@app.post("/api/restauration")
def api_restore():
    f = _fichier()
    try:
        d = json.loads(f.read().decode("utf-8-sig"))
        if not isinstance(d, dict) or not ("identite" in d or "balance_n" in d):
            raise ValueError
    except (ValueError, UnicodeDecodeError):
        return jsonify({"erreur": "Ce fichier n'est pas une sauvegarde Smart Liasse (.json)."}), 400
    d.pop("id", None)
    did = store.save(d)
    return jsonify({"id": did})


# ------------------------------------------------------------------ balances
@app.post("/api/import/analyse")
def api_import_analyse():
    f = _fichier()
    data = f.read()
    try:
        rows = importer.read_table(f.filename, data)
    except Exception as e:
        return jsonify({"erreur": str(e)}), 400
    info = importer.analyse_balance(rows)
    info["preview"] = [[_js(v) for v in r] for r in info["preview"]]
    return jsonify(info)


@app.post("/api/dossiers/<int:did>/balance/<which>")
def api_import_balance(did, which):
    if which not in ("n", "n1"):
        abort(400)
    f = _fichier()
    mapping = json.loads(request.form.get("mapping") or "{}")
    header_row = request.form.get("header_row")
    header_row = int(header_row) if header_row not in (None, "", "null") else None
    rows = importer.read_table(f.filename, f.read())
    entries, totals = importer.extract_balance(rows, {k: (int(v) if v not in (None, "", "null") else None) for k, v in mapping.items()}, header_row)
    d = load(did)
    d["balance_" + which] = entries
    store.save(d)
    sd = sum(e["sd"] for e in entries)
    sc = sum(e["sc"] for e in entries)
    return jsonify({"comptes": len(entries), "debit": sd, "credit": sc, "totaux_ignores": totals})


@app.get("/api/dossiers/<int:did>/ventilation")
def api_ventilation(did):
    from . import plan
    return jsonify(plan.affectations(load(did)))


_ROW_CODES = None


def _row_codes(model):
    """Poste de la liasse (code bilan / resultat) de chaque ligne de la balance standard."""
    global _ROW_CODES
    if _ROW_CODES is not None:
        return _ROW_CODES
    codes = {}
    # la ligne de sous-total qui suit porte le code du poste
    cur = []
    for r in range(5, 764):
        a = model.consts.get(("Balance std", f"A{r}"))
        c = model.consts.get(("Balance std", f"C{r}"))
        if a is not None:
            cur.append(r)
            if c:
                codes[r] = str(c).strip()
        elif c:
            for x in cur:
                codes.setdefault(x, str(c).strip())
            cur = []
    _ROW_CODES = codes
    return codes


@app.get("/api/lignes-standard")
def api_leaf():
    from . import plan
    model = get_model()
    sens = plan.sensibilite(model)
    out = []
    for r, a, l, c in model.leaf_info:
        dd, cc = (sens.get(r) or {}).get("D") or [], (sens.get(r) or {}).get("C") or []
        p = dd[0] if dd else (cc[0] if cc else "")
        if dd and cc and dd != cc:
            p = f"{dd[0]} / {cc[0]}"
        out.append({"ligne": r, "compte": a, "libelle": l, "poste": p})
    return jsonify(out)


# ----------------------------------------------------------------- calculs
@app.get("/api/dossiers/<int:did>/synthese")
def api_synthese(did):
    d = load(did)
    res = compute(d)
    n = res.num
    checks = engine.run_checks(res)
    immo = res.info.get("immo") or {}
    t = getattr(res.ev, "decl", {})
    data = {
        "ca": n("RESULTAT", "H17"), "ca_n1": n("RESULTAT", "I17"),
        "va": n("RESULTAT", "H31"), "ebe": n("RESULTAT", "H33"), "rex": n("RESULTAT", "H36"),
        "resultat": n("RESULTAT", "H51"), "resultat_n1": n("RESULTAT", "I51"),
        "total_bilan": n("Bilan modèle 1", "F40"), "total_passif": n("Bilan modèle 1", "K40"),
        "total_bilan_n1": n("Bilan modèle 1", "G40"),
        "capitaux_propres": n("Bilan modèle 1", "K22"), "tresorerie": n("Bilan modèle 1", "F38") - n("Bilan modèle 1", "K38"),
        "resultat_fiscal": n("TABLEAU DE PASSAGE", "G49") or n("TABLEAU DE PASSAGE", "G50"),
        "imf": n("TABLEAU DE PASSAGE", "F53"), "isb": n("TABLEAU DE PASSAGE", "F54"),
        "reliquat": n("TABLEAU DE PASSAGE", "F62"),
        "tap": res.ev.params.get("tap_total", 0), "tcfge": res.ev.params.get("tcfge_montant", 0),
        "total_a_payer": n("BORDEREAU", "X57"),
        "deficit_reportable": n("TRAITEMENT DE DEFICITS", "M18"), "ard": n("TRAITEMENT DE DEFICITS", "F26"),
        "controles": [{"libelle": c[0], "a": c[1], "b": c[2], "ok": bool(c[3])} for c in checks],
        "non_ventiles": [{"source": x[0], "compte": x[1], "intitule": x[2], "solde": x[3]} for x in res.info["non_ventiles"]],
        "approx": [{"source": x[0], "compte": x[1], "intitule": x[2]} for x in res.info["approx"]],
        "totaux": res.info["totaux"],
        "annexe_amorts": bool(immo.get("annexe")),
    }
    return jsonify(data)


@app.get("/api/dossiers/<int:did>/impot")
def api_impot(did):
    """Calcul detaille de l'impot et du bordereau de versement (page 86), pour controle a l'ecran."""
    d = load(did)
    res = compute(d)
    n = res.num
    P = "TABLEAU DE PASSAGE"
    p = res.ev.params
    ded = [("1er acompte", n(P, "G57")), ("2e acompte", n(P, "G58")), ("3e acompte", n(P, "G59")),
           ("Crédit d'impôt", n(P, "G60")), ("Précomptes ISB", n(P, "G61"))]
    du = max(n(P, "F53"), n(P, "F54"))
    solde = n(P, "F62")
    impute = p.get("imputer_credit") not in (False, 0, 0.0, "0", "non")
    autres = float(p.get("tap_total") or 0) + float(p.get("tcfge_montant") or 0)
    net = solde + autres if impute else max(0.0, solde) + autres
    return jsonify({
        "ca": n(P, "B53"), "taux_imf": p.get("taux_imf"), "imf": n(P, "D53"), "minimum": float(p.get("imf_minimum") or 0),
        "base_isb": n(P, "B54"), "taux_isb": p.get("taux_isb"), "isb": n(P, "D54"),
        "impot_du": du, "nature": "ISB" if n(P, "F54") > 0 else ("IMF" if du else ""),
        "deductions": ded, "total_deductions": sum(v for _, v in ded),
        "solde": solde, "a_payer": max(0.0, solde), "credit": max(0.0, -solde),
        "impute": impute, "credit_reportable": max(0.0, -net) if impute else max(0.0, -solde),
        "tap_brute": float(p.get("tap_3") or 0) + float(p.get("tap_5") or 0), "tap_formation": float(p.get("tap_formation") or 0),
        "tap_mode": p.get("tap_mode") or "base", "tap_base": float(p.get("tap_base") or 0),
        "tap_ded_base": float(p.get("tap_ded_base") or 0), "tap_base_nette": float(p.get("tap_base_nette") or 0),
        "tap": float(p.get("tap_total") or 0), "tcfge": float(p.get("tcfge_montant") or 0),
        "total": n("BORDEREAU", "X57"),
        "registre": bool(d.get("reglements")),
        "illisibles": res.info.get("params_invalides") or [],
    })


@app.get("/api/dossiers/<int:did>/immobilisations/calcul")
def api_immo(did):
    d = load(did)
    exo = d.get("exercice") or {}
    debut, fin = to_date(exo.get("debut")), to_date(exo.get("fin"))
    if not debut or not fin:
        return jsonify({"lignes": [], "totaux": {}})
    items = d.get("immobilisations") or []
    out = []
    from .immobilisations import compute_asset
    for a in items:
        r = compute_asset(a, debut, fin) if (a.get("designation") or a.get("valeur")) else None
        out.append(None if r is None else {k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in r.items()})
    _, tot = compute_register(items, debut, fin)
    return jsonify({"lignes": out, "totaux": tot, "postes": POSTES})


@app.post("/api/import/immobilisations")
def api_import_immo():
    f = _fichier()
    rows = importer.read_table(f.filename, f.read())
    try:
        items = importer.extract_immobilisations(rows)
    except ValueError as e:
        return jsonify({"erreur": str(e)}), 400
    for it in items:
        if not it.get("poste"):
            it["poste"] = poste_from_compte(it.get("compte")) or "AM"
    return jsonify(items)


@app.get("/api/dossiers/<int:did>/declarations")
def api_decl(did):
    d = load(did)
    res = compute(d)
    t = res.ev.decl
    return jsonify({"tap": _clean(t["tap"]), "tcfge": _clean(t["tcfge"]),
                    "tap_lignes": decl.TAP_LIGNES, "tcfge_lignes": decl.TCFGE_LIGNES})


def _clean(o):
    return json.loads(json.dumps(o, default=str))


# -------------------------------------------------------------------- pages
@app.get("/api/plan")
def api_plan():
    return jsonify([{"id": p[0], "section": p[1], "titre": p[2]} for p in PLAN])


@app.get("/api/dossiers/<int:did>/page/<pid>")
def api_page(did, pid):
    if pid not in PAGES:
        abort(404)
    d = load(did)
    res = compute(d)
    try:
        zoom = float(request.args.get("zoom", 1))
    except ValueError:
        zoom = 1.0
    if pid == "garde":
        res.ev.params["nb_pages"] = request.args.get("nb") or ""
        res.ev.reset_cache()
    grids = book.page_grids(res, pid)
    if not grids:
        return Response('<div class="vide">Page sans objet pour ce dossier (aucune donnée à présenter).</div>', mimetype="text/html")
    return Response("".join(grid_html(g, zoom) for g in grids), mimetype="text/html")


@app.post("/api/dossiers/<int:did>/cellule")
def api_cell(did):
    body = request.get_json(force=True)
    ref = body.get("ref")
    if not ref or "!" not in ref:
        abort(400)
    d = load(did)
    cells = d.setdefault("cells", {})
    v = body.get("value")
    key = PARAM_CELLS.get(tuple(ref.rsplit("!", 1)))
    if key:
        # acomptes, credit, precomptes... : une seule source (parametres fiscaux), quelle que soit la page modifiee
        with EDIT_LOCK:
            d = load(did)
            p = d.setdefault("params", {})
            for r_, k_ in PARAM_CELLS.items():
                if k_ == key:
                    d.get("cells", {}).pop("!".join(r_), None)
            if v is None or v == "__reset__" or (isinstance(v, str) and not v.strip()):
                p.pop(key, None)
                p.pop(key + "_manuel", None)
            else:
                f = parse_num(v) if isinstance(v, str) else v
                p[key] = f if f is not None else v
                p[key + "_manuel"] = True
            store.save(d)
        return jsonify({"ok": True, "parametre": key})
    with EDIT_LOCK:
        d = load(did)
        cells = d.setdefault("cells", {})
        if v is None or v == "__reset__":
            cells.pop(ref, None)
        else:
            if isinstance(v, str):
                s = v.strip()
                m = re.fullmatch(r"(\d{1,2})[/.](\d{1,2})[/.](\d{4})", s)
                if m:
                    v = f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
                elif s == "":
                    v = ""
                elif re.fullmatch(r"[-+(]?[\d\s\u00a0\u202f.,']+\)?-?(\s*(F|FCFA|F CFA|XOF|%))?", s, re.I):
                    f = parse_num(s)
                    if f is not None:
                        v = f / 100 if s.endswith("%") else f
                        if isinstance(v, float) and v.is_integer():
                            v = int(v)
            cells[ref] = v
        store.save(d)
    return jsonify({"ok": True})


# ------------------------------------------------------------------ exports
def _fname(d, ext, prefix="Liasse"):
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    nom = re.sub(r"[^A-Za-z0-9_-]+", "_", (ident.get("denomination") or "societe"))[:40]
    return f"{prefix}_{nom}_{exo.get('annee', '')}.{ext}"


def _selection():
    s = request.args.get("pages")
    return set(s.split(",")) if s else None


@app.get("/api/dossiers/<int:did>/export.pdf")
def api_pdf(did):
    d = load(did)
    res = compute(d)
    data, n = book.export_pdf(res, _selection())
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=request.args.get("dl") == "1",
                     download_name=_fname(d, "pdf"))


@app.get("/api/dossiers/<int:did>/export.xlsx")
def api_xlsx(did):
    d = load(did)
    res = compute(d)
    data, n = xlsx.export_xlsx(res, _selection())
    return send_file(io.BytesIO(data), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     as_attachment=True, download_name=_fname(d, "xlsx"))


@app.get("/api/dossiers/<int:did>/alertes")
def api_alertes(did):
    from . import alertes
    d = load(did)
    return jsonify(alertes.compute(compute(d)))


@app.get("/api/dossiers/<int:did>/rapport")
def api_rapport(did):
    from . import rapport
    d = load(did)
    A = rapport.analyse(compute(d))
    sc, lab = rapport.score(A["ratios"])
    return jsonify({"forces": A["forces"], "faiblesses": A["faiblesses"],
                    "conseils": [{"titre": t, "texte": x} for t, x in A["conseils"]],
                    "ratios": A["ratios"], "score": sc, "appreciation": lab, "D": A["D"]})


@app.get("/api/dossiers/<int:did>/rapport.pdf")
def api_rapport_pdf(did):
    from . import rapport
    d = load(did)
    data = rapport.export_pdf(d)
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=request.args.get("dl") == "1",
                     download_name=_fname(d, "pdf", "Rapport_gestion"))


# ------------------------------------------------------ import d'une liasse complete
@app.post("/api/import/liasse")
def api_import_liasse():
    from . import import_liasse
    f = _fichier()
    try:
        d = import_liasse.importer(f.filename, f.read())
    except ValueError as e:
        return jsonify({"erreur": str(e)}), 400
    except Exception as e:
        return jsonify({"erreur": f"Lecture impossible du fichier : {e}"}), 400
    d.setdefault("rapport", {"signature": "G.H. Liman", "lieu": "Niamey"})
    did = store.save(d)
    return jsonify({"id": did, "postes": len(d["import"]["declare"]), "mode": d["import"]["mode"]})


@app.post("/api/dossiers/<int:did>/liasse-reference")
def api_liasse_ref(did):
    """Rattache a un dossier existant une liasse deja deposee, pour comparaison (sans modifier les donnees)."""
    from . import import_liasse
    f = _fichier()
    try:
        imp = import_liasse.importer(f.filename, f.read())["import"]
    except ValueError as e:
        return jsonify({"erreur": str(e)}), 400
    except Exception as e:
        return jsonify({"erreur": f"Lecture impossible du fichier : {e}"}), 400
    imp["notes"] = [n for n in imp.get("notes", []) if "balance" not in n.lower() and "saisies" not in n.lower()]
    imp["notes"].insert(0, "Liasse de référence rattachée au dossier : les données du dossier n'ont pas été modifiées.")
    d = load(did)
    d["import"] = imp
    store.save(d)
    return jsonify({"ok": True, "postes": len(imp["declare"])})


@app.get("/api/dossiers/<int:did>/conformite")
def api_conformite(did):
    from . import import_liasse
    from .conformite import recommandations
    d = load(did)
    if not d.get("import"):
        return jsonify({"vide": True})
    v = import_liasse.verifier(d)
    v["recommandations"] = [{"titre": t, "texte": x} for t, x in recommandations(v)]
    return jsonify(_clean(v))


@app.delete("/api/dossiers/<int:did>/conformite")
def api_conformite_del(did):
    d = load(did)
    d.pop("import", None)
    store.save(d)
    return jsonify({"ok": True})


@app.get("/api/dossiers/<int:did>/conformite.pdf")
def api_conformite_pdf(did):
    from . import conformite
    d = load(did)
    if not d.get("import"):
        abort(404)
    data = conformite.export_pdf(d)
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=request.args.get("dl") == "1",
                     download_name=_fname(d, "pdf", "Rapport_conformite"))


@app.get("/api/types-reglements")
def api_types_regl():
    from .reglements import TYPES
    return jsonify(TYPES)


@app.post("/api/import/reglements")
def api_import_regl():
    from . import reglements
    f = _fichier()
    rows = importer.read_table(f.filename, f.read())
    try:
        return jsonify(reglements.extract(rows, request.form.get("type") or "precompte_douane"))
    except ValueError as e:
        return jsonify({"erreur": str(e)}), 400


@app.post("/api/import/formations")
def api_import_form():
    f = _fichier()
    rows = importer.read_table(f.filename, f.read())
    try:
        return jsonify(importer.extract_formations(rows))
    except ValueError as e:
        return jsonify({"erreur": str(e)}), 400


@app.get("/api/dossiers/<int:did>/notes-na")
def api_notes_na(did):
    """Notes non chiffrees (N/A en fiche R4), retirees d'office de l'impression."""
    from .notes_na import non_chiffrees
    d = load(did)
    res = compute(d)
    return jsonify(non_chiffrees(res))


@app.get("/api/dossiers/<int:did>/pages-auto")
def api_pages_auto(did):
    """Pages retirees automatiquement : notes non chiffrees et second modele de bilan."""
    from .notes_na import non_chiffrees
    d = load(did)
    res = compute(d)
    opts = d.get("options") or {}
    auto = set(book.exclusions_auto(res))
    if not opts.get("imprimer_notes_vides"):
        auto |= set(non_chiffrees(res))
    return jsonify(sorted(auto))


@app.get("/api/dossiers/<int:did>/page/<pid>/liste")
def api_page_liste(did, pid):
    """Cellules modifiables d'une page presentees en liste (libelle, valeur, calcul ou saisie)."""
    from .numfmt import fmt_value
    if pid not in PAGES:
        abort(404)
    d = load(did)
    res = compute(d)
    p = PAGES[pid]
    if not p[3] or ":" not in p[4] or p[4].startswith(("TEXTE", "CUSTOM")):
        return jsonify([])
    g = book.page_grids(res, pid)[0]
    model = res.model

    def entete(c):
        f = model.sheets[c.ref[0]]["cells"].get(c.ref[1], {}).get("f", "")
        return "Fiche R1" in f or "Fiche R2" in f

    import collections
    merge = g.merge_at()

    def anchor(i, j):
        m = merge.get((i, j))
        return m is None or (m[0], m[1]) == (i, j)

    def isnum(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool)

    fcells = [(i, j) for (i, j), c in g.cells.items()
              if c.ref and c.formula and (isnum(c.value) or c.value is None) and not entete(c) and anchor(i, j)]
    cnt = collections.Counter(j for i, j in fcells)
    numcols = {j for j, n in cnt.items() if n >= 3}
    start = min((i for i, j in fcells if j in numcols), default=0)
    heads = {}

    def colhead(j):
        if j not in heads:
            t = ""
            for i in range(start - 1, max(start - 7, -1), -1):
                c = g.cells.get((i, j))
                if c is None:
                    for (a, b, a2, b2) in g.merges:
                        if a <= i <= a2 and b <= j <= b2:
                            c = g.cells.get((a, b))
                            break
                if c is not None and c.text and not c.num and len(c.text.strip()) > 1:
                    t = c.text.strip().replace("\n", " ")
                    break
            heads[j] = t[:40]
        return heads[j]
    out = []
    rows = {}
    prev_labels = []
    for (i, j), c in g.cells.items():
        rows.setdefault(i, []).append((j, c))
    for i in sorted(rows):
        if i < start:
            continue
        cells = sorted(rows[i], key=lambda x: x[0])
        labels = []
        cand = []
        for j, c in cells:
            t = (c.text or "").strip()
            if t and not c.num and not c.formula:
                if len(t) > 2 and not re.fullmatch(r"[=…\.\s:\-–_]+", t):
                    labels.append(t)
                continue
            if not c.ref or entete(c) or not anchor(i, j):
                continue
            if j not in numcols and not (c.formula and (isnum(c.value) or (isinstance(c.value, str) and len(c.value.strip()) > 2))):
                continue
            v = c.value
            if v is not None and not isnum(v) and not (c.formula and isinstance(v, str) and len(v.strip()) > 2):
                continue
            if not labels and not c.formula:
                continue
            if not (c.formula or c.forced or v is None):
                continue
            lab = " – ".join(x for x in (labels or prev_labels)[-2:] if x)[:160]
            if not lab or re.search(r"SIGLE|ADRESSE|TELEDECL|DENOMINATION|IDENTIFICATION|DUREE|DURÉE|EXERCICE CLOS", lab.upper()):
                continue
            pk = PARAM_CELLS.get(c.ref)
            saisie = bool(c.forced) or bool(pk and (d.get("params") or {}).get(pk + "_manuel"))
            cand.append({"ref": f"{c.ref[0]}!{c.ref[1]}", "libelle": lab, "cellule": c.ref[1], "colonne": colhead(j),
                         "valeur": v, "affiche": c.text, "calcul": bool(c.formula) and not pk, "saisie": saisie})
        prev_labels = labels
        # une ligne qui porte un calcul n'affiche que ses cellules calculees ; sinon une seule case de saisie
        utiles = [x for x in cand if x["calcul"] or x["saisie"] or x["valeur"] is not None]
        if utiles:
            out.extend(utiles)
        elif cand and len({x["colonne"] for x in cand}) == len(cand) and len(cand) > 1 and len(numcols) > 1 and any(x["colonne"] for x in cand):
            out.extend(cand)   # tableau a plusieurs colonnes de saisie (N / N-1...)
        elif cand:
            out.append(cand[-1])
    return jsonify(out)


@app.post("/api/dossiers/<int:did>/page/<pid>/reinitialiser")
def api_page_reset(did, pid):
    from .layout import parse_area
    from .formula import CELL_RE, col2num
    p = PAGES.get(pid)
    if not p or not p[3]:
        abort(404)
    d = load(did)
    r1, c1, r2, c2 = parse_area(p[4])
    cells = d.get("cells") or {}
    n = 0
    for ref in list(cells):
        sh, a = ref.rsplit("!", 1)
        m = CELL_RE.fullmatch(a)
        if sh == p[3] and m and r1 <= int(m.group(2)) <= r2 and c1 <= col2num(m.group(1)) <= c2:
            cells.pop(ref)
            n += 1
    store.save(d)
    return jsonify({"supprimees": n})


@app.get("/api/textes-defaut")
def api_textes():
    return jsonify(TEXTES_DEFAUT)


@app.get("/api/apropos")
def api_apropos():
    return jsonify({"version": VERSION, "corrections": [{"feuille": a, "cellule": b, "objet": c} for a, b, c in JOURNAL],
                    "base": store.db_path()})


def _js(v):
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.strftime("%d/%m/%Y")
    return v


@app.post("/api/quitter")
def api_quit():
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


def port_occupe(port):
    import socket
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def run(port=8765, open_browser=True):
    url = f"http://127.0.0.1:{port}/"
    if port_occupe(port):
        # deja lance : on ouvre simplement le navigateur
        if open_browser:
            webbrowser.open(url)
        return
    get_model()
    if open_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    print(f"Smart Liasse est lancé : {url}\n(laisser cette fenêtre ouverte pendant l'utilisation ; Ctrl+C pour arrêter)")
    try:
        from waitress import serve
        serve(app, host="127.0.0.1", port=port, threads=4)
    except ImportError:
        app.run(host="127.0.0.1", port=port, debug=False, threaded=True)
