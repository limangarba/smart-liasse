"""Mise en forme des valeurs selon les formats de nombre Excel (usage courant de la liasse)."""
import datetime
import re

NBSP = " "


def _group(n):
    s = f"{n:,.0f}".replace(",", NBSP)
    return s


def fmt_number(v, nf):
    nf = nf or "General"
    low = nf.lower()
    if "%" in nf:
        dec = 0
        m = re.search(r"0\.(0+)%", nf)
        if m:
            dec = len(m.group(1))
        return f"{v * 100:.{dec}f}".replace(".", ",") + " %"
    if any(t in low for t in ("yy", "dd", "mmm")) and not ("#" in nf):
        try:
            d = datetime.date(1899, 12, 30) + datetime.timedelta(days=int(v))
            return d.strftime("%d/%m/%Y")
        except Exception:
            pass
    accounting = '"-"' in nf
    parens = "\\(" in nf or "(#" in nf
    if nf == "General" or nf == "@":
        if abs(v - round(v)) < 1e-9:
            iv = int(round(v))
            if abs(iv) >= 10000:
                return ("-" if iv < 0 else "") + _group(abs(iv))
            return str(iv)
        return f"{v:.2f}".replace(".", ",")
    dec = 0
    m = re.search(r"0\.(0+)", nf)
    if m:
        dec = len(m.group(1))
    if "#,##0" in nf or "# ##0" in nf or accounting:
        if abs(v) < 0.5 and dec == 0:
            return "-"
        if dec:
            body = f"{abs(v):,.{dec}f}".replace(",", NBSP).replace(".", ",")
        else:
            body = _group(abs(v))
        if v < 0:
            return f"({body})" if parens else f"-{body}"
        return body
    if nf in ("0", "00", "000"):
        return str(int(round(v))).zfill(len(nf))
    if dec:
        return f"{v:.{dec}f}".replace(".", ",")
    return str(int(round(v)))


def fmt_value(v, nf):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "VRAI" if v else "FAUX"
    if isinstance(v, datetime.datetime):
        v = v.date()
    if isinstance(v, datetime.date):
        if nf and "mmmm" in nf:
            mois = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
                    "septembre", "octobre", "novembre", "décembre"]
            return f"{v.day} {mois[v.month - 1]} {v.year}"
        return v.strftime("%d/%m/%Y")
    if isinstance(v, (int, float)):
        return fmt_number(float(v), nf)
    if hasattr(v, "code"):
        return ""  # erreur de calcul : cellule laissee vide a l'impression
    return str(v)
