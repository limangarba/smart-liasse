"""Rapport de gestion financiere : performance, faiblesses, tableau de bord et recommandations.

Le rapport est etabli a partir des etats calcules par le moteur (bilan, compte de resultat, TFT,
tableau de passage) et des alertes. Les appreciations reposent sur des seuils usuels d'analyse
financiere ; ils sont indiques dans le texte pour que le lecteur puisse les discuter."""
import io
import datetime

from .engine import compute as compute_liasse
from . import alertes as alertes_mod
from .nombres import num as _n

BM, CR, TFT = "Bilan modèle 1", "RESULTAT", "TFT"


def _f(v):
    v = int(round(v or 0))
    return f"{v:,d}".replace(",", "\u00a0")


def _p(v, dec=1):
    if v is None:
        return "–"
    t = f"{v * 100:.{dec}f}"
    if float(t) == 0:
        t = t.lstrip("-")
    return t.replace(".", ",") + " %"


def _div(a, b):
    return a / b if b else None


def _var(n, n1):
    if not n1:
        return None
    return (n - n1) / abs(n1)


def donnees(res):
    n = res.num
    D = {}
    for col, suf in (("H", ""), ("I", "_1")):
        g = lambda r: n(CR, f"{col}{r}")
        D["ca" + suf] = g(17)
        D["ventes_march" + suf] = g(10)
        D["achats_march" + suf] = -g(11)
        D["marge_com" + suf] = g(13)
        D["va" + suf] = g(31)
        D["personnel" + suf] = -g(32)
        D["ebe" + suf] = g(33)
        D["dotations" + suf] = -g(35)
        D["rex" + suf] = g(36)
        D["rfin" + suf] = g(42)
        D["rao" + suf] = g(43)
        D["hao" + suf] = g(48)
        D["impot" + suf] = -g(50)
        D["rn" + suf] = g(51)
        D["services_ext" + suf] = -(g(27) + g(28))
        D["autres_achats" + suf] = -(g(23) + g(25))
        D["impots_taxes" + suf] = -g(29)
        D["frais_fin" + suf] = -g(40)
        D["achats_tot" + suf] = -(g(11) + g(23) + g(25) + g(27) + g(28))
    for col, pcol, suf in (("F", "K", ""), ("G", "L", "_1")):
        a = lambda r: n(BM, f"{col}{r}")
        p = lambda r: n(BM, f"{pcol}{r}")
        D["actif_immo" + suf] = a(27)
        D["stocks" + suf] = a(29)
        D["clients" + suf] = a(32)
        D["autres_creances" + suf] = a(33)
        D["actif_circ" + suf] = a(34) + a(28)
        D["treso_actif" + suf] = a(38)
        D["total" + suf] = a(40)
        D["capital" + suf] = p(10)
        D["cp" + suf] = p(22)
        D["dettes_fin" + suf] = p(26)
        D["ress_stables" + suf] = p(27)
        D["fournisseurs" + suf] = p(30)
        D["dettes_fisc" + suf] = p(31)
        D["autres_dettes" + suf] = p(32)
        D["passif_circ" + suf] = p(34) + p(28)
        D["treso_passif" + suf] = p(38)
        D["frng" + suf] = D["ress_stables" + suf] - D["actif_immo" + suf]
        D["bfr" + suf] = D["actif_circ" + suf] - D["passif_circ" + suf]
        D["treso" + suf] = D["treso_actif" + suf] - D["treso_passif" + suf]
    D["caf"] = n(TFT, "H15")
    D["caf_1"] = n(TFT, "I15")
    D["flux_exploit"] = n(TFT, "H21")
    D["flux_invest"] = n(TFT, "H28")
    D["flux_fin"] = n(TFT, "H40")
    D["impot_du"] = max(n("TABLEAU DE PASSAGE", "F53"), n("TABLEAU DE PASSAGE", "F54"))
    D["imf"] = n("TABLEAU DE PASSAGE", "F53")
    D["resultat_fiscal"] = n("TABLEAU DE PASSAGE", "G49") or n("TABLEAU DE PASSAGE", "G50")
    D["deficits"] = n("TRAITEMENT DE DEFICITS", "M18")
    D["ard"] = n("TRAITEMENT DE DEFICITS", "F26")
    D["tap"] = float(res.ev.params.get("tap_total") or 0)
    D["compte_courant"] = n("Balance std", "G355") + n("Balance std", "G354")
    D["attente"] = sum(abs(_n(e.get("sd")) - _n(e.get("sc"))) for e in (res.dossier.get("balance_n") or [])
                       if str(e.get("compte", "")).startswith(("475", "4718", "4719")))
    return D


def ratios(D):
    R = []

    def add(cle, lib, v, v1, fmt, statut, seuil):
        R.append({"cle": cle, "libelle": lib, "n": v, "n1": v1, "fmt": fmt, "statut": statut, "seuil": seuil})

    def st(v, bon, mauvais, sens=1):
        if v is None:
            return "gris"
        if sens * v >= sens * bon:
            return "vert"
        if sens * v <= sens * mauvais:
            return "rouge"
        return "orange"

    va_ca = _div(D["va"], D["ca"])
    add("taux_va", "Taux de valeur ajoutée (VA / CA)", va_ca, _div(D["va_1"], D["ca_1"]), "p", st(va_ca, 0.35, 0.15), "≥ 35 % satisfaisant, < 15 % faible")
    ebe_ca = _div(D["ebe"], D["ca"])
    add("taux_ebe", "Taux de marge brute d'exploitation (EBE / CA)", ebe_ca, _div(D["ebe_1"], D["ca_1"]), "p", st(ebe_ca, 0.10, 0.0), "≥ 10 % satisfaisant, ≤ 0 critique")
    mn = _div(D["rn"], D["ca"])
    add("marge_nette", "Marge nette (résultat net / CA)", mn, _div(D["rn_1"], D["ca_1"]), "p", st(mn, 0.05, 0.0), "≥ 5 % satisfaisant, < 0 perte")
    pers = _div(D["personnel"], D["va"]) if D["va"] > 0 else None
    add("pers_va", "Charges de personnel / valeur ajoutée", pers, _div(D["personnel_1"], D["va_1"]) if D["va_1"] > 0 else None, "p",
        "rouge" if D["va"] <= 0 else st(pers, 0.65, 0.90, -1), "≤ 65 % soutenable, > 90 % l'EBE disparaît")
    auto = _div(D["cp"], D["total"])
    add("autonomie", "Autonomie financière (capitaux propres / total bilan)", auto, _div(D["cp_1"], D["total_1"]), "p", st(auto, 0.30, 0.0), "≥ 30 % solide, < 0 capitaux propres négatifs")
    endt = _div(D["dettes_fin"], D["cp"]) if D["cp"] > 0 else None
    add("endettement", "Endettement financier (dettes financières / capitaux propres)", endt,
        _div(D["dettes_fin_1"], D["cp_1"]) if D["cp_1"] > 0 else None, "x",
        "gris" if endt is None and not D["dettes_fin"] else ("rouge" if D["cp"] <= 0 and D["dettes_fin"] else st(endt, 1.0, 2.0, -1)), "≤ 1 prudent, > 2 excessif")
    liq = _div(D["actif_circ"] + D["treso_actif"], D["passif_circ"] + D["treso_passif"])
    add("liquidite", "Liquidité générale (actif circulant + trésorerie / dettes à court terme)", liq,
        _div(D["actif_circ_1"] + D["treso_actif_1"], D["passif_circ_1"] + D["treso_passif_1"]), "x", st(liq, 1.2, 1.0), "≥ 1,2 confortable, < 1 tension")
    dcl = _div(D["clients"] * 360, D["ca"])
    add("dso", "Délai moyen de recouvrement clients (jours de CA)", dcl, _div(D["clients_1"] * 360, D["ca_1"]), "j", st(dcl, 45, 90, -1), "≤ 45 j bon, > 90 j à surveiller")
    dfo = _div(D["fournisseurs"] * 360, D["achats_tot"])
    add("dpo", "Délai moyen de paiement fournisseurs (jours d'achats)", dfo, _div(D["fournisseurs_1"] * 360, D["achats_tot_1"]), "j",
        st(dfo, 60, 120, -1), "≤ 60 j normal, > 120 j retards de paiement probables")
    add("frng", "Fonds de roulement net global", D["frng"], D["frng_1"], "m", "vert" if D["frng"] >= 0 else "rouge", "positif requis")
    add("bfr", "Besoin en fonds de roulement", D["bfr"], D["bfr_1"], "m", "gris", "à rapprocher du fonds de roulement")
    add("treso", "Trésorerie nette", D["treso"], D["treso_1"], "m", "vert" if D["treso"] > 0 else "rouge", "positive requise")
    add("caf", "Capacité d'autofinancement globale", D["caf"], D["caf_1"], "m", "vert" if D["caf"] > 0 else "rouge", "positive requise")
    rembt = _div(D["dettes_fin"], D["caf"]) if D["caf"] > 0 else None
    if D["dettes_fin"]:
        add("rembt", "Capacité de remboursement (dettes financières / CAF, en années)", rembt, None, "x",
            "rouge" if rembt is None else st(rembt, 3, 5, -1), "≤ 3 ans bon, > 5 ans risqué")
    return R


def analyse(res):
    D = donnees(res)
    R = ratios(D)
    forces, faiblesses, conseils = [], [], []
    ca, ca1 = D["ca"], D["ca_1"]
    vca = _var(ca, ca1)

    # ------------------------------------------------------------ activite
    if vca is not None:
        if vca >= 0.05:
            forces.append(f"Chiffre d'affaires en hausse de {_p(vca)} ({_f(ca1)} → {_f(ca)} F CFA).")
        elif vca <= -0.05:
            faiblesses.append(f"Chiffre d'affaires en baisse de {_p(-vca)} ({_f(ca1)} → {_f(ca)} F CFA).")
            conseils.append(("Relancer l'activité", "Analyser la baisse par client et par prestation, relancer les clients inactifs "
                             "et fixer un objectif de chiffre d'affaires mensuel suivi en réunion de direction."))
        else:
            forces.append(f"Chiffre d'affaires stable ({_f(ca)} F CFA, {'+' if vca >= 0 else ''}{_p(vca)} sur un an).")
    # ------------------------------------------------------------ rentabilite
    if D["ebe"] < 0:
        faiblesses.append(f"Excédent brut d'exploitation négatif ({_f(D['ebe'])} F CFA) : l'activité courante ne couvre pas "
                          "ses propres charges, avant même les amortissements et la fiscalité.")
        conseils.append(("Rétablir l'équilibre d'exploitation",
                         f"Le déficit d'EBE à combler est de {_f(-D['ebe'])} F CFA, soit {_p(_div(-D['ebe'], ca) or 0)} du chiffre d'affaires. "
                         "Deux leviers à chiffrer ensemble : une révision des tarifs (une hausse de "
                         f"{_p(_div(-D['ebe'], ca) or 0)} suffirait à volume constant) et une revue ligne à ligne des achats et services extérieurs."))
    elif _div(D["ebe"], ca) and _div(D["ebe"], ca) >= 0.10:
        forces.append(f"Bonne rentabilité d'exploitation : EBE de {_f(D['ebe'])} F CFA, soit {_p(_div(D['ebe'], ca))} du chiffre d'affaires.")
    if D["rn"] < 0:
        faiblesses.append(f"Exercice déficitaire : perte nette de {_f(-D['rn'])} F CFA"
                          + (f" contre un bénéfice de {_f(D['rn_1'])} F CFA en N-1." if D["rn_1"] > 0 else "."))
    elif D["rn"] > 0:
        forces.append(f"Exercice bénéficiaire : résultat net de {_f(D['rn'])} F CFA ({_p(_div(D['rn'], ca))} du CA).")
    # evolution des charges
    for cle, lib in (("personnel", "charges de personnel"), ("autres_achats", "achats de matières et fournitures"),
                     ("services_ext", "transports et services extérieurs"), ("achats_march", "achats de marchandises")):
        v, v1 = D[cle], D[cle + "_1"]
        vv = _var(v, v1)
        if vv is not None and vv > 0.15 and (vca is None or vv > vca + 0.10) and v - v1 > 0.02 * max(ca, 1):
            faiblesses.append(f"Les {lib} progressent de {_p(vv)} ({_f(v1)} → {_f(v)} F CFA), plus vite que le chiffre d'affaires.")
            if cle == "personnel":
                conseils.append(("Maîtriser la masse salariale",
                                 f"La masse salariale absorbe {_p(_div(v, D['va'])) if D['va'] > 0 else 'plus de 100 %'} de la valeur ajoutée. "
                                 "Rapprocher les effectifs du niveau d'activité, conditionner les primes aux résultats et vérifier les charges "
                                 "sociales (CNSS) sur les bulletins."))
            else:
                conseils.append((f"Revoir les {lib}", "Mettre en concurrence les fournisseurs, regrouper les commandes, "
                                 "suivre la consommation mensuelle et exiger des factures normalisées (factures sans NIF réintégrées fiscalement)."))
    if D["achats_march"] > 0 and D["ventes_march"] == 0:
        faiblesses.append(f"{_f(D['achats_march'])} F CFA d'achats comptabilisés en marchandises (compte 601) sans aucune vente de "
                          "marchandises : la marge commerciale affichée est négative et la valeur ajoutée est mal présentée.")
        conseils.append(("Corriger le classement des achats", "Reclasser les consommables et fournitures dans les comptes 602 à 605 "
                         "(achats de matières et fournitures) : la présentation du compte de résultat en sera plus fidèle."))
    # ------------------------------------------------------------ structure
    if D["cp"] < 0:
        faiblesses.append(f"Capitaux propres négatifs ({_f(D['cp'])} F CFA) pour un capital de {_f(D['capital'])} F CFA : "
                          "les pertes cumulées dépassent les apports.")
        txt = ("L'Acte uniforme relatif aux sociétés commerciales impose, lorsque les capitaux propres deviennent inférieurs à la moitié "
               "du capital, de consulter les associés dans les quatre mois sur la dissolution anticipée puis, à défaut, de reconstituer "
               "les capitaux propres dans les deux exercices suivants (SARL art. 371, SA art. 664).")
        if D["compte_courant"] > 0:
            txt += (f" Le compte courant d'associé de {_f(D['compte_courant'])} F CFA peut être incorporé au capital : cette opération "
                    "reconstitue les fonds propres sans sortie de trésorerie.")
        conseils.append(("Reconstituer les capitaux propres", txt))
    elif D["capital"] and D["cp"] < D["capital"] / 2:
        faiblesses.append(f"Capitaux propres ({_f(D['cp'])}) inférieurs à la moitié du capital social ({_f(D['capital'])}).")
        conseils.append(("Régulariser la situation des capitaux propres", "Consulter les associés sur la poursuite de l'activité et "
                         "prévoir la reconstitution des capitaux propres (AUSCGIE, SARL art. 371, SA art. 664)."))
    elif D["total"] and D["cp"] / D["total"] >= 0.30:
        forces.append(f"Structure financière solide : les capitaux propres financent {_p(D['cp'] / D['total'])} du total du bilan.")
    if D["frng"] < 0:
        faiblesses.append(f"Fonds de roulement négatif ({_f(D['frng'])} F CFA) : une partie des immobilisations est financée "
                          "par des dettes à court terme.")
        conseils.append(("Consolider le financement à long terme", "Adosser les investissements à des ressources durables "
                         "(apports, emprunt à moyen terme, compte courant bloqué) plutôt qu'aux dettes fournisseurs ou fiscales."))
    elif D["frng"] > 0:
        forces.append(f"Fonds de roulement positif ({_f(D['frng'])} F CFA) : les immobilisations sont financées par des ressources stables.")
    if D["treso"] < D["treso_1"] and D["treso_1"] > 0 and (D["treso_1"] - D["treso"]) / D["treso_1"] > 0.3:
        faiblesses.append(f"Trésorerie en forte baisse : {_f(D['treso_1'])} → {_f(D['treso'])} F CFA.")
        conseils.append(("Piloter la trésorerie", "Établir un plan de trésorerie mensuel sur douze mois (encaissements clients, salaires, "
                         "CNSS, ITS, acomptes ISB, fournisseurs) et le mettre à jour chaque mois."))
    elif D["treso"] > 0:
        forces.append(f"Trésorerie positive de {_f(D['treso'])} F CFA à la clôture.")
    # ------------------------------------------------------------ BFR
    dso = _div(D["clients"] * 360, ca)
    if dso and dso > 60:
        faiblesses.append(f"Recouvrement lent : les créances clients représentent {dso:.0f} jours de chiffre d'affaires "
                          f"({_f(D['clients'])} F CFA).")
        conseils.append(("Accélérer le recouvrement", f"Ramener le délai client à 45 jours libérerait environ "
                         f"{_f(max(0, D['clients'] - ca * 45 / 360))} F CFA de trésorerie. Relances écrites à 30 et 45 jours, "
                         "acomptes à la commande, suivi hebdomadaire de la balance âgée."))
    dpo = _div(D["fournisseurs"] * 360, D["achats_tot"])
    if dpo and dpo > 120:
        faiblesses.append(f"Dettes fournisseurs élevées : {dpo:.0f} jours d'achats ({_f(D['fournisseurs'])} F CFA), signe de retards de paiement.")
        conseils.append(("Assainir les dettes fournisseurs", "Négocier un échéancier avec les principaux fournisseurs et "
                         "vérifier les factures non parvenues (compte 408) avant la clôture suivante."))
    if D["dettes_fisc"] > 0.25 * max(D["passif_circ"], 1) and D["dettes_fisc"] > 0.05 * max(ca, 1):
        faiblesses.append(f"Dettes fiscales et sociales importantes ({_f(D['dettes_fisc'])} F CFA) : risque de pénalités et de majorations.")
        conseils.append(("Solder les arriérés fiscaux et sociaux", "Payer en priorité la CNSS et l'ITS retenu sur salaires, "
                         "puis solliciter un moratoire auprès de l'administration pour le reste."))
    # ------------------------------------------------------------ fiscalite
    if D["impot_du"] > 0 and D["rn"] <= 0:
        faiblesses.append(f"Impôt minimum forfaitaire de {_f(D['imf'])} F CFA dû malgré le déficit : l'IMF pèse "
                          f"{_p(_div(D['imf'], ca))} du chiffre d'affaires.")
    if D["deficits"] > 0:
        forces.append(f"Déficit fiscal reportable de {_f(D['deficits'])} F CFA, imputable sur les bénéfices des trois exercices suivants"
                      + (f", et {_f(D['ard'])} F CFA d'amortissements réputés différés reportables sans limite de durée." if D["ard"] else "."))
        conseils.append(("Utiliser les reports fiscaux", "Planifier le retour au bénéfice avant l'expiration du délai de trois ans "
                         "pour imputer le déficit reportable ; conserver le suivi des ARD dans le tableau de passage."))
    if D["attente"] > 0:
        faiblesses.append(f"{_f(D['attente'])} F CFA restent en comptes d'attente ou sur le compte transitoire (475, 4718, 4719).")
        conseils.append(("Apurer les comptes d'attente", "Justifier chaque solde avant l'arrêté des comptes et le reclasser "
                         "au compte définitif : un compte d'attente non soldé fragilise la sincérité du bilan."))
    if D["caf"] > 0:
        forces.append(f"Capacité d'autofinancement positive ({_f(D['caf'])} F CFA) : l'entreprise dégage des ressources internes.")
    elif D["caf"] < 0:
        faiblesses.append(f"Capacité d'autofinancement négative ({_f(D['caf'])} F CFA) : l'exploitation consomme de la trésorerie.")
    # conseils generaux de pilotage
    conseils.append(("Mettre en place un reporting mensuel", "Suivre chaque mois le chiffre d'affaires, l'EBE, la trésorerie, le délai "
                     "client et les dettes fiscales et sociales, avec comparaison au budget et à l'exercice précédent ; le tableau de bord "
                     "de ce rapport peut servir de modèle."))
    return {"D": D, "ratios": R, "forces": forces, "faiblesses": faiblesses, "conseils": conseils}


def score(R):
    pts = {"vert": 2, "orange": 1, "rouge": 0}
    vals = [pts[r["statut"]] for r in R if r["statut"] in pts]
    if not vals:
        return None, ""
    s = sum(vals) / (2 * len(vals))
    lab = "Situation saine" if s >= 0.7 else "Situation fragile" if s >= 0.4 else "Situation préoccupante"
    return s, lab


# ================================================================== PDF
def export_pdf(dossier):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether)
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.graphics.shapes import Drawing, String
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from .pdf import register_fonts
    register_fonts()

    res = compute_liasse(dossier)
    A = analyse(res)
    D, R = A["D"], A["ratios"]
    al = [a for a in alertes_mod.compute(res) if a["niveau"] == "critique" or (
        a["niveau"] == "anomalie" and not any(k in a["titre"].lower() for k in ("attente", "capitaux propres")))]
    ident = dossier.get("identite") or {}
    exo = dossier.get("exercice") or {}
    rap = dossier.get("rapport") or {}
    annee = exo.get("annee") or ""
    NAVY = colors.HexColor("#1d3557")
    ACC = colors.HexColor("#e07a1f")
    GRIS = colors.HexColor("#f0f3f7")
    STAT = {"vert": colors.HexColor("#2e7d4f"), "orange": colors.HexColor("#c77d12"), "rouge": colors.HexColor("#c0392b"),
            "gris": colors.HexColor("#8a94a3")}

    base = ParagraphStyle("b", fontName="LS", fontSize=9.6, leading=13.4, spaceAfter=5, alignment=4)
    h1 = ParagraphStyle("h1", fontName="LS-B", fontSize=14, leading=18, textColor=NAVY, spaceBefore=6, spaceAfter=8)
    h2 = ParagraphStyle("h2", fontName="LS-B", fontSize=11.2, leading=14, textColor=NAVY, spaceBefore=10, spaceAfter=5)
    small = ParagraphStyle("s", fontName="LS", fontSize=8, leading=10, textColor=colors.HexColor("#5f6b7a"))
    cell = ParagraphStyle("c", fontName="LS", fontSize=8.4, leading=10.4)
    cellb = ParagraphStyle("cb", fontName="LS-B", fontSize=8.4, leading=10.4)
    bullet = ParagraphStyle("bu", parent=base, leftIndent=12, bulletIndent=2, spaceAfter=3)

    buf = io.BytesIO()

    def deco(c, doc):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, A4[1] - 14 * mm, A4[0], 14 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("LS-B", 9.5)
        c.drawString(15 * mm, A4[1] - 9 * mm, f"{ident.get('denomination') or ''} – Rapport de gestion financière {annee}")
        c.setFont("LS", 8.5)
        c.drawRightString(A4[0] - 15 * mm, A4[1] - 9 * mm, f"Page {doc.page}")
        c.setFillColor(colors.HexColor("#8a94a3"))
        c.setFont("LS", 7.5)
        c.drawString(15 * mm, 9 * mm, "Document de gestion établi à partir des états financiers de l'exercice – usage interne, non destiné au dépôt DGI.")
        c.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=17 * mm, rightMargin=17 * mm, topMargin=22 * mm, bottomMargin=17 * mm,
                            title=f"Rapport de gestion {ident.get('denomination', '')} {annee}", author=rap.get("signature") or "")
    S = []
    S.append(Paragraph("RAPPORT DE GESTION FINANCIÈRE", ParagraphStyle("t", fontName="LS-B", fontSize=19, leading=24, textColor=NAVY)))
    S.append(Paragraph(f"{ident.get('denomination') or ''} – exercice clos le {_date(exo.get('fin'))}",
                       ParagraphStyle("t2", fontName="LS-B", fontSize=12, leading=16, textColor=ACC, spaceAfter=4)))
    S.append(Paragraph(" · ".join(x for x in (f"NIF {ident['nif']}" if ident.get("nif") else "", ident.get("activite") or "",
                                              ident.get("adresse") or "") if x), small))
    S.append(Spacer(1, 8))
    sc, sclab = score(R)
    # --- synthese
    S.append(Paragraph("1. Synthèse", h1))
    synth = (f"L'exercice {annee} se solde par un {'bénéfice' if D['rn'] >= 0 else 'déficit'} de {_f(abs(D['rn']))} F CFA "
             f"pour un chiffre d'affaires de {_f(D['ca'])} F CFA"
             + (f" ({'+' if D['ca'] >= D['ca_1'] else ''}{_p(_var(D['ca'], D['ca_1']))} par rapport à N-1)" if D["ca_1"] else "") + ". "
             f"L'excédent brut d'exploitation s'établit à {_f(D['ebe'])} F CFA et la trésorerie nette à {_f(D['treso'])} F CFA. "
             f"Les capitaux propres s'élèvent à {_f(D['cp'])} F CFA.")
    S.append(Paragraph(synth, base))
    if sc is not None:
        S.append(Paragraph(f"<b>Appréciation d'ensemble : {sclab}</b> ({round(sc * 100)} / 100 sur {len([r for r in R if r['statut'] != 'gris'])} indicateurs du tableau de bord).", base))
    kt = [["", f"Exercice {annee}", "Exercice N-1", "Variation"]]
    for lib, k in (("Chiffre d'affaires", "ca"), ("Valeur ajoutée", "va"), ("Excédent brut d'exploitation", "ebe"),
                   ("Résultat d'exploitation", "rex"), ("Résultat net", "rn"), ("Capitaux propres", "cp"),
                   ("Trésorerie nette", "treso"), ("Total du bilan", "total")):
        v, v1 = D[k], D[k + "_1"]
        kt.append([lib, _f(v), _f(v1), _p(_var(v, v1)) if v1 else "–"])
    S.append(_table(kt, [70 * mm, 33 * mm, 33 * mm, 30 * mm], NAVY, GRIS))
    S.append(Spacer(1, 6))
    S.append(_chart(D, annee, NAVY, ACC))
    # --- performance
    S.append(Paragraph("2. Performance de l'exercice", h1))
    S.append(Paragraph("Soldes intermédiaires de gestion", h2))
    sig = [["Solde", f"{annee}", "N-1", "% du CA"]]
    for lib, k in (("Chiffre d'affaires", "ca"), ("Marge commerciale", "marge_com"), ("Valeur ajoutée", "va"),
                   ("Charges de personnel", "personnel"), ("Excédent brut d'exploitation", "ebe"), ("Dotations aux amortissements et provisions", "dotations"),
                   ("Résultat d'exploitation", "rex"), ("Résultat financier", "rfin"), ("Résultat des activités ordinaires", "rao"),
                   ("Résultat hors activités ordinaires", "hao"), ("Impôt sur le résultat", "impot"), ("Résultat net", "rn")):
        sig.append([lib, _f(D[k]), _f(D[k + "_1"]), _p(_div(D[k], D["ca"]))])
    S.append(_table(sig, [74 * mm, 32 * mm, 32 * mm, 28 * mm], NAVY, GRIS))
    S.append(Paragraph("Points forts", h2))
    for t in A["forces"] or ["Aucun point fort significatif ne ressort des indicateurs de l'exercice."]:
        S.append(Paragraph(t, bullet, bulletText="•"))
    S.append(Paragraph("Faiblesses et points de vigilance", h2))
    for t in A["faiblesses"] or ["Aucune faiblesse majeure relevée par les indicateurs."]:
        S.append(Paragraph(t, bullet, bulletText="•"))
    # --- structure
    S.append(Paragraph("3. Structure financière et trésorerie", h1))
    eq = [["Équilibre financier", f"{annee}", "N-1"],
          ["Ressources stables", _f(D["ress_stables"]), _f(D["ress_stables_1"])],
          ["– Actif immobilisé net", _f(D["actif_immo"]), _f(D["actif_immo_1"])],
          ["= Fonds de roulement net global", _f(D["frng"]), _f(D["frng_1"])],
          ["Besoin en fonds de roulement", _f(D["bfr"]), _f(D["bfr_1"])],
          ["= Trésorerie nette", _f(D["treso"]), _f(D["treso_1"])],
          ["Capacité d'autofinancement (TFT)", _f(D["caf"]), _f(D["caf_1"])],
          ["Flux de trésorerie opérationnels", _f(D["flux_exploit"]), ""],
          ["Flux d'investissement", _f(D["flux_invest"]), ""],
          ["Flux de financement", _f(D["flux_fin"]), ""]]
    S.append(_table(eq, [90 * mm, 38 * mm, 38 * mm], NAVY, GRIS))
    # --- tableau de bord
    S.append(PageBreak())
    S.append(Paragraph("4. Tableau de bord (reporting)", h1))
    S.append(Paragraph("Indicateurs de pilotage comparés à l'exercice précédent. Le code couleur applique les seuils indiqués en dernière colonne.", base))
    tb = [[Paragraph("<b>Indicateur</b>", cell), Paragraph(f"<b>{annee}</b>", cell), Paragraph("<b>N-1</b>", cell),
           Paragraph("<b>État</b>", cell), Paragraph("<b>Repère</b>", cell)]]
    styl = []
    for i, r in enumerate(R, 1):
        tb.append([Paragraph(r["libelle"], cell), _vfmt(r["n"], r["fmt"]), _vfmt(r["n1"], r["fmt"]),
                   {"vert": "Bon", "orange": "À surveiller", "rouge": "Critique", "gris": "–"}[r["statut"]], Paragraph(r["seuil"], small)])
        styl.append(("TEXTCOLOR", (3, i), (3, i), STAT[r["statut"]]))
        styl.append(("FONTNAME", (3, i), (3, i), "LS-B"))
    t = Table(tb, colWidths=[64 * mm, 25 * mm, 25 * mm, 22 * mm, 40 * mm], repeatRows=1)
    t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), "LS"), ("FONTSIZE", (0, 0), (-1, -1), 8.4),
                           ("BACKGROUND", (0, 0), (-1, 0), GRIS), ("ALIGN", (1, 0), (2, -1), "RIGHT"),
                           ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5dbe3")),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)] + styl))
    S.append(t)
    S.append(Paragraph("Situation fiscale", h2))
    fx = [["Élément", "Montant"],
          ["Résultat fiscal", _f(D["resultat_fiscal"])],
          ["Impôt dû (IMF ou ISB)", _f(D["impot_du"])],
          ["Taxe d'apprentissage", _f(D["tap"])],
          ["Déficits reportables", _f(D["deficits"])],
          ["Amortissements réputés différés", _f(D["ard"])]]
    S.append(_table(fx, [90 * mm, 40 * mm], NAVY, GRIS))
    if al:
        S.append(Paragraph("Anomalies relevées dans le dossier comptable", h2))
        for a in al[:10]:
            S.append(Paragraph(f"<b>{a['titre']}</b> – {a['detail']}", bullet, bulletText="•"))
    # --- recommandations
    head = [Paragraph("5. Recommandations", h1),
            Paragraph("Mesures proposées pour améliorer le résultat et préserver la santé financière, classées par ordre de priorité.", base)]
    for i, (tit, txt) in enumerate(A["conseils"], 1):
        blk = [Paragraph(f"{i}. {tit}", ParagraphStyle("rt", parent=base, fontName="LS-B", textColor=NAVY, spaceAfter=2)),
               Paragraph(txt, base)]
        S.append(KeepTogether(head + blk if i == 1 else blk))
    if (rap.get("commentaire") or "").strip():
        S.append(Paragraph("Observations du consultant", h2))
        for para in rap["commentaire"].split("\n\n"):
            if para.strip():
                S.append(Paragraph(para.strip().replace("\n", "<br/>"), base))
    S.append(Spacer(1, 14))
    lieu = rap.get("lieu") or "Niamey"
    S.append(Paragraph(f"{lieu}, le {datetime.date.today().strftime('%d/%m/%Y')}", ParagraphStyle("d", parent=base, alignment=2)))
    if rap.get("signature"):
        S.append(Paragraph(f"<b>{rap['signature']}</b>", ParagraphStyle("sg", parent=base, alignment=2)))
    doc.build(S, onFirstPage=deco, onLaterPages=deco)
    return buf.getvalue()


def _vfmt(v, fmt):
    if v is None:
        return "–"
    if fmt == "p":
        return _p(v)
    if fmt == "x":
        return f"{v:.2f}".replace(".", ",")
    if fmt == "j":
        return f"{v:.0f} j"
    return _f(v)


def _date(v):
    if isinstance(v, str) and len(v) == 10 and v[4] == "-":
        return f"{v[8:10]}/{v[5:7]}/{v[0:4]}"
    return v or ""


def _table(rows, widths, head, band):
    from reportlab.platypus import Table, TableStyle
    from reportlab.lib import colors
    t = Table(rows, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), "LS"), ("FONTSIZE", (0, 0), (-1, -1), 8.6),
                           ("FONTNAME", (0, 0), (-1, 0), "LS-B"), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("BACKGROUND", (0, 0), (-1, 0), head), ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, band]),
                           ("LINEBELOW", (0, -1), (-1, -1), 0.6, head),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def _chart(D, annee, c1, c2):
    from reportlab.graphics.shapes import Drawing, String, Rect
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    d = Drawing(460, 170)
    bc = VerticalBarChart()
    bc.x, bc.y, bc.width, bc.height = 45, 25, 400, 120
    keys = [("CA", "ca"), ("Valeur ajoutée", "va"), ("EBE", "ebe"), ("Résultat net", "rn"), ("Trésorerie", "treso")]
    bc.data = [[D[k + "_1"] / 1e6 for _, k in keys], [D[k] / 1e6 for _, k in keys]]
    lo = min(0, min(min(x) for x in bc.data))
    hi = max(0.001, max(max(x) for x in bc.data))
    bc.valueAxis.valueMin = lo * 1.15 if lo < 0 else 0
    bc.valueAxis.valueMax = hi * 1.1
    bc.categoryAxis.categoryNames = [l for l, _ in keys]
    bc.categoryAxis.labels.fontName = "LS"
    bc.categoryAxis.labels.fontSize = 8
    bc.valueAxis.labels.fontName = "LS"
    bc.valueAxis.labels.fontSize = 7.5
    bc.categoryAxis.labels.dy = -2
    bc.bars[0].fillColor = c1.clone(alpha=0.35) if hasattr(c1, "clone") else c1
    bc.bars[1].fillColor = c2
    bc.bars.strokeColor = None
    bc.groupSpacing = 12
    bc.barSpacing = 2
    d.add(bc)
    d.add(String(45, 155, "Principaux agrégats (millions F CFA)", fontName="LS-B", fontSize=8.5, fillColor=c1))
    d.add(Rect(300, 152, 8, 8, fillColor=bc.bars[0].fillColor, strokeColor=None))
    d.add(String(311, 153, "N-1", fontName="LS", fontSize=8))
    d.add(Rect(340, 152, 8, 8, fillColor=c2, strokeColor=None))
    d.add(String(351, 153, str(annee), fontName="LS", fontSize=8))
    return d
