"""Assemblage de la liasse : liste ordonnee des pages (grilles) et exports PDF / Excel."""
import io

from .pages import PLAN, PAGES
from .layout import sheet_grid
from . import custom
from .pdf import PdfWriter


def page_grids(res, pid):
    """Renvoie la liste des grilles (une ou plusieurs pages physiques) pour une page du plan."""
    p = PAGES[pid]
    _, sec, title, sheet, area, orient = p
    model = res.model
    if area.startswith("TEXTE:"):
        key = area.split(":", 1)[1]
        if key == "note2":
            return custom.text_note_pages(model, res, sheet, "A1:F7", "note2", "NOTE 2 : INFORMATIONS OBLIGATOIRES (suite)")
        return custom.text_note_pages(model, res, sheet, "A1:I8", key, "NOTE 39 : NOTES SUPPLÉMENTAIRES (suite)")
    if area.startswith("CUSTOM:"):
        key = area.split(":", 1)[1]
        if key == "tcfge":
            return custom.tcfge_pages(res)
        if key == "gardedgi":
            return custom.garde_dgi_pages(res)
        if key.startswith("tap"):
            pages = _cached(res, "tap", lambda: custom.tap_pages(res))
            return [pages[int(key[3]) - 1]]
        if key == "annexe_reglements":
            return custom.annexe_reglements_pages(res)
        if key == "annexe_formation":
            return custom.annexe_formation_pages(res)
        if key == "annexe_amorts":
            if not (res.info.get("immo") or {}).get("annexe"):
                return []
            return custom.annexe_amorts_pages(res)
        return []
    g = sheet_grid(model, res, sheet, area, orient)
    if pid == "couverture":
        _cover_overlay(g)
    if pid == "amorts" and (res.info.get("immo") or {}).get("annexe"):
        g.textboxes.append({"x": 0, "y": sum(g.rows[:-3]), "w": sum(g.cols), "h": 14,
                            "paras": [{"t": "Détail complet : voir le tableau des immobilisations et des amortissements joint en annexe.", "i": True}],
                            "size": 8, "pad": 1, "border": None})
    return [g]


def _cached(res, key, fn):
    cache = res.__dict__.setdefault("_cache", {})
    if key not in cache:
        cache[key] = fn()
    return cache[key]


def _cover_overlay(g):
    # cadre de titre de la couverture (zone de texte du modele d'origine)
    W = sum(g.cols)
    H = sum(g.rows)
    g.textboxes.append({"x": W * 0.08, "y": H * 0.26, "w": W * 0.84, "h": H * 0.2,
                        "paras": [{"t": "SUPPORT NORMALISÉ DE COLLECTE DES", "k": 1.0},
                                  {"t": "ÉTATS FINANCIERS DU SYSTÈME COMPTABLE OHADA", "k": 1.0},
                                  {"t": "(SYSCOHADA)", "k": 1.0}],
                        "size": 15, "pad": 12, "gap": 8, "border": 1.2, "align": "center", "bg": "F2F2F2",
                        "valign": "center"})


def exclusions_auto(res):
    """Pages retirees d'office : second modele de bilan (le bilan n'est imprime qu'une fois)."""
    opts = res.dossier.get("options") or {}
    return {"bilan1"} if opts.get("bilan_format") == "deux_pages" else {"actif", "passif"}


def included_pages(res, selection=None):
    """Pages retenues : toutes par defaut, ou selection explicite, en retirant les annexes sans objet."""
    ids = [p[0] for p in PLAN]
    opts = res.dossier.get("options") or {}
    excl = set(opts.get("pages_exclues") or [])
    forcees = set(opts.get("pages_forcees") or [])
    unique = bool(selection) and len(selection) == 1   # apercu d'une seule page : on l'affiche toujours
    # bilan imprime une seule fois : modele paysage (1 page) par defaut, ou actif + passif (2 pages)
    if not unique:
        excl.update(exclusions_auto(res))
    # notes annexes non chiffrees : non imprimees, cochees N/A en fiche R4
    if not opts.get("imprimer_notes_vides") and not unique:
        from .notes_na import non_chiffrees
        excl.update(non_chiffrees(res))
    excl -= forcees
    if selection:
        ids = [i for i in ids if i in selection]
    return [i for i in ids if i not in excl]


def all_grids(res, selection=None):
    out = []
    for pid in included_pages(res, selection):
        for g in page_grids(res, pid):
            out.append((pid, g))
    return out


def count_and_grids(res, selection=None):
    """Deux passes : la page de garde indique le nombre de pages deposees."""
    grids = all_grids(res, selection)
    res.ev.params["nb_pages"] = len(grids)
    res.ev.reset_cache()
    return [(pid, page_grids(res, pid)[0]) if pid == "garde" else (pid, g) for pid, g in grids]


def export_pdf(res, selection=None):
    ident = res.dossier.get("identite", {})
    exo = res.dossier.get("exercice", {})
    buf = io.BytesIO()
    w = PdfWriter(buf, title=f"Liasse SYSCOHADA {ident.get('denomination', '')} {exo.get('annee', '')}",
                  author=ident.get("comptable") or "")
    grids = count_and_grids(res, selection)
    for pid, g in grids:
        w.add_grid(g)
    w.save()
    return buf.getvalue(), len(grids)
