"""Rapport de conformite d'une liasse importee (PDF A4)."""
import datetime
import io
import re

from .import_liasse import verifier
from .engine import compute
from .rapport import _f

NIV_LIB = {"critique": "Critique", "anomalie": "Anomalie", "manquement": "Manquement", "imperfection": "À vérifier"}


def recommandations(v):
    """Actions correctives deduites des constats, par ordre de priorite."""
    R = []
    ko = [c for c in v["controles"] if not c["ok"]]
    libs = " ".join(c["libelle"] for c in ko)
    if any(c["niveau"] == "critique" for c in ko):
        R.append(("Rétablir l'équilibre des états avant tout dépôt",
                  "Un bilan déséquilibré, un résultat différent entre bilan et compte de résultat ou une trésorerie du TFT "
                  "non raccordée au bilan rendent la liasse irrecevable. Reprendre la balance dans l'application : les "
                  "états sont alors régénérés de façon cohérente."))
    if "valeur nette négative" in libs:
        R.append(("Corriger les immobilisations à valeur nette négative",
                  "Des amortissements supérieurs à la valeur brute traduisent en général un bien mal classé (brut porté "
                  "sur un autre poste que ses amortissements), un bien sorti de l'actif sans solde de ses amortissements, "
                  "ou une dotation excessive. Rapprocher les comptes 2 et 28 poste par poste avec le tableau "
                  "d'amortissement, puis corriger la note 3A/3C."))
    if "Sous-total" in libs or "brut − amortissements" in libs:
        R.append(("Revoir les sous-totaux signalés",
                  "Les totaux saisis ou calculés dans le fichier ne correspondent pas à la somme de leurs composantes. "
                  "Dans une liasse établie par l'application, ces totaux sont recalculés automatiquement."))
    if "TFT" in libs or any(e["section"].startswith("Tableau des flux") for e in v["ecarts"]):
        R.append(("Refaire le tableau des flux de trésorerie",
                  "Le TFT doit se raccorder à la trésorerie du bilan d'ouverture (ZA) et de clôture (ZH), et la colonne N-1 "
                  "doit reprendre à l'identique le TFT de l'exercice précédent. Vérifier en particulier les acquisitions "
                  "et cessions d'immobilisations, les emprunts et les dividendes."))
    if any(e["section"].startswith("Tableau de passage") for e in v["ecarts"]):
        R.append(("Arrêter l'impôt sur le résultat recalculé",
                  "L'impôt dû est le plus élevé de l'ISB (30 % du bénéfice fiscal, CGI art. 27) et de l'impôt minimum "
                  "forfaitaire assis sur le chiffre d'affaires. Contrôler la base, le taux d'IMF applicable à l'activité "
                  "et l'imputation des acomptes et précomptes (quittances et attestations à l'appui)."))
    if "reliquat négatif" in libs:
        R.append(("Justifier l'excédent de versement",
                  "Les acomptes et précomptes excèdent l'impôt dû : l'excédent constitue un crédit d'impôt à reporter sur "
                  "les acomptes suivants ou à faire restituer. Conserver les quittances et les attestations de retenue."))
    if "Capitaux propres" in libs:
        R.append(("Régulariser la situation des capitaux propres",
                  "Les capitaux propres sont inférieurs à la moitié du capital social. Les associés doivent être consultés "
                  "sur la poursuite de l'activité dans les quatre mois de l'approbation des comptes et la décision publiée "
                  "(AUSCGIE, art. 371 pour les SARL, art. 664 pour les SA)."))
    if v.get("conflits"):
        R.append(("Harmoniser les pages du dossier",
                  "Un même poste présente des montants différents d'une page à l'autre (bilan paysage et bilan détaillé, "
                  "par exemple). Une seule valeur doit figurer dans toute la liasse."))
    crit = [a for a in v["alertes"] if a["niveau"] in ("critique", "manquement")]
    if crit:
        R.append(("Compléter les informations obligatoires",
                  "Renseigner les mentions manquantes relevées par les contrôles du dossier (identification, dirigeants, "
                  "dates, acomptes), puis relancer la vérification."))
    R.append(("Rééditer la liasse corrigée",
              "Après corrections dans l'application, relancer la vérification, puis exporter la liasse en PDF ou Excel. "
              "Le rapport de gestion financière peut être produit sur la même base."))
    return R


def export_pdf(dossier):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from .pdf import register_fonts
    register_fonts()

    res = compute(dossier)
    v = verifier(dossier, res)
    ident = dossier.get("identite") or {}
    exo = dossier.get("exercice") or {}
    rap = dossier.get("rapport") or {}
    NAVY = colors.HexColor("#1d3557")
    ACC = colors.HexColor("#e07a1f")
    GRIS = colors.HexColor("#f0f3f7")
    LIGNE = colors.HexColor("#d5dbe3")
    COUL = {"critique": colors.HexColor("#c0392b"), "anomalie": colors.HexColor("#c77d12"),
            "manquement": colors.HexColor("#7b4fa0"), "imperfection": colors.HexColor("#5f6b7a"),
            "ok": colors.HexColor("#2e7d4f")}
    VERD = {"conforme": COUL["ok"], "conforme avec réserves": COUL["anomalie"], "non conforme": COUL["critique"]}

    base = ParagraphStyle("b", fontName="LS", fontSize=9.4, leading=13, spaceAfter=5, alignment=4)
    h1 = ParagraphStyle("h1", fontName="LS-B", fontSize=13, leading=17, textColor=NAVY, spaceBefore=10, spaceAfter=6)
    small = ParagraphStyle("s", fontName="LS", fontSize=7.8, leading=9.6, textColor=colors.HexColor("#5f6b7a"))
    cell = ParagraphStyle("c", fontName="LS", fontSize=8, leading=9.8)
    cellb = ParagraphStyle("cb", fontName="LS-B", fontSize=8, leading=9.8)

    def tbl(rows, widths, extra=()):
        t = Table(rows, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), "LS"), ("FONTSIZE", (0, 0), (-1, -1), 8),
                               ("BACKGROUND", (0, 0), (-1, 0), GRIS), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                               ("LINEBELOW", (0, 0), (-1, -1), 0.3, LIGNE),
                               ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)] + list(extra)))
        return t

    buf = io.BytesIO()
    annee = exo.get("annee") or ""

    def deco(c, doc):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, A4[1] - 14 * mm, A4[0], 14 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("LS-B", 9.5)
        c.drawString(15 * mm, A4[1] - 9 * mm, f"{ident.get('denomination') or ''} – Conformité de la liasse {annee}")
        c.setFont("LS", 8.5)
        c.drawRightString(A4[0] - 15 * mm, A4[1] - 9 * mm, f"Page {doc.page}")
        c.setFillColor(colors.HexColor("#8a94a3"))
        c.setFont("LS", 7.3)
        c.drawString(15 * mm, 9 * mm, "Contrôle établi à partir du fichier importé et du recalcul SYSCOHADA révisé (système normal) – DGI Niger.")
        c.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=21 * mm, bottomMargin=16 * mm,
                            title=f"Rapport de conformité {ident.get('denomination', '')} {annee}",
                            author=rap.get("signature") or "G.H. Liman")
    W = A4[0] - 30 * mm
    S = []
    S.append(Paragraph("RAPPORT DE CONFORMITÉ DE LA LIASSE FISCALE", ParagraphStyle("t", fontName="LS-B", fontSize=17, leading=22, textColor=NAVY)))
    fin = str(exo.get("fin") or "")
    fin_txt = f"{fin[8:10]}/{fin[5:7]}/{fin[:4]}" if re.fullmatch(r"\d{4}-\d{2}-\d{2}", fin[:10]) else fin
    S.append(Paragraph(f"{ident.get('denomination') or ''} – exercice clos le {fin_txt}",
                       ParagraphStyle("t2", fontName="LS-B", fontSize=11.5, leading=15, textColor=ACC, spaceAfter=3)))
    S.append(Paragraph(" · ".join(x for x in (f"NIF {ident['nif']}" if ident.get("nif") else "", ident.get("adresse") or "") if x), small))
    S.append(Spacer(1, 6))
    info = [["Fichier contrôlé", v.get("fichier") or "–"], ["Mode de lecture", v.get("mode") or "–"],
            ["Date d'import", v.get("date") or "–"], ["Postes lus", str(v.get("nb_codes") or 0)],
            ["Date du rapport", datetime.date.today().strftime("%d/%m/%Y")]]
    t = Table([[Paragraph(f"<b>{a}</b>", cell), Paragraph(str(b), cell)] for a, b in info], colWidths=[40 * mm, W - 40 * mm])
    t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.3, LIGNE), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    S.append(t)

    ko = [c for c in v["controles"] if not c["ok"]]
    nb = {k: sum(1 for c in ko if c["niveau"] == k) for k in NIV_LIB}
    nal = {k: sum(1 for a in v["alertes"] if a["niveau"] == k) for k in NIV_LIB}
    S.append(Paragraph("1. Conclusion", h1))
    box = Table([[Paragraph(f"<font color='{VERD[v['verdict']].hexval().replace('0x', '#')}'><b>LIASSE {v['verdict'].upper()}</b></font>",
                            ParagraphStyle("vd", fontName="LS-B", fontSize=12.5, leading=16)),
                  Paragraph(v["commentaire"], cell)]], colWidths=[62 * mm, W - 62 * mm])
    box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1, VERD[v["verdict"]]), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                             ("BACKGROUND", (0, 0), (0, 0), GRIS), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    S.append(box)
    S.append(Spacer(1, 5))
    synth = [["", "Critique", "Anomalie", "Manquement", "À vérifier"],
             ["Contrôles arithmétiques de la liasse déposée"] + [str(nb[k]) for k in NIV_LIB],
             ["Contrôles du dossier recalculé"] + [str(nal[k]) for k in NIV_LIB]]
    S.append(tbl(synth, [78 * mm] + [(W - 78 * mm) / 4] * 4, [("ALIGN", (1, 0), (-1, -1), "CENTER"), ("FONTNAME", (0, 0), (-1, 0), "LS-B")]))
    S.append(Paragraph(f"Contrôles arithmétiques satisfaits : {len(v['controles']) - len(ko)} sur {len(v['controles'])}. "
                       f"Écarts entre la liasse déposée et le recalcul : {len(v['ecarts'])}. "
                       f"Incohérences entre pages : {len(v.get('conflits') or [])}.", base))

    # --- controles
    S.append(Paragraph("2. Contrôles arithmétiques de la liasse déposée", h1))
    S.append(Paragraph("Équilibres, sous-totaux, raccordements entre états et contrôles du calcul de l'impôt, "
                       "effectués sur les montants tels qu'ils figurent dans le fichier.", base))
    rows = [[Paragraph("<b>Contrôle</b>", cell), Paragraph("<b>Montant</b>", cell), Paragraph("<b>Attendu</b>", cell),
             Paragraph("<b>Écart</b>", cell), Paragraph("<b>Résultat</b>", cell)]]
    ex = []
    ordre = sorted(v["controles"], key=lambda c: (c["ok"], list(NIV_LIB).index(c["niveau"])))
    for i, c in enumerate(ordre, 1):
        rows.append([Paragraph(c["libelle"], cell), _f(c["a"]), _f(c["b"]), _f(c["ecart"]) if not c["ok"] else "",
                     "Conforme" if c["ok"] else NIV_LIB[c["niveau"]]])
        ex.append(("TEXTCOLOR", (4, i), (4, i), COUL["ok"] if c["ok"] else COUL[c["niveau"]]))
        ex.append(("FONTNAME", (4, i), (4, i), "LS-B"))
    S.append(tbl(rows, [W - 110 * mm, 27 * mm, 27 * mm, 26 * mm, 30 * mm], [("ALIGN", (1, 1), (3, -1), "RIGHT")] + ex))

    # --- ecarts
    S.append(Paragraph("3. Écarts entre la liasse déposée et le recalcul", h1))
    if v["ecarts"]:
        S.append(Paragraph("Chaque poste a été recalculé par l'application à partir des données reprises (balance, saisies, "
                           "paramètres fiscaux). Un écart signale une formule erronée, une saisie manuelle non justifiée "
                           "ou une incohérence du fichier d'origine.", base))
        rows = [[Paragraph(f"<b>{h}</b>", cell) for h in ("État", "Réf.", "Poste", "Colonne", "Déclaré", "Recalculé", "Écart")]]
        for e in v["ecarts"]:
            rows.append([Paragraph(e["section"], cell), e["code"], Paragraph(e["libelle"] or "", cell), Paragraph(e["colonne"], cell),
                         _f(e["declare"]), _f(e["recalcule"]), _f(e["ecart"])])
        S.append(tbl(rows, [30 * mm, 11 * mm, W - 139 * mm, 20 * mm, 26 * mm, 26 * mm, 26 * mm], [("ALIGN", (4, 1), (-1, -1), "RIGHT")]))
    else:
        S.append(Paragraph("Aucun écart : les montants déclarés sont identiques au recalcul de l'application.", base))
    if v.get("conflits"):
        S.append(Paragraph("Incohérences entre pages", ParagraphStyle("h2", parent=h1, fontSize=10.5, spaceBefore=6)))
        rows = [[Paragraph(f"<b>{h}</b>", cell) for h in ("Réf.", "Page", "Montants", "Autre page", "Montants")]]
        for c in v["conflits"][:25]:
            rows.append([c["code"], c["page1"], Paragraph(" / ".join(_f(x) for x in c["valeurs1"]), cell), c["page2"],
                         Paragraph(" / ".join(_f(x) for x in c["valeurs2"]), cell)])
        S.append(tbl(rows, [12 * mm, 22 * mm, (W - 56 * mm) / 2, 22 * mm, (W - 56 * mm) / 2]))

    # --- alertes du dossier
    S.append(Paragraph("4. Contrôles du dossier et mentions obligatoires", h1))
    al = v["alertes"]
    if al:
        rows = [[Paragraph("<b>Niveau</b>", cell), Paragraph("<b>Constat</b>", cell)]]
        ex = []
        for i, a in enumerate(al[:45], 1):
            rows.append([NIV_LIB[a["niveau"]], Paragraph(f"<b>{a['titre']}</b>" + (f" – {a['detail']}" if a["detail"] else ""), cell)])
            ex += [("TEXTCOLOR", (0, i), (0, i), COUL[a["niveau"]]), ("FONTNAME", (0, i), (0, i), "LS-B")]
        S.append(tbl(rows, [24 * mm, W - 24 * mm], ex))
        if len(al) > 45:
            S.append(Paragraph(f"… et {len(al) - 45} autre(s) constat(s), consultables dans l'application.", small))
    else:
        S.append(Paragraph("Aucune alerte.", base))
    if v.get("notes"):
        S.append(Paragraph("Conditions de reprise du fichier", ParagraphStyle("h2", parent=h1, fontSize=10.5, spaceBefore=6)))
        for n in v["notes"]:
            S.append(Paragraph(n, ParagraphStyle("bu", parent=base, leftIndent=10, bulletIndent=1), bulletText="•"))

    # --- recommandations
    blocs = [Paragraph("5. Actions correctives recommandées", h1)]
    for i, (tit, txt) in enumerate(recommandations(v), 1):
        blk = [Paragraph(f"{i}. {tit}", ParagraphStyle("rt", parent=base, fontName="LS-B", textColor=NAVY, spaceAfter=1)),
               Paragraph(txt, base)]
        S.append(KeepTogether(blocs + blk if i == 1 else blk))
    S.append(Spacer(1, 10))
    lieu = rap.get("lieu") or "Niamey"
    S.append(Paragraph(f"{lieu}, le {datetime.date.today().strftime('%d/%m/%Y')}", ParagraphStyle("d", parent=base, alignment=2)))
    S.append(Paragraph(f"<b>{rap.get('signature') or 'G.H. Liman'}</b>", ParagraphStyle("sg", parent=base, alignment=2)))
    doc.build(S, onFirstPage=deco, onLaterPages=deco)
    return buf.getvalue()
