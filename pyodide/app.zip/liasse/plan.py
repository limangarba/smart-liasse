"""Affectation des comptes aux postes de la liasse (SYSCOHADA revise, systeme normal).

- attendu(compte, sens) : poste du bilan ou du compte de resultat prevu par le plan de comptes
  pour un compte et le sens de son solde (D = debiteur, C = crediteur) ;
- sensibilite(model) : poste effectivement alimente par chaque ligne de la balance standard du
  modele, au debit et au credit (mesure par calcul, une fois par session) ;
- libelles des postes.
Ces deux vues permettent de verifier chaque affectation et de signaler les ecarts."""
import re

BM, CR, BAL = "Bilan modèle 1", "RESULTAT", "Balance std"
TOTAUX = {"AD", "AI", "AQ", "AZ", "BG", "BK", "BT", "BZ", "CP", "DD", "DF", "DP", "DT", "DZ", "CJ"}

_CR = {'601': 'RA', '6031': 'RB', '602': 'RC', '6032': 'RD', '604': 'RE', '605': 'RE', '606': 'RE', '608': 'RE',
       '6033': 'RF', '61': 'RG', '62': 'RH', '63': 'RH', '64': 'RI', '65': 'RJ', '66': 'RK', '681': 'RL', '691': 'RL',
       '67': 'RM', '697': 'RN', '68': 'RL', '69': 'RN', '701': 'TA', '702': 'TB', '703': 'TB', '704': 'TB',
       '705': 'TC', '706': 'TC', '707': 'TD', '73': 'TE', '72': 'TF', '71': 'TG', '75': 'TH', '781': 'TI',
       '791': 'TJ', '798': 'TJ', '799': 'TJ', '797': 'TL', '787': 'TM', '77': 'TK', '78': 'TI', '79': 'TJ',
       '81': 'RO', '82': 'TN', '83': 'RP', '85': 'RP', '84': 'TO', '86': 'TO', '88': 'TO', '87': 'RQ', '89': 'RS'}


def attendu(a, side):
    """Poste attendu pour le compte `a` (chiffres) selon le sens de son solde."""
    a = re.sub(r"\D", "", str(a or ""))
    if not a:
        return None
    P = lambda *ps: any(a.startswith(p) for p in ps)
    if P('28', '29'):
        if P('296'):
            return 'AR'
        if P('297'):
            return 'AS'
        if P('295'):
            return 'AP'
        if P('2939') or P('2839'):
            return 'AK'
        return attendu('2' + a[2:], 'D')
    if P('211', '2181', '2191'):
        return 'AE'
    if P('212', '213', '214', '2193'):
        return 'AF'
    if P('215', '216'):
        return 'AG'
    if P('217', '218', '219'):
        return 'AH'
    if P('22'):
        return 'AJ'
    if P('231', '232', '233', '237', '2391', '239'):
        return 'AK' if not P('2392', '2393', '2394', '2395', '2398') else 'AL'
    if P('234', '235', '238'):
        return 'AL'
    if P('245', '2495'):
        return 'AN'
    if P('24'):
        return 'AM'
    if P('25'):
        return 'AP'
    if P('26'):
        return 'AR'
    if P('27'):
        return 'AS'
    if P('101', '102', '103', '104'):
        return 'CA'
    if P('109'):
        return 'CB'
    if P('105'):
        return 'CD'
    if P('106'):
        return 'CE'
    if P('111', '112', '113'):
        return 'CF'
    if P('118'):
        return 'CG'
    if P('12', '13'):
        return 'CH'   # le resultat N-1 non affecte (13) est presente en report a nouveau
    if P('14'):
        return 'CL'
    if P('15'):
        return 'CM'
    if P('16', '18'):
        return 'DA'
    if P('17'):
        return 'DB'
    if P('19'):
        return 'DC'
    if P('3'):
        return 'BB'
    if P('485', '488'):
        return 'BA' if side == 'D' else 'DH'
    if P('498'):
        return 'BA'
    if P('481', '482', '483', '484', '486', '487'):
        return 'DH' if side == 'C' else 'BA'
    if P('499', '599'):
        return 'DN'
    if P('490'):
        return 'BH'
    if P('491'):
        return 'BI'
    if P('49'):
        return 'BJ'
    if P('409'):
        return 'BH' if side == 'D' else 'DJ'
    if P('40'):
        return 'DJ' if side == 'C' else 'BH'
    if P('419'):
        return 'DI' if side == 'C' else 'BI'
    if P('41'):
        return 'BI' if side == 'D' else 'DI'
    if P('42', '43', '44'):
        return 'BJ' if side == 'D' else 'DK'
    if P('478'):
        return 'BU'
    if P('479'):
        return 'DV'
    if P('45', '46', '47'):
        return 'BJ' if side == 'D' else 'DM'
    if P('50', '590'):
        return 'BQ'
    if P('51', '591'):
        return 'BR'
    if P('564', '565'):
        return 'DQ' if side == 'C' else 'BS'
    if P('561', '566'):
        return 'DR' if side == 'C' else 'BS'
    if P('59'):
        return 'BS'
    if P('5'):
        return 'BS' if side == 'D' else 'DR'
    for L in (4, 3, 2):
        if a[:L] in _CR:
            return _CR[a[:L]]
    if P('603'):
        return 'RB'
    if P('60'):
        return 'RE'
    return None


_SENS = None
_LIB = None


def codes(model):
    out = {}
    for (s, a), v in model.consts.items():
        if isinstance(v, str) and re.fullmatch(r'[A-Z]{2}', v.strip()) and s in (BM, CR):
            r, c = int(a[1:]), a[0]
            if s == CR:
                out[v.strip()] = (CR, [f"H{r}"], "A", r)
            elif c == 'A':
                out[v.strip()] = (BM, [f"D{r}", f"E{r}"], "A", r)
            else:
                out[v.strip()] = (BM, [f"K{r}"], "H", r)
    return out


def libelles(model):
    global _LIB
    if _LIB is None:
        _LIB = {}
        for code, (sh, cols, colcode, r) in codes(model).items():
            start = "ABCDEFGHIJ".index(colcode) + 1
            for c in "ABCDEFGHIJ"[start:start + 3]:
                t = model.consts.get((sh, f"{c}{r}"))
                if isinstance(t, str) and len(t.strip()) > 3:
                    _LIB[code] = re.sub(r"\s+", " ", t.strip())
                    break
    return _LIB


def sensibilite(model):
    """ligne de la balance standard -> {'D': [postes], 'C': [postes]} effectivement alimentes."""
    global _SENS
    if _SENS is not None:
        return _SENS
    from .formula import Evaluator
    from .engine import DEFAULT_PARAMS
    ev = Evaluator(dict(model.consts), dict(model.formulas))
    ev.params = dict(DEFAULT_PARAMS)
    C = codes(model)
    detail = [c for c in C if not c.startswith('X') and c not in TOTAUX]

    def num(sh, a):
        try:
            return float(ev.get(sh, a) or 0)
        except (TypeError, ValueError):
            return 0.0

    def snap():
        return {c: sum(num(C[c][0], x) for x in C[c][1]) for c in detail}
    base = snap()
    out = {}
    for row, acct, lib, code in model.leaf_info:
        res = {}
        for side, col in (('D', 'F'), ('C', 'G')):
            ev.set(BAL, f"{col}{row}", 1000.0)
            ev.reset_cache()
            s = snap()
            res[side] = sorted(c for c in detail if abs(s[c] - base[c]) > 0.5)
            ev.set(BAL, f"{col}{row}", None)
        out[row] = res
    ev.reset_cache()
    _SENS = out
    return out


def affectations(dossier, keys=("balance_n", "balance_n1")):
    """Pour chaque compte de la balance : ligne du plan, poste retenu, poste attendu et statut."""
    from .model import get_model
    from .engine import Mapper
    from .nombres import num as _n
    model = get_model()
    mapper = Mapper(model, dossier.get("mapping"))
    info = {r: (acct, lib) for r, acct, lib, code in model.leaf_info}
    sens = sensibilite(model)
    libs = libelles(model)
    out = []
    for key in keys:
        for e in dossier.get(key) or []:
            solde = _n(e.get("sd")) - _n(e.get("sc"))
            row, how = mapper.row_for(e.get("compte", ""), solde)
            acct, lib = info.get(row, ("", "")) if row else ("", "")
            side = "C" if solde < 0 else "D"
            sr = sens.get(row) or {}
            eff = sr.get(side) or []
            inverse = False
            if not eff:
                other = sr.get("C" if side == "D" else "D") or []
                eff, inverse = other, bool(other)
            poste = eff[0] if eff else ""
            att = attendu(e.get("compte", ""), side) or ""
            if not row:
                statut = "non ventilé"
            elif att and poste and att != poste:
                statut = "à vérifier"
            elif inverse and abs(solde) > 0.5:
                statut = "solde inversé"
            else:
                statut = "conforme"
            out.append({"source": "N" if key == "balance_n" else "N-1", "compte": e.get("compte", ""),
                        "intitule": e.get("intitule", ""), "sd": e.get("sd", 0), "sc": e.get("sc", 0), "solde": solde,
                        "ligne": row, "compte_std": acct, "libelle_std": lib, "poste": poste,
                        "poste_lib": libs.get(poste, ""), "attendu": att, "attendu_lib": libs.get(att, ""),
                        "statut": statut, "mode": how})
    return out
