"""Alertes : anomalies, incoherences, imperfections et manquements detectes sur le dossier.

Niveaux : critique (bloque un depot recevable), anomalie (incoherence chiffree),
manquement (information obligatoire absente), imperfection (a verifier ou a completer)."""
import re

from .engine import run_checks
from .nombres import num as _n
from . import reglements

BM = "Bilan modèle 1"


def _acc(entries, prefixes, sens=None):
    """Comptes de la balance commencant par un prefixe ; sens 'D' ou 'C' filtre les soldes."""
    out = []
    for e in entries or []:
        a = re.sub(r"\D", "", str(e.get("compte", "")))
        if any(a.startswith(p) for p in prefixes):
            s = _n(e.get("sd")) - _n(e.get("sc"))
            if sens == "D" and s <= 0.5:
                continue
            if sens == "C" and s >= -0.5:
                continue
            if sens is None and abs(s) <= 0.5:
                continue
            out.append((a, e.get("intitule", ""), s))
    return out


def _fmt(v):
    return f"{v:,.0f}".replace(",", " ")


def _liste(items, n=4):
    txt = ", ".join(f"{a} ({_fmt(s)})" for a, _, s in items[:n])
    return txt + (f" et {len(items) - n} autre(s)" if len(items) > n else "")


def compute(res):
    d = res.dossier
    num = res.num
    A = []

    def add(niveau, titre, detail="", vue=""):
        A.append({"niveau": niveau, "titre": titre, "detail": detail, "vue": vue})

    ident = d.get("identite") or {}
    exo = d.get("exercice") or {}
    bal = d.get("balance_n") or []
    bal1 = d.get("balance_n1") or []

    # ------------------------------------------------------------ critiques
    if not bal:
        add("critique", "Balance N absente", "Aucune donnée comptable : la liasse sera vide.", "balance_n")
    tot = res.info.get("totaux", {})
    for lab, vue in (("N", "balance_n"), ("N-1", "balance_n1")):
        if lab in tot and abs(tot[lab][0] - tot[lab][1]) >= 1:
            add("critique", f"Balance {lab} déséquilibrée",
                f"Débit {_fmt(tot[lab][0])} – crédit {_fmt(tot[lab][1])} : écart {_fmt(tot[lab][0] - tot[lab][1])}.", vue)
    if bal and abs(num(BM, "F40") - num(BM, "K40")) >= 1:
        add("critique", "Bilan N déséquilibré", f"Actif {_fmt(num(BM, 'F40'))} / passif {_fmt(num(BM, 'K40'))}.", "controles")
    if bal1 and abs(num(BM, "G40") - num(BM, "L40")) >= 1:
        add("critique", "Bilan N-1 déséquilibré", f"Actif {_fmt(num(BM, 'G40'))} / passif {_fmt(num(BM, 'L40'))}.", "controles")
    nv = res.info.get("non_ventiles") or []
    if nv:
        add("critique", f"{len(nv)} compte(s) non ventilé(s)", "Ces soldes n'apparaissent dans aucun état : "
            + ", ".join(f"{x[1]} ({_fmt(x[3])})" for x in nv[:5]), "ventilation")
    if bal and abs(num("TFT", "H42") - (num(BM, "F38") - num(BM, "K38"))) >= 1:
        add("critique", "Tableau des flux de trésorerie non équilibré",
            f"Trésorerie de clôture du TFT {_fmt(num('TFT', 'H42'))} ≠ trésorerie du bilan {_fmt(num(BM, 'F38') - num(BM, 'K38'))}. "
            "Vérifier les acquisitions/cessions, les emprunts et les mouvements de capitaux propres.", "pages")
    for k, lab in (("nif", "NIF"), ("denomination", "dénomination sociale")):
        if not (ident.get(k) or "").strip():
            add("critique", f"{lab.capitalize()} non renseigné(e)", "Mention obligatoire de la page de garde et de chaque page.", "societe")
    if not exo.get("fin"):
        add("critique", "Date de clôture de l'exercice non renseignée", "", "societe")

    # ------------------------------------------------------------ anomalies
    for c in run_checks(res):
        lib, a, b, ok = c
        if ok or lib.startswith(("Balance", "Bilan N", "Comptes de la balance", "TFT : trésorerie nette")):
            continue
        add("anomalie", lib, f"Valeur {_fmt(a)} – attendu {_fmt(b)} (écart {_fmt(a - b)}).", "controles")
    if bal:
        x = _acc(bal, ["57"], "C")
        if x:
            add("anomalie", "Caisse créditrice", "Une caisse ne peut présenter un solde créditeur : " + _liste(x), "balance_n")
        x = _acc(bal, ["3"], "C")
        if x:
            add("anomalie", "Stock à solde créditeur", _liste(x), "balance_n")
        x = _acc(bal, ["28", "29", "39", "49", "59"], "D")
        if x:
            add("anomalie", "Amortissements ou dépréciations à solde débiteur", _liste(x), "balance_n")
        for code, lib in (("AE", 11), ("AF", 12), ("AG", 13), ("AH", 14), ("AJ", 16), ("AK", 18), ("AL", 20), ("AM", 21), ("AN", 22)):
            if num(BM, f"F{lib}") < -0.5:
                add("anomalie", f"Valeur nette négative au bilan (poste {code})",
                    "Les amortissements dépassent la valeur brute : vérifier les comptes 2 et 28.", "pages")
        x = _acc(bal, ["58"])
        if x:
            add("anomalie", "Virements internes (58) non soldés", "Le compte de virement de fonds doit être soldé à la clôture : " + _liste(x), "balance_n")
        x = _acc(bal, ["475", "4718", "4719"])
        if x:
            add("anomalie", "Comptes d'attente ou compte transitoire non soldés (475, 4718, 4719)",
                "À analyser et reclasser avant la clôture : " + _liste(x), "balance_n")
        x = _acc(bal, ["401", "402", "408"], "D")
        if x:
            add("imperfection", "Fournisseurs à solde débiteur", "Classés en « Fournisseurs, avances versées » : " + _liste(x), "balance_n")
        x = _acc(bal, ["411", "412", "418"], "C")
        if x:
            add("imperfection", "Clients à solde créditeur", "Classés en « Clients, avances reçues » : " + _liste(x), "balance_n")
        # capitaux propres
        cp = num(BM, "K22") - num(BM, "K20") - num(BM, "K21")
        capital = num(BM, "K10")
        if capital > 0 and cp < capital / 2:
            add("anomalie", "Capitaux propres inférieurs à la moitié du capital social",
                f"Capitaux propres {_fmt(cp)} pour un capital de {_fmt(capital)}. L'Acte uniforme OHADA sur les sociétés "
                "commerciales impose de consulter les associés sur la poursuite de l'activité (SARL art. 371, SA art. 664) "
                "et d'en faire mention dans les notes.", "textes")
        # report a nouveau / affectation du resultat N-1
        if bal1:
            ran_n = num(BM, "K16")
            attendu = num(BM, "L16") + num(BM, "L18")
            dres = (num(BM, "K14") + num(BM, "K15")) - (num(BM, "L14") + num(BM, "L15"))
            div = -num("TFT", "H33")
            if abs(ran_n - (attendu - dres - div)) >= 1:
                add("anomalie", "Report à nouveau N incohérent avec l'exercice N-1",
                    f"RAN N {_fmt(ran_n)} ; attendu {_fmt(attendu - dres - div)} (RAN N-1 + résultat N-1 − dotations aux réserves − dividendes). "
                    "Vérifier l'affectation du résultat N-1 ou la balance N-1.", "balance_n1")
        # dotations / amortissements
        if num("Balance std", "F641") and not (d.get("immobilisations")):
            add("imperfection", "Tableau d'amortissement non renseigné",
                "Les notes 3A/3C et l'état n°9 sont établis à partir de la balance seule, sans le détail des biens.", "immo")

    # --------------------------------------------------------- manquements
    for k, lab in (("rccm", "N° RCCM"), ("adresse", "adresse"), ("activite", "activité principale"),
                   ("code_activite", "code activité"), ("signataire", "signataire des états financiers"),
                   ("forme_juridique", "forme juridique (code)"), ("telephone", "téléphone")):
        if not str(ident.get(k) or "").strip():
            add("manquement", f"Fiche d'identification : {lab} manquant(e)", "", "societe")
    if not exo.get("date_arrete"):
        add("manquement", "Date d'arrêté des comptes non renseignée (fiche R1, ZB)", "", "societe")
    elif exo.get("fin") and str(exo.get("date_arrete"))[:10] < str(exo.get("fin"))[:10]:
        add("anomalie", "Date d'arrêté des comptes antérieure à la clôture de l'exercice",
            f"Arrêté le {str(exo.get('date_arrete'))[:10]} pour une clôture au {str(exo.get('fin'))[:10]} : "
            "les comptes ne peuvent être arrêtés qu'après la clôture (AUDCIF, art. 8 et 23).", "societe")
    cells = d.get("cells") or {}
    if not any(k.startswith("Fiche R3!") for k in cells):
        add("manquement", "Fiche R3 non renseignée", "Dirigeants et principaux associés à compléter.", "pages")
    if bal and not bal1:
        add("manquement", "Balance N-1 absente", "La colonne N-1 des états et des notes sera à zéro.", "balance_n1")
    if bal1 and not any(k.startswith("TFT!I") for k in cells):
        add("manquement", "Colonne N-1 du tableau des flux non renseignée",
            "À reprendre de la liasse N-1 (page « Flux de trésorerie », colonne Exercice N-1).", "pages")
    imp = max(num("TABLEAU DE PASSAGE", "F53"), num("TABLEAU DE PASSAGE", "F54"))
    p = res.ev.params
    if imp > 0 and not any(float(p.get(k) or 0) for k in ("acompte1", "acompte2", "acompte3", "precomptes")):
        add("manquement", "Aucun acompte ni précompte déclaré",
            "L'impôt dû sera présenté sans imputation. Saisir ou importer les acomptes, relevés de douane et attestations de retenue.", "reglements")
    rawp = d.get("params") or {}
    regt = {r.get("type") for r in (d.get("reglements") or [])}
    saisi = [str(rawp.get(f"acompte{i}") if rawp.get(f"acompte{i}") is not None else "").strip() != "" or f"acompte{i}" in regt
             for i in (1, 2, 3)]
    if any(saisi) and not all(saisi):
        manq = ", ".join(n for n, v in zip(("1er", "2e", "3e"), saisi) if not v)
        add("manquement", f"Acompte(s) non renseigné(s) : {manq}",
            "Les trois acomptes provisionnels (1er, 2e et 3e) viennent en déduction de l'impôt dû au tableau de passage "
            "et au bordereau. Saisir le montant versé ou 0 s'il n'a pas été payé.", "fiscal")
    for r in d.get("reglements") or []:
        if float(reglements.num(r.get("montant"))) and not str(r.get("reference") or "").strip():
            add("imperfection", "Précompte ou acompte sans référence",
                f"{reglements.LIB.get(r.get('type'), '')} de {_fmt(reglements.num(r.get('montant')))} : indiquer la quittance ou la déclaration en douane.", "reglements")
            break
    if num("RESULTAT", "H32") and not p.get("tap_base"):
        add("anomalie", "Charges de personnel sans base de taxe d'apprentissage", "Vérifier les comptes retenus dans l'écran TAP.", "tap")
    for i in range(3):
        if float(p.get(f"deficit_orig_{i}") or 0) and not str(p.get(f"deficit_annee_{i}") or "").strip():
            add("imperfection", "Déficit antérieur sans année d'origine", "", "fiscal")
            break

    for k, v in res.info.get("params_invalides") or []:
        add("anomalie", f"Montant illisible dans les paramètres fiscaux ({k})",
            f"« {v} » n'est pas un nombre : il est compté pour 0. Saisir le montant en chiffres (ex. 1 250 000).", "fiscal")

    # -------------------------------------------------------- imperfections
    from . import plan
    aff = [x for x in plan.affectations(d, ("balance_n",)) if abs(x["solde"]) > 0.5]
    av = [x for x in aff if x["statut"] == "à vérifier"]
    if av:
        add("anomalie", f"{len(av)} compte(s) affecté(s) à un poste différent de celui prévu par le plan SYSCOHADA",
            "; ".join(f"{x['compte']} ({_fmt(x['solde'])}) en {x['poste']} au lieu de {x['attendu']}" for x in av[:5])
            + (" …" if len(av) > 5 else "") + ". Corriger le rattachement dans « Ventilation des comptes ».", "ventilation")
    inv = [x for x in aff if x["statut"] == "solde inversé"]
    if inv:
        add("anomalie", f"{len(inv)} compte(s) à solde de sens inhabituel",
            "Présentés en diminution de leur poste : " + "; ".join(f"{x['compte']} {x['intitule'][:30]} ({_fmt(x['solde'])}, {x['poste']})" for x in inv[:5])
            + (" …" if len(inv) > 5 else "") + ". Vérifier les écritures (amortissement débiteur, immobilisation créditrice, dépréciation de stock débitrice…).", "ventilation")
    ap = res.info.get("approx") or []
    if ap:
        add("imperfection", f"{len(ap)} compte(s) ventilé(s) par approximation",
            ", ".join(f"{x[1]} {x[2]}" for x in ap[:4]), "ventilation")
    if not (d.get("textes") or {}).get("note2"):
        add("imperfection", "Note 2 : texte type non personnalisé",
            "Adapter les règles et méthodes comptables (taux d'amortissement, méthode des stocks…) à l'entité.", "textes")
    excl = set((d.get("options") or {}).get("pages_exclues") or [])
    vides = []
    for r in range(9, 62):
        if res.value("Fiche R4", f"J{r}") == "X":
            note = str(res.value("Fiche R4", f"A{r}") or "").strip()
            pid = "note" + note.replace("NOTE", "").replace(" ", "").lower()
            if pid in ("note16bbis",):
                pid = "note16bis"
            if pid in ("note36",):
                continue
            if pid not in excl and pid + "" in _plan_ids():
                vides.append(note)
    if vides:
        add("imperfection", f"{len(vides)} note(s) non applicable(s) encore incluse(s)",
            "Les notes non chiffrées doivent être retirées de la liasse (conditions de recevabilité) : " + ", ".join(vides[:8])
            + (" …" if len(vides) > 8 else "") + ". Les décocher dans « Pages de la liasse ».", "pages")
    ordre = {"critique": 0, "anomalie": 1, "manquement": 2, "imperfection": 3}
    A.sort(key=lambda x: ordre[x["niveau"]])
    return A


def _plan_ids():
    from .pages import PAGES
    return set(PAGES)
