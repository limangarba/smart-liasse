"""Lecture des montants saisis : 1 234 567 | 1.234.567 | 1,234,567 | 1234567,50 | (12 000) | 12 000 F CFA."""
import re

_ESP = re.compile(r"[\s   ']")


def parse(v):
    """Nombre ou None si le texte n'est pas un montant."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    s = re.sub(r"(?i)\s*(f\s*cfa|fcfa|xof|francs?|f)\.?\s*$", "", s)
    s = _ESP.sub("", s).replace("%", "")
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg, s = True, s[1:-1]
    if s.endswith("-"):
        neg, s = True, s[:-1]
    if s in ("", "-", "–"):
        return 0.0 if s else None
    if re.fullmatch(r"[-+]?[1-9]\d{0,2}(\.\d{3})+(,\d+)?", s):
        s = s.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"[-+]?\d{1,3}(,\d{3})+(\.\d+)?", s):
        s = s.replace(",", "")
    else:
        s = s.replace(",", ".")
    try:
        f = float(s)
    except ValueError:
        return None
    return -f if neg else f


def num(v):
    f = parse(v)
    return 0.0 if f is None else f
