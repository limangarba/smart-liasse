"""Pages construites par programme : Note 2 et Note 39 (texte libre), declarations TAP et TCFGE,
annexe du tableau d'amortissement."""
import os
import json
import datetime

from .layout import Grid, Cell, sheet_grid
from .numfmt import fmt_value
from .pdf import wrap_lines, register_fonts, font_name
from . import declarations as decl
from .immobilisations import POSTES, AMORTISSABLES

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(HERE, "static")
A4P = (595.28 - 52, 841.89 - 52)   # zone utile portrait (points)
A4L = (841.89 - 52, 595.28 - 52)

with open(os.path.join(HERE, "data", "textes_defaut.json"), encoding="utf-8") as fh:
    TEXTES_DEFAUT = json.load(fh)

NUMF = "#,##0"


def S(**kw):
    st = {"b": False, "i": False, "u": False, "size": 8.5, "ha": "left", "va": "center", "wrap": False, "rot": 0,
          "ind": 0, "bg": None, "bl": None, "br": None, "bt": None, "bb": None, "nf": "General"}
    st.update(kw)
    return st


BOX = dict(bl="thin", br="thin", bt="thin", bb="thin")


class GB:
    """Constructeur de grille : colonnes en points, lignes ajoutees successivement."""

    def __init__(self, widths, orient="P"):
        self.g = Grid(orient)
        self.g.cols = list(widths)
        self.r = 0

    def row(self, h, cells):
        """cells : liste de (texte, style, nb_colonnes)."""
        g = self.g
        g.rows.append(h)
        j = 0
        for item in cells:
            txt, st, span = (item + (1,))[:3] if len(item) == 2 else item
            if span > 1:
                g.merges.append((self.r, j, self.r, j + span - 1))
            num = isinstance(txt, (int, float)) and not isinstance(txt, bool)
            text = fmt_value(txt, st.get("nf", "General")) if txt is not None else ""
            g.cells[(self.r, j)] = Cell(text, st, num, None, txt)
            # bordures des cellules couvertes par la fusion (pour le trace du contour)
            for k in range(1, span):
                g.cells.setdefault((self.r, j + k), Cell("", dict(st, bl=None)))
            j += span
        self.r += 1
        return self.r - 1

    def space(self, h):
        self.g.rows.append(h)
        self.r += 1

    def y_of(self, r):
        return sum(self.g.rows[:r])


def _num(v):
    return decl.num(v)


# ------------------------------------------------------------------ Notes texte
def parse_text(text):
    paras = []
    for block in (text or "").replace("\r", "").split("\n\n"):
        b = block.strip()
        if not b:
            continue
        if b.startswith("## "):
            paras.append({"t": b[3:].strip(), "b": True, "gap": 3, "k": 1.0})
        elif b.startswith("# "):
            paras.append({"t": b[2:].strip(), "b": True, "gap": 5, "k": 1.12})
        else:
            for ln in b.split("\n"):
                ln = ln.strip()
                if ln:
                    ind = ln.startswith(("-", "•"))
                    paras.append({"t": ("      " if ind else "") + ln, "gap": 4, "align": "left" if ind else "justify"})
    return paras


def text_note_pages(model, res, sheet, header_rows, key, title_suite):
    """Note a texte libre (Note 2, Note 39) : en-tete du modele + texte reparti sur autant de pages que necessaire."""
    register_fonts()
    textes = (res.dossier.get("textes") or {}) if res else {}
    text = textes.get(key)
    if text is None:
        text = TEXTES_DEFAUT.get(key, "")
    paras = parse_text(text)
    head = sheet_grid(model, res, sheet, header_rows, "P")
    tw, th = head.size()
    s = A4P[0] / tw
    total_h = A4P[1] / s
    fs = 10.5 / s
    body_w = tw
    pages = []
    queue = list(paras)
    first = True
    while True:
        if first:
            g = head
            top = th
        else:
            g = Grid("P")
            g.cols = list(head.cols)
            g.rows = [18 / s]
            g.cells[(0, 0)] = Cell(title_suite, S(b=True, size=9.5, ha="left"))
            g.merges.append((0, 0, 0, len(g.cols) - 1))
            top = 18 / s
        avail = total_h - top - 6 / s
        page_paras, used = [], 0
        while queue:
            p = queue[0]
            font = font_name({"b": p.get("b")})
            lines = wrap_lines(p["t"], font, fs * p.get("k", 1), body_w - 8 / s)
            h = len(lines) * fs * p.get("k", 1) * 1.22 + p.get("gap", 3) * (1 / s) * 1.0
            if used + h > avail and page_paras:
                break
            page_paras.append(p)
            used += h
            queue.pop(0)
        g.rows = list(g.rows) + [avail + 2 / s]
        g.textboxes.append({"x": 0, "y": top + 2 / s, "w": body_w, "h": avail, "paras": page_paras,
                            "size": 9.2, "pad": 3, "gap": 3, "border": None})
        # la taille est en points apres mise a l'echelle : on compense
        g.textboxes[-1]["size"] = fs
        g.textboxes[-1]["pad"] = 4 / s
        pages.append(g)
        first = False
        if not queue:
            break
    return pages


# ------------------------------------------------------------------------ TAP
def _header_dgi(gb, W, ref_text, title_lines, logo=True):
    g = gb.g
    ncol = len(gb.g.cols)
    gb.row(12, [("RÉPUBLIQUE DU NIGER", S(b=True, size=8.5), 4), ("", S(), ncol - 6), (ref_text, S(size=7, ha="right"), 2)])
    gb.row(12, [("MINISTÈRE DES FINANCES", S(b=True, size=8.5), 4), ("", S(), ncol - 4)])
    gb.row(12, [("DIRECTION GÉNÉRALE DES IMPÔTS", S(b=True, size=8.5), 4), ("", S(), ncol - 4)])
    gb.row(11, [("BP 217 Niamey – Tél. 20 72 23 66 / 67 – www.impots.gouv.ne", S(size=7), 5), ("", S(), ncol - 5)])
    if logo:
        g.images.append((W / 2 - 28, 0, 56, 50, os.path.join(STATIC, "logo_dgi.png")))
    gb.space(8)
    for t, st in title_lines:
        gb.row(st.pop("h", 16), [(t, st, ncol)])


def tap_pages(res):
    register_fonts()
    d = res.dossier
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    t = res.ev.decl["tap"] if hasattr(res.ev, "decl") else decl.compute_tap(d, res.ev.params)
    W = A4P[0]
    # 12 colonnes
    widths = [22, 150, 60, 20, 22, 60, 20, 22, 60, 20, 22, 65]
    k = W / sum(widths)
    widths = [w * k for w in widths]
    annee = exo.get("annee") or ""
    deb = _d(exo.get("debut"))
    fin = _d(exo.get("fin"))
    pages = []

    # ---------------- page 1
    gb = GB(widths)
    _header_dgi(gb, W, "N° DGI-551-TAP-2014", [
        ("TAXE D'APPRENTISSAGE", S(b=True, size=14, ha="center", **BOX, bg="E6E6E6", h=24)),
        (f"Déclaration relative à l'exercice {annee} du {deb} au {fin}", S(b=True, size=9.5, ha="center", h=16)),
        ("AVANT DE REMPLIR CET IMPRIMÉ, CONSULTER LA NOTICE EXPLICATIVE EN PAGES 3 ET 4", S(size=7.5, ha="center", i=True, h=13)),
    ])
    gb.space(6)
    n = len(widths)
    gb.row(16, [("I. IDENTIFICATION DU DÉCLARANT", S(b=True, size=9, bg="E6E6E6", **BOX), n)])
    lab = S(size=8, bl="thin")
    val = S(size=8.5, b=True, br="thin")
    gb.row(15, [("NIF :", lab, 2), (ident.get("nif") or "", val, n - 2)])
    gb.row(15, [("Nom, prénoms ou raison sociale :", lab, 2), (ident.get("denomination") or "", val, n - 2)])
    gb.row(15, [("Activités exercées (souligner l'activité principale) :", lab, 2), (ident.get("activite") or "", val, n - 2)])
    gb.row(15, [("Adresse (BP, quartier, rue, n° de porte) :", lab, 2),
                (" – ".join(x for x in (("BP " + ident["bp"]) if ident.get("bp") else "", ident.get("adresse") or "") if x), val, n - 2)])
    gb.row(15, [("Îlot / Marché / N° boutique – Téléphone :", dict(lab, bb="thin"), 2),
                (ident.get("telephone") or "", dict(val, bb="thin"), n - 2)])
    gb.space(8)
    gb.row(16, [("II. DÉTERMINATION DU MONTANT DE LA TAXE", S(b=True, size=9, bg="E6E6E6", **BOX), n)])
    h = S(b=True, size=7.5, ha="center", wrap=True, bg="F0F0F0", **BOX)
    gb.row(26, [("N°", h), ("Revenus à prendre en considération pour l'établissement de l'assiette", h, 2),
                ("", h), ("Montant brut", h, 3), ("Déduction ou abattements", h, 3), ("Montant net", h, 2)])
    v = t["vals"]
    L_ = S(size=8, **BOX)
    Lb = S(size=8, b=True, **BOX)
    C_ = S(size=8, ha="center", b=True, **BOX)
    N_ = S(size=8.5, ha="right", nf=NUMF, **BOX)
    NB = S(size=8.5, ha="right", nf=NUMF, b=True, **BOX)
    E_ = S(**BOX, bg="EDEDED")

    def line(no, label, letter, brut=None, ded=None, net=None, style=L_, grey=()):
        gb.row(15, [(no, C_), (label, style, 2), (letter, C_),
                    (brut, E_ if "b" in grey else N_, 3), (ded, E_ if "d" in grey else N_, 3),
                    (net, E_ if "n" in grey else N_, 2)])

    line("1", "RÉMUNÉRATIONS PRINCIPALES", "", style=Lb, grey="bdn")
    line("", "Montant brut", "A", v["A"], None, None, grey="dn")
    line("", "Montant cumulé des déductions pour pensions ou retraites", "B", None, v["B"], None, grey="bn")
    line("", "Montant net (A − B)", "C", None, None, t["C"], grey="bd")
    line("2", "INDEMNITÉS DE DÉPAYSEMENT", "", style=Lb, grey="bdn")
    line("", "Montant brut", "D", v["D"], None, None, grey="dn")
    line("", "Montant cumulé des abattements", "E", None, v["E"], None, grey="bn")
    line("", "Montant net (D − E)", "F", None, None, t["F"], grey="bd")
    line("3", "RÉMUNÉRATIONS ACCESSOIRES OU DIVERSES – montant brut", "G", None, None, v["G"], grey="bd")
    line("4", "INDEMNITÉS DE RUPTURE DE CONTRAT DE TRAVAIL – montant brut", "H", None, None, v["H"], grey="bd")
    line("5", "AVANTAGES EN NATURE", "I", None, None, v["I"], grey="bd")
    line("6", "RÉMUNÉRATIONS VERSÉES À CERTAINS DIRIGEANTS ET ADMINISTRATEURS DE SOCIÉTÉS", "J", None, None, v["J"], grey="bd")
    gb.row(17, [("", C_), ("TOTAL  K = C + F + G + H + I + J", Lb, 2), ("K", C_), ("", E_, 3), ("", E_, 3), (t["K"], NB, 2)])
    gb.space(8)
    lab2 = S(size=8.5, **BOX)
    gb.row(16, [("MONTANT BRUT DE LA TAXE", S(b=True, size=8.5, **BOX), 2), ("Base", h, 2), ("Taux", h, 2), ("Montant", h, 3), ("", S(), 3)])
    gb.row(15, [("Salaires des travailleurs nigériens", lab2, 2), (t["base3"], N_, 2), (_pct(t["t3"]), C_, 2), (t["tap3"], N_, 3), ("", S(), 3)])
    gb.row(15, [("Salaires des travailleurs non nigériens", lab2, 2), (t["base5"], N_, 2), (_pct(t["t5"]), C_, 2), (t["tap5"], N_, 3), ("", S(), 3)])
    gb.row(16, [("MONTANT GLOBAL DE LA TAXE", S(b=True, size=8.5, **BOX), 5), ("L", C_), (t["L"], NB, 3), ("", S(), 3)])
    gb.row(15, [("Total des dépenses ouvrant droit à réduction (voir page 2)", lab2, 5), ("M", C_), (t["M"], N_, 3), ("", S(), 3)])
    gb.row(15, [("Déduction : frais de formation déduits de la base × taux" if t.get("mode") == "base" else "Déduction admise (maximum 50 % de la taxe)", lab2, 5), ("N", C_), (t["N"], N_, 3), ("", S(), 3)])
    gb.row(18, [("NET À PAYER  (L − N)", S(b=True, size=9.5, bg="E6E6E6", **BOX), 5), ("P", C_), (t["P"], S(size=10, b=True, ha="right", nf=NUMF, **BOX, bg="E6E6E6"), 3), ("", S(), 3)])
    gb.space(14)
    gb.row(14, [("", S(), 7), ("Le déclarant,", S(b=True, size=9), 5)])
    gb.row(14, [("", S(), 7), ("A ____________________, le ______________", S(size=8.5), 5)])
    gb.row(40, [("", S(), 7), ("Signature et cachet", S(size=8.5, va="top"), 5)])
    gb.row(22, [("", S(), 7), ("Certifie sous peine de l'application de sanctions fiscales que les éléments déclarés sont rigoureusement exacts.", S(size=7, i=True, wrap=True), 5)])
    gb.space(10)
    gb.row(26, [("La présente déclaration doit être déposée auprès du service des impôts territorialement compétent dans les délais impartis pour le dépôt de la déclaration des résultats. Le défaut de production ou la production tardive donne lieu à l'application de sanctions fiscales.", S(size=7, wrap=True, ha="center", i=True), n)])
    gb.row(12, [("PAGE 1", S(size=7.5, ha="right", b=True), n)])
    pages.append(gb.g)

    # ---------------- page 2
    widths2 = [22, 140, 70, 70, 50, 45, 45, 80]
    k = W / sum(widths2)
    widths2 = [w * k for w in widths2]
    n = len(widths2)
    gb = GB(widths2)
    gb.row(18, [("TAXE D'APPRENTISSAGE – DÉCLARATION (suite)", S(b=True, size=11, ha="center"), n)])
    gb.row(12, [(f"{ident.get('denomination') or ''}   –   NIF : {ident.get('nif') or ''}   –   Exercice {annee}", S(size=8, ha="center"), n)])
    gb.space(8)
    gb.row(16, [("III. DÉPENSES LIBÉRATOIRES", S(b=True, size=9, bg="E6E6E6", **BOX), n)])
    f = t["form"]
    L2 = S(size=8, wrap=True, **BOX)
    gb.row(24, [("7", C_), ("Pour les employeurs assurant eux-mêmes des actions de formation technologiques ou professionnelles, indiquer :", dict(L2, b=True), n - 1)])
    gb.row(15, [("", C_), ("• les frais de formation supportés par les assujettis", L2, 5), ("A", C_), (_num(f.get("frais_formation")), N_)])
    gb.row(24, [("", C_), ("• les salaires des techniciens chargés de la formation des apprentis et du perfectionnement des adultes, à l'exclusion de tout autre travail", L2, 5), ("B", C_), (_num(f.get("salaires_techniciens")), N_)])
    gb.row(15, [("", C_), ("• les subventions, bourses et allocations d'études ou stages de perfectionnement", L2, 5), ("C", C_), (_num(f.get("bourses")), N_)])
    gb.row(24, [("8", C_), ("Pour les employeurs confiant à des établissements ou organismes habilités des actions de formation technologiques ou professionnelles, indiquer les nom et adresse des établissements et le montant des concours versés :", dict(L2, b=True), n - 1)])
    etabs = list(f.get("etablissements") or [])
    if len(etabs) > 3:
        autres = etabs[2:]
        etabs = etabs[:2] + [{"nom": f"Autres organismes ({len(autres)})", "adresse": "voir état joint",
                              "montant": sum(_num(e.get("montant")) for e in autres)}]
    while len(etabs) < 3:
        etabs.append({})
    for i, e in enumerate(etabs, 1):
        gb.row(15, [("", C_), (e.get("nom") or "", L2, 2), (e.get("adresse") or "", L2, 3), (str(i), C_), (_num(e.get("montant")) or None, N_)])
    gb.row(24, [("9", C_), ("Pour l'ensemble des employeurs, montant global des rémunérations versées aux apprentis avec lesquels un contrat d'apprentissage a été établi (voir état justificatif)", L2, 5), ("D", C_), (_num(f.get("concours")) or None, N_)])
    gb.row(17, [("10", C_), ("TOTAL des dépenses à raison desquelles la réduction est demandée (A+B+C+1+2+3+D)", dict(L2, b=True), 5), ("M", C_), (t["M"], NB)])
    gb.space(10)
    gb.row(16, [("IV. ÉTAT JUSTIFICATIF POUR LES EXONÉRATIONS AU TITRE DES SALAIRES DES APPRENTIS", S(b=True, size=9, bg="E6E6E6", **BOX), n)])
    hh = S(b=True, size=7, ha="center", wrap=True, bg="F0F0F0", **BOX)
    gb.row(30, [("N°", hh), ("Noms et prénoms", hh), ("N° matricule interne", hh), ("N° d'enregistrement du contrat", hh),
                ("Date de début du contrat", hh), ("Durée du contrat", hh), ("Nombre de mois", hh), ("Rémunération", hh)])
    gb.row(11, [(str(i), S(size=7, ha="center", i=True, **BOX)) for i in ["", "1", "2", "3", "4", "5", "6", "7"]])
    ap = list(t["apprentis"])[:15]
    tot = 0
    for i in range(15):
        a = ap[i] if i < len(ap) else {}
        r = _num(a.get("remuneration"))
        tot += r
        gb.row(14, [(str(i + 1), C_), (a.get("nom") or "", L_), (a.get("matricule") or "", L_), (a.get("contrat") or "", L_),
                    (a.get("debut") or "", S(size=8, ha="center", **BOX)), (a.get("duree") or "", S(size=8, ha="center", **BOX)),
                    (a.get("mois") or "", S(size=8, ha="center", **BOX)), (r or None, N_)])
    gb.row(16, [("TOTAL", Lb, 7), (tot, NB)])
    gb.row(12, [("Si ce cadre est insuffisant, joindre un état du même type.", S(size=7, i=True), n)])
    gb.space(10)
    gb.row(18, [("", S(), 3), ("RÉDUCTION ACCORDÉE", S(b=True, size=8.5, **BOX), 3), ("", S(**BOX), 2)])
    gb.space(6)
    gb.row(18, [("", S(), 3), ("TAXE DUE", S(b=True, size=8.5, **BOX), 3), ("", S(**BOX), 2)])
    gb.row(12, [("(cadre réservé à l'administration)", S(size=7, i=True, ha="right"), n)])
    gb.space(30)
    gb.row(12, [("PAGE 2", S(size=7.5, ha="right", b=True), n)])
    pages.append(gb.g)

    # ---------------- pages 3 et 4 : notice
    pages.extend(_notice_pages(W))
    return pages


NOTICE_1 = [
    ("# V. NOTICE EXPLICATIVE", None),
    ("## QUI DOIT PAYER LA TAXE ?", None),
    ("Les personnes physiques ou morales soumises à un régime réel d'imposition au titre des bénéfices sont passibles de la taxe d'apprentissage (article 128).", None),
    ("Les personnes physiques ou morales qui ont pour activité exclusive l'enseignement sont exonérées de la taxe.", None),
    ("## QUELS SONT L'ASSIETTE, LE TAUX ET LE MONTANT DE LA TAXE ?", None),
    ("La taxe d'apprentissage est assise sur l'ensemble des revenus mis à la disposition de leurs salariés permanents ou non, au cours de l'année, par les personnes physiques ou morales entrant dans le champ d'application de la taxe sous déduction :", None),
    ("- des retenues faites par l'employeur en vue de la constitution de pension de retraite. Pour être admis en déduction, ces prélèvements doivent être effectués à titre obligatoire. Ces déductions sont limitées à 6 % de la rémunération principale brute ;", None),
    ("- de l'abattement de 17 % de la somme représentative de la rémunération principale brute et de l'indemnité de dépaysement pour les travailleurs non nigériens, lorsque cette indemnité est au moins égale à 40 % de la rémunération principale brute telle que définie à l'article 60 du Livre premier du Code Général des Impôts.", None),
    ("Le taux de la taxe d'apprentissage est égal à :", None),
    ("- 3 % pour les salaires versés aux travailleurs nigériens ;", None),
    ("- 5 % pour les salaires versés aux travailleurs non nigériens.", None),
    ("## LIEU DU DÉPÔT ET DÉLAIS DE DÉCLARATION", None),
    ("La déclaration doit être souscrite en un seul exemplaire et déposée auprès du service des impôts territorialement compétent du lieu de souscription de la déclaration des résultats, c'est-à-dire en général celui du principal établissement ou du siège d'exploitation.", None),
    ("## PRÉCISION IMPORTANTE", None),
    ("Le défaut de production ou la production hors délai de la déclaration, ainsi que les omissions ou inexactitudes relevées dans les indications qu'elle doit comporter donnent lieu à l'application de sanctions fiscales.", None),
    ("## RAPPEL DE NOTIONS FONDAMENTALES", None),
    ("Rappel de notions fondamentales quant à la définition des revenus à prendre en considération pour l'établissement de l'assiette de la taxe.", None),
    ("Par « rémunérations principales », il y a lieu d'entendre les traitements et salaires proprement dits, publics et privés, quelle que soit la situation de leurs bénéficiaires au regard de la législation du travail ou de la législation sociale. À ce titre sont notamment imposables les revenus ayant leur source dans les rémunérations payées par l'État, les collectivités publiques, les offices, les établissements publics et les sociétés d'économie mixte, dès lors que la partie versante est passible de la taxe d'apprentissage.", None),
    ("Les salaires versés aux apprentis sont à comprendre dans l'assiette de la taxe.", None),
    ("Le montant imposable est un montant net, c'est-à-dire après déduction des retenues effectuées pour la constitution des pensions ou des retraites. Pour être admis en déduction, ces prélèvements doivent être effectués à titre obligatoire. Dans la majorité des cas, le taux de la retenue est de 5,25 % et il ne peut en toute hypothèse dépasser 6 % dans certaines circonstances bien définies (ex. : cas des travailleurs expatriés).", None),
]

NOTICE_2 = [
    ("# NOTICE EXPLICATIVE (suite)", None),
    ("Les « indemnités de dépaysement » entrent dans le calcul de l'assiette. Toutefois, cette indemnité allouée à certains travailleurs étrangers expatriés au Niger est imposable sous déduction d'un abattement de 17 % calculé sur le montant de la somme représentative de la rémunération brute principale et de l'indemnité de dépaysement. Pour ouvrir droit à l'abattement dont il s'agit, l'indemnité de dépaysement doit au moins être égale à 40 % de la rémunération brute principale.", None),
    ("Par « rémunérations accessoires ou diverses », il y a lieu d'entendre les rémunérations perçues en sus des traitements et salaires proprement dits. Il en est ainsi en particulier des allocations afférentes à la qualité du travail ou au statut du personnel dans l'entreprise (primes d'ancienneté, d'assiduité, etc.), des allocations afférentes aux conditions de travail (primes ou indemnités de sujétions, de risque, de pénibilité, de responsabilité, de caisse, etc.), des allocations ou indemnités pour frais professionnels dès lors qu'elles ne répondent pas aux conditions posées pour être exonérées, des indemnités, remboursements et allocations forfaitaires pour frais versés aux dirigeants de sociétés, des avantages divers pouvant être accordés aux salariés (prise en charge par l'employeur de cotisations sociales normalement à la charge du salarié, de primes d'assurances, paiement direct par l'employeur de charges incombant personnellement au salarié, etc.), des commissions calculées généralement en proportion du chiffre d'affaires réalisé dès lors qu'elles sont perçues dans l'exercice d'une profession salariée.", None),
    ("Les « indemnités versées au salarié en cas de rupture de contrat de travail », lorsqu'elles correspondent à l'attribution d'un salaire de congédiement, entrent dans le calcul de l'assiette de la taxe ; il en est de même des indemnités ou primes versées en cas de départ ou de démission volontaire du salarié.", None),
    ("Les « avantages en nature » dont bénéficient les salariés entrent dans le calcul de l'assiette de la taxe ; les avantages en nature consistent dans la concession gratuite au salarié d'un bien dont l'employeur est propriétaire ou locataire ou dans la fourniture de prestations de services. Les avantages en nature sont évalués sur les bases forfaitaires suivantes :", None),
    ("- logement : 20 000 F CFA par pièce et par mois dans la limite du 1/3 de la rémunération brute principale ;", None),
    ("- ameublement : 1/3 de la valeur du logement déterminée dans les conditions ci-dessus ;", None),
    ("- électricité : 50 000 F CFA par mois ;  eau : 15 000 F CFA par mois ;  téléphone : 20 000 F CFA par mois ;", None),
    ("- véhicule automobile : 20 000 F CFA par véhicule et par mois ;  domesticité : 20 000 F CFA par domestique et par mois.", None),
    ("Entrent également dans le calcul de l'assiette de la taxe les revenus provenant de l'exercice de certaines fonctions privées. Tel est notamment le cas des rémunérations de certains dirigeants de sociétés. Ont ainsi le caractère de traitements et salaires :", None),
    ("- dans les sociétés anonymes : les indemnités de fonction, ainsi que les traitements, les participations et avantages divers attribués à titre de rétribution de leurs fonctions aux administrateurs exerçant des responsabilités spéciales de direction (président du conseil d'administration, directeur général, administrateurs provisoirement délégués, membres du directoire) ;", None),
    ("- dans les sociétés à responsabilité limitée : les appointements de toute nature et indemnités de fonction perçus par les gérants minoritaires, qu'ils soient ou non associés, et par les associés non-gérants.", None),
    ("Sur demande expresse des assujettis, à formuler en page 2 de la déclaration, des exonérations partielles ou totales peuvent être accordées en considération des dépenses effectuées au cours de l'année d'imposition en faveur des actions de formation technologique ou professionnelle des travailleurs déjà engagés dans la vie active, soit directement, soit par l'intermédiaire d'établissements ou d'organismes consacrant la totalité ou une partie de leurs ressources au but recherché.", None),
    ("À l'exclusion de toutes autres, les dépenses libératoires sont celles figurant en face des numéros concernés.", None),
    ("À peine d'irrecevabilité, les dépenses invoquées en vue de l'exonération doivent être intégralement justifiées par tous moyens appropriés (factures, bulletins de salaires, conventions de stage, attestations des établissements ou organismes de formation, reçus divers, etc.). Les pièces justificatives doivent impérativement être jointes à la demande d'exonération, éventuellement récapitulées sur un bordereau d'envoi.", None),
    ("L'ÉTAT JUSTIFICATIF POUR LES EXONÉRATIONS AU TITRE DES SALAIRES DES APPRENTIS doit être rempli avec une grande précision.", None),
]


def _notice_pages(W):
    out = []
    for i, content in enumerate((NOTICE_1, NOTICE_2)):
        g = Grid("P")
        g.cols = [W]
        g.rows = [A4P[1] - 16, 16]
        paras = parse_text("\n\n".join(t for t, _ in content))
        g.textboxes.append({"x": 0, "y": 0, "w": W, "h": A4P[1] - 20, "paras": paras, "size": 9.3, "pad": 8,
                            "gap": 3, "border": 0.8})
        g.cells[(1, 0)] = Cell(f"PAGE {3 + i}", S(size=7.5, ha="right", b=True))
        out.append(g)
    return out


# ---------------------------------------------------------------------- TCFGE
def tcfge_pages(res):
    register_fonts()
    d = res.dossier
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    t = res.ev.decl["tcfge"] if hasattr(res.ev, "decl") else decl.compute_tcfge(d, res.ev.params)
    W = A4P[0]
    widths = [26, 175, 30, 80, 80, 22, 80]
    k = W / sum(widths)
    widths = [w * k for w in widths]
    n = len(widths)
    gb = GB(widths)
    g = gb.g
    gb.row(12, [("RÉPUBLIQUE DU NIGER", S(b=True, size=8.5), 3), ("DIRECTION GÉNÉRALE DES IMPÔTS", S(b=True, size=8.5, ha="center"), 2), ("N° DCD-TCFG100", S(size=7.5, ha="right"), 2)])
    gb.row(12, [("MINISTÈRE DES FINANCES", S(b=True, size=8.5), 3), ("", S(), 2), ("(Janvier 1988)", S(size=7.5, ha="right"), 2)])
    gb.row(12, [("", S(), 5), ("Timbre à date du service", S(size=7.5, ha="right", i=True), 2)])
    g.images.append((0, 40, 70, 54, os.path.join(STATIC, "armoiries.png")))
    g.images.append((W - 70, 40, 70, 54, os.path.join(STATIC, "logo_dgi2.png")))
    gb.space(18)
    gb.row(30, [("", S(), 2), ("TAXE SUR CERTAINS FRAIS GÉNÉRAUX DES ENTREPRISES", S(b=True, size=12, ha="center", wrap=True, **BOX, bg="E6E6E6"), 3), ("", S(), 2)])
    gb.space(22)
    gb.row(16, [(f"Déclaration relative à l'année {exo.get('annee') or ''}", S(b=True, size=11), 5), (f"NIF : {ident.get('nif') or ''}", S(b=True, size=9.5, ha="right"), 2)])
    gb.space(8)
    lab = S(size=8, bl="thin")
    val = S(size=9, b=True, br="thin")
    gb.row(16, [("I. IDENTIFICATION DE L'ENTREPRISE", S(b=True, size=9, bg="E6E6E6", **BOX), n)])
    gb.row(15, [("1. Nom et prénom ou désignation de la société (raison sociale et forme juridique)", lab, 3), (ident.get("denomination") or "", val, 4)])
    gb.row(15, [("2. Activités exercées (souligner l'activité principale)", lab, 3), (ident.get("activite") or "", val, 4)])
    gb.row(15, [("3. Adresse", lab, 3), ((ident.get("adresse") or "") + (("   Tél. : " + ident["telephone"]) if ident.get("telephone") else ""), val, 4)])
    gb.row(15, [("4. N° sécurité sociale employeur", dict(lab, bb="thin"), 2), (ident.get("cnss") or "", S(size=9, b=True, bb="thin"), 1),
                ("5. N° registre du commerce", S(size=8, bb="thin"), 2), (ident.get("rccm") or "", dict(val, bb="thin"), 2)])
    gb.space(10)
    hdr = S(b=True, size=8, ha="center", wrap=True, bg="F0F0F0", **BOX)
    gb.row(26, [("II.", S(b=True, size=9, **BOX)), ("ASSIETTE DE LA TAXE", S(b=True, size=9, **BOX), 2), ("Montant brut", hdr), ("Déduction ou abattement", hdr), ("", hdr), ("Montant net", hdr)])
    L_ = S(size=8.5, wrap=True, **BOX)
    N_ = S(size=9, ha="right", nf=NUMF, **BOX)
    C_ = S(size=8.5, ha="center", b=True, **BOX)
    for code, lib, _ in decl.TCFGE_LIGNES:
        brut, ded, net = t["lignes"][code]
        gb.row(28 if len(lib) > 60 else 18, [("", S(**BOX)), (lib, L_, 2), (brut or None, N_), (ded or None, N_), (code, C_), (net or None, N_)])
    gb.row(18, [("", S(**BOX)), ("Total (a + b + c + d + e)", S(b=True, size=8.5, **BOX), 2), ("", S(**BOX, bg="EDEDED")), ("", S(**BOX, bg="EDEDED")), ("f", C_), (t["base"] or "NÉANT", S(size=9, ha="right" if t["base"] else "center", nf=NUMF, b=True, **BOX))])
    gb.space(14)
    gb.row(16, [("III.", S(b=True, size=9, bl="thin", bt="thin")), ("MONTANT DE LA TAXE", S(b=True, size=9, bt="thin"), 2), ("", S(bt="thin"), 3), ("", S(bt="thin", br="thin"))])
    mont = t["montant"]
    gb.row(22, [("", S(bl="thin")), (f"f × {_pct(t['taux'])} =", S(size=10, b=True, ha="right")), (fmt_value(mont, NUMF) if mont else "NÉANT", S(size=11, b=True, ha="center", **BOX), 2),
                ("", S()), ("", S()), ("", S(br="thin"))])
    gb.row(14, [("", S(bl="thin")), ("", S(), 3), ("A ____________________, le _____________", S(size=8.5), 2), ("", S(br="thin"))])
    gb.row(34, [("", S(bl="thin", bb="thin")), ("", S(bb="thin"), 3), ("Signature", S(size=8.5, va="top", bb="thin"), 2), ("", S(br="thin", bb="thin"))])
    gb.space(14)
    gb.row(16, [("IV.", S(b=True, size=9, bl="thin", bt="thin")), ("CADRE RÉSERVÉ AU SERVICE", S(b=True, size=9, bt="thin"), 5), ("", S(bt="thin", br="thin"))])
    gb.row(26, [("", S(bl="thin")), ("", S(), 1), ("", S(**BOX), 3), ("", S(), 1), ("", S(br="thin"))])
    gb.row(14, [("", S(bl="thin", bb="thin")), ("(Pénalités d'assiette)", S(size=8, i=True, bb="thin"), 5), ("", S(br="thin", bb="thin"))])
    gb.space(16)
    gb.row(34, [("La présente déclaration doit être déposée auprès du service des contributions diverses dans les délais impartis pour le dépôt des déclarations des bénéfices industriels et commerciaux ou des bénéfices non commerciaux. Le défaut de production ou la production tardive donne lieu à l'application des pénalités prévues par le Code Général des Impôts.", S(size=7.5, wrap=True, i=True), n)])
    return [gb.g]


# ------------------------------------------------------- annexe amortissements
def annexe_amorts_pages(res):
    info = res.info.get("immo") or {}
    lines = info.get("lignes") or []
    if not lines:
        return []
    register_fonts()
    d = res.dossier
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    W = A4L[0]
    heads = ["Désignation du bien", "Référence", "Compte", "Date mise en service", "Valeur d'origine", "Taux",
             "Amort. antérieurs", "Dotation de l'exercice", "Sorties", "Amort. cumulés", "VNC"]
    widths = [150, 60, 45, 55, 70, 35, 70, 70, 60, 70, 70]
    k = W / sum(widths)
    widths = [w * k for w in widths]
    n = len(widths)
    per_page = 30
    groups = []
    for p in POSTES:
        ls = [l for l in lines if l["poste"] == p]
        if ls:
            groups.append((p, ls))
    rows = []
    for p, ls in groups:
        rows.append(("H", p, None))
        for l in ls:
            rows.append(("L", p, l))
        rows.append(("T", p, ls))
    rows.append(("G", None, lines))
    pages = []
    chunks = [rows[i:i + per_page] for i in range(0, len(rows), per_page)]
    for pi, chunk in enumerate(chunks, 1):
        gb = GB(widths, "L")
        gb.row(18, [("TABLEAU DES IMMOBILISATIONS ET DES AMORTISSEMENTS (annexe à l'état complémentaire n°9)", S(b=True, size=11, ha="center"), n)])
        gb.row(13, [(f"{ident.get('denomination') or ''}  –  NIF : {ident.get('nif') or ''}  –  Exercice clos le {_d(exo.get('fin'))}", S(size=8.5, ha="center"), n - 2),
                    (f"Page {pi}/{len(chunks)}", S(size=8, ha="right"), 2)])
        gb.space(6)
        hh = S(b=True, size=7.5, ha="center", wrap=True, bg="E6E6E6", **BOX)
        gb.row(26, [(h, hh) for h in heads])
        L_ = S(size=7.5, **BOX)
        N_ = S(size=7.5, ha="right", nf=NUMF, **BOX)
        for kind, p, l in chunk:
            if kind == "H":
                gb.row(13, [(POSTES[p], S(b=True, size=7.5, bg="F2F2F2", **BOX), n)])
            elif kind == "L":
                sortie = l["reprise"] if l["cession"] else None
                gb.row(12.5, [(l["designation"], L_), (l["reference"], L_), (l["compte"], S(size=7.5, ha="center", **BOX)),
                              (l["date_service"], S(size=7.5, ha="center", nf="dd/mm/yyyy", **BOX)), (l["valeur"], N_),
                              (l["taux"] or None, S(size=7.5, ha="center", nf="0.00%", **BOX)), (l["cum_ouv"], N_), (l["dotation"], N_),
                              (sortie, N_), (l["cum_clot"], N_), (l["clot_brut"] - l["cum_clot"], N_)])
            else:
                ls = l if kind == "G" else l
                lab = "TOTAL GÉNÉRAL" if kind == "G" else "Sous-total " + POSTES[p]
                B = S(size=7.5, ha="right", nf=NUMF, b=True, **BOX, bg="F2F2F2" if kind == "G" else None)
                gb.row(13, [(lab, S(b=True, size=7.5, **BOX, bg="F2F2F2" if kind == "G" else None), 4),
                            (sum(x["valeur"] for x in ls), B), ("", S(**BOX)), (sum(x["cum_ouv"] for x in ls), B),
                            (sum(x["dotation"] for x in ls), B), (sum(x["reprise"] for x in ls), B),
                            (sum(x["cum_clot"] for x in ls), B), (sum(x["clot_brut"] - x["cum_clot"] for x in ls), B)])
        gb.space(6)
        gb.row(12, [("Amortissement linéaire, prorata temporis (année de 360 jours). Les amortissements antérieurs sont repris du tableau ou recalculés depuis la date de mise en service.", S(size=7, i=True), n)])
        pages.append(gb.g)
    return pages


def _pct(x):
    x = _num(x)
    s = f"{x * 100:.2f}".rstrip("0").rstrip(".").replace(".", ",")
    return s + " %"


def _d(v):
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.strftime("%d/%m/%Y")
    if isinstance(v, str) and len(v) == 10 and v[4] == "-":
        return f"{v[8:10]}/{v[5:7]}/{v[0:4]}"
    return v or ""


# ------------------------------------------------------- annexes justificatives
def _liste_pages(res, titre, heads, widths, rows, total_cols, note=""):
    """Etat en liste (portrait), reparti sur plusieurs pages si necessaire, total general en fin."""
    register_fonts()
    d = res.dossier
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    W = A4P[0]
    k = W / sum(widths)
    widths = [w * k for w in widths]
    n = len(widths)
    per = 42
    chunks = [rows[i:i + per] for i in range(0, len(rows), per)] or [[]]
    pages = []
    hh = S(b=True, size=7.5, ha="center", wrap=True, bg="E6E6E6", **BOX)
    L_ = S(size=7.5, **BOX)
    N_ = S(size=7.5, ha="right", nf=NUMF, **BOX)
    for pi, ch in enumerate(chunks, 1):
        gb = GB(widths)
        gb.row(18, [(titre, S(b=True, size=11, ha="center"), n)])
        gb.row(13, [(f"{ident.get('denomination') or ''}  –  NIF : {ident.get('nif') or ''}  –  Exercice clos le {_d(exo.get('fin'))}", S(size=8.5, ha="center"), n)])
        gb.row(11, [(f"Page {pi}/{len(chunks)}", S(size=7.5, ha="right"), n)])
        gb.space(4)
        gb.row(24, [(h, hh) for h in heads])
        for r in ch:
            if r and r[0] == "__SOUS_TOTAL__":
                B = S(size=7.5, ha="right", nf=NUMF, b=True, bg="F2F2F2", **BOX)
                cells = [(r[1], S(b=True, size=7.5, bg="F2F2F2", **BOX), n - len(total_cols))]
                cells += [(r[2 + i], B) for i in range(len(total_cols))]
                gb.row(13, cells)
                continue
            gb.row(12.5, [(v, N_ if isinstance(v, (int, float)) and not isinstance(v, bool) else L_) for v in r])
        if pi == len(chunks):
            B = S(size=8, ha="right", nf=NUMF, b=True, bg="E6E6E6", **BOX)
            tot = [sum(_num(r[c]) for r in rows if r and r[0] != "__SOUS_TOTAL__") for c in total_cols]
            gb.row(15, [("TOTAL GÉNÉRAL", S(b=True, size=8, bg="E6E6E6", **BOX), n - len(total_cols))] + [(t, B) for t in tot])
            if note:
                gb.space(6)
                gb.row(24, [(note, S(size=7, i=True, wrap=True), n)])
        pages.append(gb.g)
    return pages


def annexe_reglements_pages(res):
    from .reglements import TYPES
    regs = res.dossier.get("reglements") or []
    if not regs:
        return []
    rows = []
    for key, lib in TYPES:
        ls = [r for r in regs if r.get("type") == key]
        if not ls:
            continue
        for r in sorted(ls, key=lambda x: str(x.get("date") or "")):
            rows.append([lib, _d(r.get("date")), r.get("reference") or "", r.get("tiers") or "",
                         _num(r.get("base")) or "", _num(r.get("montant"))])
        rows.append(["__SOUS_TOTAL__", "Sous-total " + lib, sum(_num(r.get("montant")) for r in ls)])
    return _liste_pages(res, "ÉTAT DÉTAILLÉ DES ACOMPTES, PRÉCOMPTES ET CRÉDITS D'IMPÔT",
                        ["Nature", "Date", "Référence (quittance, déclaration en douane…)", "Tiers / bureau", "Base", "Montant"],
                        [130, 50, 115, 110, 70, 70], rows, [5],
                        "Annexe au tableau de passage (lignes acomptes, crédit d'impôt, précomptes) et au bordereau de versement. "
                        "Joindre les quittances, relevés de douane et attestations de retenue.")


def annexe_formation_pages(res):
    fr = res.dossier.get("formations") or []
    if not fr:
        return []
    labs = {"A": "A – Frais de formation", "B": "B – Salaires des formateurs", "C": "C – Bourses, stages",
            "D": "D – Rémunérations des apprentis", "E": "Concours à un établissement"}
    rows = [[labs.get((f.get("categorie") or "A").upper(), f.get("categorie")), _d(f.get("date")), f.get("libelle") or "",
             f.get("organisme") or "", f.get("piece") or "", _num(f.get("montant"))] for f in fr]
    return _liste_pages(res, "TAXE D'APPRENTISSAGE – ÉTAT DES FRAIS DE FORMATION",
                        ["Catégorie", "Date", "Libellé de l'action", "Organisme / bénéficiaire", "Pièce", "Montant"],
                        [105, 50, 140, 110, 55, 70], rows, [5],
                        "Dépenses libératoires ouvrant droit à réduction de la taxe (plafond : 50 % de la taxe). "
                        "Pièces justificatives à joindre à la déclaration.")


# ------------------------------------------------------- garde des etats supplementaires
def garde_dgi_pages(res):
    register_fonts()
    d = res.dossier
    ident = d.get("identite", {})
    exo = d.get("exercice", {})
    W = A4P[0]
    n = 6
    gb = GB([W / n] * n)
    _header_dgi(gb, W, "", [], logo=True)
    gb.space(150)
    big = S(b=True, size=22, ha="center", bg="E6E6E6", bl="medium", br="medium")
    gb.row(10, [("", S(bg="E6E6E6", bl="medium", br="medium", bt="medium"), n)])
    gb.row(34, [("ÉTATS SUPPLÉMENTAIRES", big, n)])
    gb.row(26, [("DIRECTION GÉNÉRALE DES IMPÔTS", S(b=True, size=15, ha="center", bg="E6E6E6", bl="medium", br="medium"), n)])
    gb.row(22, [("États complémentaires n° 1 à 13 – SYSCOHADA révisé, système normal", S(i=True, size=10, ha="center", bg="E6E6E6", bl="medium", br="medium"), n)])
    gb.row(10, [("", S(bg="E6E6E6", bl="medium", br="medium", bb="medium"), n)])
    gb.space(70)
    lab = S(size=10, b=True)
    val = S(size=11, bb="dotted")
    from .engine import parse_date
    fin = parse_date(exo.get("fin")) if exo.get("fin") else None
    for l, v in (("Dénomination sociale :", ident.get("denomination") or ""),
                 ("Sigle usuel :", ident.get("sigle") or ""),
                 ("N° d'identification fiscale (NIF) :", ident.get("nif") or ""),
                 ("Adresse :", ident.get("adresse") or ""),
                 ("Exercice clos le :", fin.strftime("%d/%m/%Y") if hasattr(fin, "strftime") else (exo.get("fin") or ""))):
        gb.row(24, [(l, lab, 2), (v, val, 4)])
    return [gb.g]
