"""Construction d'une page sous forme de grille (independante du format de sortie)."""
import re
from .formula import col2num, num2col, CELL_RE
from .numfmt import fmt_value


def px_width(w):
    """Largeur de colonne Excel (caracteres) -> points."""
    if w is None:
        w = 8.43
    px = int(w * 7 + 5) if w > 0 else 0
    return px * 0.75


class Cell:
    __slots__ = ("text", "st", "num", "ref", "value", "forced", "formula")

    def __init__(self, text="", st=None, num=False, ref=None, value=None, forced=False, formula=False):
        self.text = text
        self.st = st or {}
        self.num = num
        self.ref = ref
        self.value = value
        self.forced = forced
        self.formula = formula


class Grid:
    def __init__(self, orient="P"):
        self.orient = orient
        self.cols = []     # largeurs en points
        self.rows = []     # hauteurs en points
        self.cells = {}    # (i, j) -> Cell
        self.merges = []   # (i1, j1, i2, j2)
        self.images = []   # (x, y, w, h, fichier)  coordonnees en points dans la grille
        self.textboxes = []  # dict(x, y, w, h, paras, size, bold, align, border, rotate)
        self.row_ids = []
        self.col_ids = []
        self.title = ""
        self.sheet = None

    def size(self):
        return sum(self.cols), sum(self.rows)

    def merge_at(self):
        idx = {}
        for m in self.merges:
            i1, j1, i2, j2 = m
            for i in range(i1, i2 + 1):
                for j in range(j1, j2 + 1):
                    idx[(i, j)] = m
        return idx


STYLE_CACHE = {}
NAV_TEXTS = {"MENU PRINCIPAL", "'MENU PRINCIPAL'!A1", "MENU DGI", "'MENU DGI'!A1", "MENU PRINCIPAL ", "RETOUR"}


def norm_style(raw):
    key = id(raw)
    if key in STYLE_CACHE:
        return STYLE_CACHE[key]
    fn = (raw.get("fn") or "").lower()
    st = {
        "b": raw.get("fb") or ("black" in fn),
        "i": raw.get("fi"),
        "u": raw.get("fu"),
        "size": min(max(raw.get("fs") or 10, 5), 22),
        "ha": raw.get("ha"),
        "va": raw.get("va"),
        "wrap": raw.get("wr"),
        "rot": raw.get("rot") or 0,
        "ind": raw.get("ind") or 0,
        "bg": raw.get("bg"),
        "bl": raw.get("bl"), "br": raw.get("br"), "bt": raw.get("bt"), "bb": raw.get("bb"),
        "nf": raw.get("nf") or "General",
        "white": raw.get("white"),
        "shrink": raw.get("shr"),
    }
    STYLE_CACHE[key] = st
    return st


def parse_area(area):
    a, b = area.split(":")
    ma, mb = CELL_RE.fullmatch(a), CELL_RE.fullmatch(b)
    return int(ma.group(2)), col2num(ma.group(1)), int(mb.group(2)), col2num(mb.group(1))


def sheet_grid(model, result, sheet, area, orient):
    """Grille d'une zone de feuille, valeurs calculees par le moteur."""
    s = model.sheets[sheet]
    r1, c1, r2, c2 = parse_area(area)
    g = Grid(orient)
    g.sheet = sheet
    colw = s["colw"]
    defw = s.get("defw") or 8.43
    for c in range(c1, c2 + 1):
        L = num2col(c)
        info = colw.get(L)
        if info and info.get("h"):
            continue
        w = info.get("w") if info else None
        g.cols.append(px_width(w if w is not None else defw))
        g.col_ids.append(c)
    rowh = s["rowh"]
    defh = s.get("defh") or 15
    for r in range(r1, r2 + 1):
        info = rowh.get(str(r))
        if info and info.get("x"):
            continue
        h = info.get("h") if info else None
        g.rows.append(h if h is not None else defh)
        g.row_ids.append(r)
    ri = {r: i for i, r in enumerate(g.row_ids)}
    ci = {c: j for j, c in enumerate(g.col_ids)}
    styles = model.styles
    overrides = result.overrides if result is not None else {}
    for addr, c in s["cells"].items():
        m = CELL_RE.fullmatch(addr)
        r, col = int(m.group(2)), col2num(m.group(1))
        if r not in ri or col not in ci:
            continue
        st = norm_style(styles[c["s"]])
        key = (sheet, addr)
        is_formula = key in model.formulas
        v = result.value(sheet, addr) if result is not None else (c.get("v"))
        if hasattr(v, "code") and not isinstance(v, str):
            v = None  # erreur de calcul (division par zero sur un dossier incomplet) : case laissee vide
        if v is None and is_formula:
            nf = st["nf"]
            if ("#" in nf or "0" in nf) and not any(t in nf.lower() for t in ("yy", "dd", "mm")):
                v = 0.0
        if isinstance(v, str) and v.strip() in NAV_TEXTS:
            v = None
        if isinstance(v, str) and v.startswith("ü"):
            v = "•" + v[1:]  # coche Wingdings du modele
        nf_ = st["nf"]
        if nf_ and "%" in nf_ and isinstance(v, (int, float)) and not isinstance(v, bool) and abs(v) >= 100:
            nf_ = "#,##0"  # montant porte par erreur dans une cellule au format pourcentage (total de note)
        text = fmt_value(v, nf_) if v is not None else ""
        if st.get("white"):
            text = ""
        num = isinstance(v, (int, float)) and not isinstance(v, bool)
        g.cells[(ri[r], ci[col])] = Cell(text, st, num, key, v, key in overrides, is_formula)
    for rng in s["merges"]:
        a, b = rng.split(":")
        ma, mb = CELL_RE.fullmatch(a), CELL_RE.fullmatch(b)
        mr1, mc1, mr2, mc2 = int(ma.group(2)), col2num(ma.group(1)), int(mb.group(2)), col2num(mb.group(1))
        if mr2 < r1 or mr1 > r2 or mc2 < c1 or mc1 > c2:
            continue
        rows_in = [ri[x] for x in range(max(mr1, r1), min(mr2, r2) + 1) if x in ri]
        cols_in = [ci[x] for x in range(max(mc1, c1), min(mc2, c2) + 1) if x in ci]
        if not rows_in or not cols_in:
            continue
        m = (min(rows_in), min(cols_in), max(rows_in), max(cols_in))
        if m[0] == m[2] and m[1] == m[3]:
            continue
        # la cellule d'ancrage doit etre la premiere cellule visible
        if (m[0], m[1]) not in g.cells:
            src = (ri.get(mr1), ci.get(mc1))
            if src in g.cells:
                g.cells[(m[0], m[1])] = g.cells[src]
        g.merges.append(m)
    # bordures des cellules fusionnees : les bords exterieurs viennent des cellules de bord
    return g


def cell_ref_map(grid):
    return {c.ref: pos for pos, c in grid.cells.items() if c.ref}
