"""Tableau des immobilisations et amortissements (fichier des immobilisations).

Calcule, pour l'exercice, les mouvements bruts, les dotations (lineaire, prorata temporis 30/360),
les sorties et les plus ou moins-values, puis alimente les notes 3A, 3C, 3D et l'etat n°9
(detail des amortissements pratiques)."""
import datetime
import re

POSTES = {
    "AE": "Frais de développement et de prospection",
    "AF": "Brevets, licences, logiciels et droits similaires",
    "AG": "Fonds commercial et droit au bail",
    "AH": "Autres immobilisations incorporelles",
    "AJ": "Terrains",
    "AK": "Bâtiments",
    "AL": "Aménagements, agencements et installations",
    "AM": "Matériel, mobilier et actifs biologiques",
    "AN": "Matériel de transport",
    "AP": "Avances et acomptes versés sur immobilisations",
    "AR": "Titres de participation",
    "AS": "Autres immobilisations financières",
}
AMORTISSABLES = {"AE", "AF", "AG", "AH", "AK", "AL", "AM", "AN"}

# lignes des notes du modele par poste
NOTE3A = {"AE": 16, "AF": 14, "AG": 15, "AH": 16, "AJ": 18, "AK": 20, "AL": 22, "AM": 23, "AN": 24,
          "AP": 27, "AR": 29, "AS": 30}
NOTE3C = {"AE": 13, "AF": 14, "AG": 15, "AH": 16, "AK": 18, "AL": 19, "AM": 20, "AN": 21}
NOTE3D = {"AE": 11, "AF": 12, "AG": 13, "AH": 14, "AJ": 16, "AK": 17, "AL": 18, "AM": 19, "AN": 20}


def poste_from_compte(c):
    c = re.sub(r"\D", "", str(c or ""))
    if not c:
        return None
    if c.startswith(("211", "2181", "2191")):
        return "AE"
    if c.startswith(("212", "213", "214", "2193")):
        return "AF"
    if c.startswith(("215", "216")):
        return "AG"
    if c.startswith("21"):
        return "AH"
    if c.startswith("22"):
        return "AJ"
    if c.startswith(("234", "235", "238", "2392", "2393")):
        return "AL"
    if c.startswith("23"):
        return "AK"
    if c.startswith(("245", "2495")):
        return "AN"
    if c.startswith("24"):
        return "AM"
    if c.startswith("25"):
        return "AP"
    if c.startswith("26"):
        return "AR"
    if c.startswith("27"):
        return "AS"
    return None


def to_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    if isinstance(v, str) and v.strip():
        s = v.strip()
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d/%m/%y", "%d-%m-%Y"):
            try:
                return datetime.datetime.strptime(s, fmt).date()
            except ValueError:
                pass
    if isinstance(v, (int, float)) and v > 20000:
        return datetime.date(1899, 12, 30) + datetime.timedelta(days=int(v))
    return None


def to_num(v):
    from .nombres import num as _num
    return _num(v)


def days360(d1, d2):
    """Nombre de jours entre deux dates selon la convention 30/360 (mois de 30 jours)."""
    if d2 <= d1:
        return 0
    day1 = min(d1.day, 30)
    day2 = min(d2.day, 30)
    return (d2.year - d1.year) * 360 + (d2.month - d1.month) * 30 + (day2 - day1)


def compute_asset(a, debut, fin):
    val = to_num(a.get("valeur"))
    taux = to_num(a.get("taux"))
    if taux > 1:
        taux = taux / 100.0
    if not taux and to_num(a.get("duree")):
        taux = 1.0 / to_num(a.get("duree"))
    acq = to_date(a.get("date_acquisition")) or debut
    service = to_date(a.get("date_service")) or acq
    ces = to_date(a.get("date_cession"))
    prix = to_num(a.get("prix_cession"))
    poste = (a.get("poste") or poste_from_compte(a.get("compte")) or "AM").upper()
    amortissable = poste in AMORTISSABLES and taux > 0
    ouv_brut = val if acq < debut else 0.0
    acquisition = val if debut <= acq <= fin else 0.0
    if acq > fin:
        return None
    if ces and ces < debut:
        return None  # sorti avant l'exercice
    sortie = val if (ces and debut <= ces <= fin) else 0.0
    clot_brut = ouv_brut + acquisition - sortie
    # amortissements anterieurs
    if a.get("amort_anterieur") not in (None, ""):
        cum_ouv = to_num(a.get("amort_anterieur")) if acq < debut else 0.0
    elif amortissable and service < debut:
        # jour de debut = 1er jour de l'exercice : on compte jusqu'a la veille (fin de l'exercice precedent)
        cum_ouv = min(val, val * taux * days360(service, debut) / 360.0)
    else:
        cum_ouv = 0.0
    cum_ouv = min(cum_ouv, val)
    dot = 0.0
    if amortissable:
        start = max(service, debut)
        end = ces if sortie else fin
        # fin incluse : le 31/12 vaut une journee pleine
        end_excl = end + datetime.timedelta(days=1)
        dot = val * taux * days360(start, end_excl) / 360.0
        dot = max(0.0, min(dot, val - cum_ouv))
    dot = round(dot)
    cum_ouv = round(cum_ouv)
    cum_total = cum_ouv + dot
    reprise = cum_total if sortie else 0.0
    cum_clot = cum_total - reprise
    vnc_sortie = (val - cum_total) if sortie else 0.0
    pv = (prix - vnc_sortie) if sortie else 0.0
    return {
        "designation": a.get("designation") or "", "reference": a.get("reference") or "",
        "compte": a.get("compte") or "", "poste": poste, "date_service": service, "date_acquisition": acq,
        "valeur": val, "taux": taux, "ouv_brut": ouv_brut, "acquisition": acquisition, "sortie": sortie,
        "clot_brut": clot_brut, "cum_ouv": cum_ouv, "dotation": dot, "reprise": reprise, "cum_clot": cum_clot,
        "vnc": clot_brut - cum_clot, "prix": prix, "vnc_sortie": vnc_sortie, "pv": pv,
        "cession": bool(sortie), "date_cession": ces,
    }


def compute_register(items, debut, fin):
    lines = []
    for idx, a in enumerate(items or []):
        if not (a.get("designation") or a.get("valeur")):
            continue
        r = compute_asset(a, debut, fin)
        if r:
            r["_idx"] = idx
            lines.append(r)
    tot = {}
    for r in lines:
        t = tot.setdefault(r["poste"], {k: 0.0 for k in (
            "ouv_brut", "acquisition", "sortie", "clot_brut", "cum_ouv", "dotation", "reprise", "cum_clot",
            "valeur", "vnc", "prix", "vnc_sortie", "pv", "cess_brut", "cess_amort")})
        for k in ("ouv_brut", "acquisition", "sortie", "clot_brut", "cum_ouv", "dotation", "reprise", "cum_clot",
                  "valeur", "vnc", "prix", "vnc_sortie", "pv"):
            t[k] += r[k]
        if r["cession"]:
            t["cess_brut"] += r["sortie"]
            t["cess_amort"] += r["reprise"]
    return lines, tot


def apply(ev, dossier, fin):
    items = dossier.get("immobilisations") or []
    exo = dossier.get("exercice", {})
    debut = to_date(exo.get("debut"))
    fin = to_date(exo.get("fin")) or fin
    out = {"controles": [], "lignes": [], "totaux": {}}
    if not items or not debut or not fin:
        return out
    lines, tot = compute_register(items, debut, fin)
    out["lignes"], out["totaux"] = lines, tot
    if not lines:
        return out
    opts = dossier.get("options") or {}
    if opts.get("immo_notes", True):
        # Note 3A : acquisitions et cessions issues du tableau des immobilisations
        rows_c = {}
        rows_f = {}
        for p, t in tot.items():
            r = NOTE3A.get(p)
            if r:
                rows_c[r] = rows_c.get(r, 0) + t["acquisition"]
                rows_f[r] = rows_f.get(r, 0) + t["sortie"]
        # seules les lignes des postes presents dans le tableau sont remplacees : les autres
        # (immobilisations financieres, postes non detailles) restent alimentees par la balance
        for r in rows_c:
            ev.set("NOTE 3A ", f"C{r}", rows_c.get(r, 0) or None)
            ev.set("NOTE 3A ", f"F{r}", rows_f.get(r, 0) or None)
        # Note 3C : dotations et amortissements des elements sortis
        rows3c = {}
        for p, r in NOTE3C.items():
            t = tot.get(p)
            if t:
                d_, e_ = rows3c.get(r, (0.0, 0.0))
                rows3c[r] = (d_ + t["dotation"], e_ + t["reprise"])
        for r, (d_, e_) in rows3c.items():
            ev.set("NOTE 3C", f"D{r}", d_ or None)
            ev.set("NOTE 3C", f"E{r}", e_ or None)
        # Note 3D : cessions
        for p, r in NOTE3D.items():
            t = tot.get(p)
            if t and t["cess_brut"]:
                ev.set("NOTE 3D", f"B{r}", t["cess_brut"])
                ev.set("NOTE 3D", f"C{r}", t["cess_amort"])
                ev.set("NOTE 3D", f"E{r}", t["prix"])
        _sum_rows(ev, "NOTE 3D", "BCE", 15, [11, 12, 13, 14])
        _sum_rows(ev, "NOTE 3D", "BCE", 21, [16, 17, 18, 19, 20])
        _sum_rows(ev, "NOTE 3D", "BCE", 22, [15, 21])
    # Etat n°9 : detail des amortissements pratiques (14 lignes)
    amortis = [l for l in lines if l["poste"] in AMORTISSABLES]
    if len(amortis) <= 14:
        rows = amortis
        out["annexe"] = False
    else:
        # regroupement par poste, detail complet en annexe
        rows = []
        for p in sorted({l["poste"] for l in amortis}):
            ls = [l for l in amortis if l["poste"] == p]
            rows.append({"designation": POSTES[p] + f" ({len(ls)} biens)", "reference": "Voir annexe",
                         "date_service": None, "valeur": sum(l["valeur"] for l in ls), "taux": None,
                         "dotation": sum(l["dotation"] for l in ls), "cum_ouv": sum(l["cum_ouv"] for l in ls),
                         "cum_clot": sum(l["cum_clot"] for l in ls), "vnc": sum(l["vnc"] for l in ls),
                         "clot_brut": sum(l["clot_brut"] for l in ls)})
        out["annexe"] = True
    sh = "DETAILS DES AMORTS"
    for i in range(14):
        r = 12 + i
        l = rows[i] if i < len(rows) else None
        vals = [None] * 9
        if l:
            vals = [l["designation"], l.get("reference"), l.get("date_service"), l["valeur"],
                    l.get("taux"), l["dotation"], l["cum_ouv"], l["cum_ouv"] + l["dotation"],
                    l["valeur"] - l["cum_ouv"] - l["dotation"]]
        for col, v in zip("ABCDEFGHI", vals):
            ev.set(sh, f"{col}{r}", v)
    # controles tableau / balance
    def bal(sheet, addr):
        v = ev.get(sheet, addr)
        try:
            return float(v or 0)
        except (TypeError, ValueError):
            return 0.0
    brut_reg = sum(t["clot_brut"] for p, t in tot.items() if p not in ("AR", "AS", "AP"))
    brut_bal = bal("Bilan modèle 1", "D10") + bal("Bilan modèle 1", "D15")
    out["controles"].append(("Tableau d'amortissement : brut incorporel + corporel = balance", brut_reg, brut_bal,
                             abs(brut_reg - brut_bal) < 1))
    amo_reg = sum(t["cum_clot"] for t in tot.values())
    amo_bal = bal("NOTE 3C", "F23")
    out["controles"].append(("Tableau d'amortissement : amortissements cumulés = comptes 28", amo_reg, amo_bal,
                             abs(amo_reg - amo_bal) < 1))
    dot_reg = sum(t["dotation"] for t in tot.values())
    dot_bal = bal("Balance std", "F641") - bal("Balance std", "G641")
    out["controles"].append(("Tableau d'amortissement : dotations = comptes 681", dot_reg, dot_bal,
                             abs(dot_reg - dot_bal) < 1))
    return out


def _sum_rows(ev, sheet, cols, target, rows):
    from .formula import parse_formula
    for col in cols:
        txt = "=" + "+".join(f"{col}{r}" for r in rows)
        ev.formulas[(sheet, f"{col}{target}")] = parse_formula(txt, sheet)
        ev.cells.pop((sheet, f"{col}{target}"), None)
    ev.reset_cache()
