"""Export Excel de la liasse : une feuille par page, mise en page A4 identique au PDF."""
import io
import re
import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins

from .pages import PAGES
from .book import count_and_grids
from .pdf import wrap_lines, font_name, register_fonts

SIDES = {}


def side(style):
    if not style:
        return Side()
    if style not in SIDES:
        SIDES[style] = Side(style=style if style in (
            "hair", "thin", "medium", "thick", "double", "dotted", "dashed", "dashDot", "dashDotDot",
            "mediumDashed", "mediumDashDot", "mediumDashDotDot", "slantDashDot") else "thin", color="000000")
    return SIDES[style]


def excel_numfmt(nf, value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    if nf and "%" in nf:
        return nf if abs(value) < 100 else '#,##0;-#,##0;"-"'
    if nf and any(t in nf.lower() for t in ("yy", "dd")) and "#" not in nf:
        return "dd/mm/yyyy"
    if nf in (None, "General", "@"):
        return "General" if abs(value) < 10000 or not float(value).is_integer() else '#,##0'
    if "#,##0" in nf or '"-"' in nf:
        if "\\(" in nf:
            return '#,##0;(#,##0);"-"'
        return '#,##0;-#,##0;"-"'
    return nf


def sheet_title(pid, title, used):
    t = re.sub(r"[\\/*?:\[\]]", "-", title)[:28]
    base = t
    k = 2
    while t in used:
        t = (base[:25] + f" {k}")
        k += 1
    used.add(t)
    return t


def write_grid(ws, g):
    # colonnes / lignes
    for j, w in enumerate(g.cols, 1):
        ws.column_dimensions[get_column_letter(j)].width = max(0.5, (w / 0.75 - 5) / 7)
    for i, h in enumerate(g.rows, 1):
        ws.row_dimensions[i].height = max(1, h)
    merge_idx = g.merge_at()
    fonts = {}
    for (i, j), c in g.cells.items():
        st = c.st
        cell = ws.cell(row=i + 1, column=j + 1)
        m = merge_idx.get((i, j))
        anchor = (m is None) or ((i, j) == (m[0], m[1]))
        if anchor and c.text:
            v = c.value
            if isinstance(v, (int, float)) and not isinstance(v, bool) and c.num:
                cell.value = v
                nf = excel_numfmt(st.get("nf"), v)
                if nf:
                    cell.number_format = nf
            elif isinstance(v, (datetime.date, datetime.datetime)):
                cell.value = v
                cell.number_format = "dd/mm/yyyy"
            else:
                cell.value = c.text
        key = (st.get("b"), st.get("i"), st.get("u"), st.get("size"))
        if key not in fonts:
            fonts[key] = Font(name="Arial", bold=bool(st.get("b")), italic=bool(st.get("i")),
                              underline="single" if st.get("u") else None, size=st.get("size") or 10)
        cell.font = fonts[key]
        ha = st.get("ha")
        if ha in (None, "general"):
            ha = "right" if c.num else "left"
        if ha == "centerContinuous":
            ha = "center"
        rot = st.get("rot") or 0
        cell.alignment = Alignment(horizontal=ha if ha in ("left", "right", "center", "justify", "distributed", "fill") else None,
                                   vertical={"center": "center", "top": "top"}.get(st.get("va"), "bottom"),
                                   wrap_text=bool(st.get("wrap")) or ("\n" in (c.text or "")),
                                   text_rotation=rot if rot in range(0, 181) else 0,
                                   indent=st.get("ind") or 0, shrink_to_fit=not st.get("wrap"))
        if st.get("bg"):
            cell.fill = PatternFill("solid", fgColor="FF" + st["bg"])
        if any(st.get(k) for k in ("bl", "br", "bt", "bb")):
            cell.border = Border(left=side(st.get("bl")), right=side(st.get("br")),
                                 top=side(st.get("bt")), bottom=side(st.get("bb")))
    for m in g.merges:
        i1, j1, i2, j2 = m
        try:
            ws.merge_cells(start_row=i1 + 1, start_column=j1 + 1, end_row=i2 + 1, end_column=j2 + 1)
        except Exception:
            pass
    # zones de texte -> lignes fusionnees avec retour a la ligne
    if g.textboxes:
        _textboxes(ws, g)
    # images
    for (x, y, w, h, path) in g.images:
        try:
            from openpyxl.drawing.image import Image as XImage
            img = XImage(path)
            img.width, img.height = w / 0.75, h / 0.75
            col, row = _pos(g, x, y)
            ws.add_image(img, f"{get_column_letter(col)}{row}")
        except Exception:
            pass
    # mise en page
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = "landscape" if g.orient == "L" else "portrait"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.page_margins = PageMargins(left=0.35, right=0.35, top=0.35, bottom=0.35, header=0.1, footer=0.1)
    ws.print_options.horizontalCentered = True
    ws.sheet_view.showGridLines = False
    ws.print_area = f"A1:{get_column_letter(max(1, len(g.cols)))}{max(1, len(g.rows) + _extra_rows(ws, g))}"


def _extra_rows(ws, g):
    return getattr(ws, "_extra", 0)


def _pos(g, x, y):
    acc, col = 0, 1
    for j, w in enumerate(g.cols, 1):
        if acc + w > x:
            col = j
            break
        acc += w
    acc, row = 0, 1
    for i, h in enumerate(g.rows, 1):
        if acc + h > y:
            row = i
            break
        acc += h
    return col, row


def _textboxes(ws, g):
    """Les cadres de texte sont ecrits sous forme de paragraphes (une ligne fusionnee par paragraphe)."""
    register_fonts()
    ncol = len(g.cols)
    width = sum(g.cols)
    for tb in g.textboxes:
        col, row = _pos(g, tb["x"] + 1, tb["y"] + 1)
        # on insere les paragraphes a partir de la ligne de la zone, en ajoutant des lignes si besoin
        r = row
        for p in tb["paras"]:
            font = font_name({"b": p.get("b", tb.get("bold"))})
            size = 10 * p.get("k", 1)
            lines = wrap_lines(p["t"], font, size, width * 0.95)
            h = max(14, len(lines) * size * 1.25 + 3)
            if r > len(g.rows):
                ws._extra = getattr(ws, "_extra", 0) + 1
            ws.row_dimensions[r].height = h
            try:
                ws.unmerge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            except Exception:
                pass
            c = ws.cell(row=r, column=1, value=p["t"].strip())
            c.font = Font(name="Arial", size=size, bold=bool(p.get("b", tb.get("bold"))), italic=bool(p.get("i")))
            c.alignment = Alignment(wrap_text=True, vertical="top",
                                    horizontal="center" if tb.get("align") == "center" else "left")
            if ncol > 1:
                try:
                    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
                except Exception:
                    pass
            r += 1


def export_xlsx(res, selection=None):
    wb = Workbook()
    wb.remove(wb.active)
    used = set()
    grids = count_and_grids(res, selection)
    counter = {}
    for n, (pid, g) in enumerate(grids, 1):
        title = PAGES[pid][2]
        counter[pid] = counter.get(pid, 0) + 1
        if counter[pid] > 1:
            title = f"{title} ({counter[pid]})"
        ws = wb.create_sheet(sheet_title(pid, f"{n:02d} {title}", used))
        write_grid(ws, g)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue(), len(grids)
