"""Moteur : applique un dossier (societe, balances, parametres, saisies) au modele et calcule la liasse."""
import datetime
import os
import re

from .formula import Evaluator, XLError, CELL_RE
from .nombres import num as _num, parse as _parse_num
from .model import get_model, BAL
from . import immobilisations as immo
from . import declarations as decl

R1 = "Fiche R1"
R2 = "Fiche R2"
PASS_ = "TABLEAU DE PASSAGE"
# cellules des pages 73 (tableau de passage) et 86 (bordereau) reliees aux parametres fiscaux
PARAM_CELLS = {
    (PASS_, "G57"): "acompte1", (PASS_, "G58"): "acompte2", (PASS_, "G59"): "acompte3",
    (PASS_, "G60"): "credit_impot", (PASS_, "G61"): "precomptes", (PASS_, "G67"): "factures_sans_nif",
    (PASS_, "G44"): "tap_n1", (PASS_, "G27"): "conges_n",
    ("BORDEREAU", "O32"): "acompte1", ("BORDEREAU", "O33"): "acompte2", ("BORDEREAU", "O34"): "acompte3",
    ("BORDEREAU", "O35"): "credit_impot", ("BORDEREAU", "O36"): "precomptes",
}

# ---------------------------------------------------------------- identite
# (cle, libelle, groupe, feuille, cellule, type)
FIELDS = [
    ("denomination", "Dénomination sociale", "identite", R1, "H3", "text"),
    ("sigle", "Sigle usuel", "identite", R1, "S4", "text"),
    ("adresse", "Adresse", "identite", R1, "D4", "text"),
    ("nif", "N° d'identification fiscale (NIF)", "identite", R1, "G5", "text"),
    ("ntd", "N° de télédéclarant (NTD)", "identite", R1, "H6", "text"),
    ("greffe", "Greffe (RCCM)", "identite", R1, "C15", "text"),
    ("rccm", "N° Registre du commerce", "identite", R1, "D15", "text"),
    ("repertoire", "N° répertoire des entités", "identite", R1, "K15", "text"),
    ("cnss", "N° de caisse sociale (CNSS)", "identite", R1, "C18", "text"),
    ("code_importateur", "N° code importateur", "identite", R1, "F18", "text"),
    ("code_activite", "Code activité principale", "identite", R1, "Q18", "text"),
    ("telephone", "Téléphone", "identite", R1, "C24", "text"),
    ("email", "Adresse email", "identite", R1, "E24", "text"),
    ("code_postal", "Code", "identite", R1, "K24", "text"),
    ("bp", "Boîte postale", "identite", R1, "N24", "text"),
    ("ville", "Ville", "identite", R1, "Q24", "text"),
    ("activite", "Activité principale exercée", "identite", R1, "C30", "text"),
    ("capacite", "% capacité de production utile", "identite", R1, "P30", "text"),
    ("contact", "Personne à contacter (nom, adresse, tél., email, qualité)", "identite", R1, "C33", "text"),
    ("comptable", "Salarié ou professionnel comptable ayant établi les états", "identite", R1, "C36", "text"),
    ("expert_visa", "Expert-comptable (attestation de visa)", "identite", R1, "C40", "text"),
    ("cac", "Expert-comptable / commissaire aux comptes", "identite", R1, "C44", "text"),
    ("signataire", "Nom du signataire des états financiers", "identite", R1, "C53", "text"),
    ("qualite_signataire", "Qualité du signataire", "identite", R1, "C56", "text"),
    ("date_signature", "Date de signature", "identite", R1, "C59", "date"),
    # exercice
    ("annee", "Exercice (année)", "exercice", R1, "F9", "int"),
    ("debut", "Début de l'exercice", "exercice", R1, "N9", "date"),
    ("fin", "Clôture de l'exercice", "exercice", R1, "S9", "date"),
    ("duree", "Durée (mois)", "exercice", R1, "U5", "int"),
    ("date_arrete", "Date d'arrêté effectif des comptes", "exercice", R1, "H11", "date"),
    ("prec_fin", "Exercice précédent clos le", "exercice", R1, "H13", "date"),
    ("prec_duree", "Durée exercice précédent (mois)", "exercice", R1, "U13", "int"),
]

# Codes a deux chiffres de la fiche R2
CODE_FIELDS = [
    ("forme_juridique", "Forme juridique (code 2 chiffres)", ("Q9", "R9")),
    ("regime_fiscal", "Régime fiscal (code)", ("Q11",)),
    ("pays_siege", "Pays du siège social (code 2 chiffres)", ("Q13", "R13")),
    ("nb_etab_pays", "Nombre d'établissements dans le pays", ("Q15", "R15")),
    ("nb_etab_hors", "Établissements hors du pays (compta distincte)", ("Q17", "R17")),
    ("premiere_annee", "Première année d'exercice dans le pays (4 chiffres)", ("Q20", "R20", "S20", "T20")),
]

DEFAULT_PARAMS = {
    "taux_imf": 0.0175, "taux_isb": 0.30, "imf_minimum": 0,
    "acompte1": 0, "acompte2": 0, "acompte3": 0, "credit_impot": 0, "precomptes": 0,
    "factures_sans_nif": 0, "tap_n1": 0, "conges_n": 0, "conges_n1": 0,
    "ard_anterieurs": 0,
    "deficit_orig_0": 0, "deficit_orig_1": 0, "deficit_orig_2": 0,
    "deficit_impute_0": 0, "deficit_impute_1": 0, "deficit_impute_2": 0,
    "deficit_annee_0": "", "deficit_annee_1": "", "deficit_annee_2": "",
    "nb_exemplaires": 4, "tap_reintegrer": True, "taux_tcfge": 0.28,
    "imputer_credit": True,
}


def parse_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    if isinstance(v, str):
        v = v.strip()
        try:
            m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})(?:[T ].*)?", v)
            if m:
                return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            m = re.fullmatch(r"(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})", v)
            if m:
                return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    return v


def norm_account(c):
    s = str(c).strip()
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return re.sub(r"\D", "", s)


class Mapper:
    """Ventilation d'un compte client vers une ligne de la balance standard SYSCOHADA du modele."""

    def __init__(self, model, overrides=None):
        self.model = model
        self.leaf = model.leaf_rows
        self.keys = sorted(self.leaf, key=lambda k: (k, len(k)))
        self.overrides = {}
        for k, v in (overrides or {}).items():
            try:
                if v not in (None, "", 0, "0"):
                    self.overrides[norm_account(k)] = int(float(v))
            except (TypeError, ValueError):
                pass

    def row_for(self, account, solde=None):
        a = norm_account(account)
        if not a:
            return None, "invalide"
        if a in self.overrides:
            return self.overrides[a], "manuel"
        for L in range(len(a), 0, -1):
            p = a[:L]
            if p in self.leaf:
                return self.leaf[p][0], "auto"
        # compte absent du plan standard : on cherche, parmi les sous-comptes du plus long prefixe commun,
        # la ligne qui alimente le poste prevu par le plan SYSCOHADA pour ce compte et le sens de son solde
        from . import plan
        side = "C" if (solde or 0) < 0 else "D"
        cible = plan.attendu(a, side)
        sens = plan.sensibilite(self.model)
        t = a.rstrip("0") or a
        for L in range(len(t), 1, -1):
            p = t[:L]
            kids = [k for k in self.keys if k.startswith(p)]
            if kids:
                bons = [k for k in kids if cible and sens.get(self.leaf[k][0], {}).get(side) == [cible]]
                if not bons and cible:
                    # poste prevu introuvable sous ce prefixe : on elargit a toute la classe de comptes
                    bons = [k for k in self.keys if k[:1] == a[:1] and sens.get(self.leaf[k][0], {}).get(side) == [cible]]
                    bons.sort(key=lambda k: (-len(os.path.commonprefix([k, a])), len(k)))
                    if bons:
                        return self.leaf[bons[0]][0], "approx"
                pool = bons or kids
                # on privilegie le sous-compte "autres" (terminaison 8) s'il existe
                autres = [k for k in pool if len(k) == len(p) + 1 and k.endswith("8")]
                k = autres[0] if autres else pool[0]
                return self.leaf[k][0], "approx" if len(p) <= 2 else "auto"
        return None, "non ventilé"


class Result:
    def __init__(self, ev, overrides, model, dossier, info):
        self.ev = ev
        self.overrides = overrides
        self.model = model
        self.dossier = dossier
        self.info = info

    def value(self, sheet, addr):
        v = self.ev.get(sheet, addr)
        if isinstance(v, XLError):
            return v
        return v

    def num(self, sheet, addr):
        v = self.ev.get(sheet, addr)
        try:
            return float(v or 0)
        except (TypeError, ValueError):
            return 0.0


def balance_rows(entries):
    out = []
    for e in entries or []:
        acc = norm_account(e.get("compte", ""))
        if not acc:
            continue
        sd = _num(e.get("sd"))
        sc = _num(e.get("sc"))
        out.append((acc, e.get("intitule", ""), sd - sc))
    return out


def compute(dossier):
    model = get_model()
    cells = dict(model.consts)
    formulas = dict(model.formulas)
    ev = Evaluator(cells, formulas)
    info = {"non_ventiles": [], "approx": [], "totaux": {}, "inverses": []}

    # Nettoyage de cellules parasites du modele d'origine
    for sh, a in ((R1, "H4"), (R1, "L5"), (R1, "C21"), (R1, "C27")):
        ev.set(sh, a, None)
    # colonne N-1 du TFT du dossier d'origine du modele : a reprendre du dossier N-1 de chaque entite
    for a in ("I12", "I15", "I16", "I18", "I19", "I27", "K17"):
        ev.set("TFT", a, None)
    ident = dossier.get("identite", {})
    exo = dossier.get("exercice", {})

    # ------------------------------------------------------------ balances
    mapper = Mapper(model, dossier.get("mapping"))
    for label, key, cols in (("N", "balance_n", ("F", "G")), ("N-1", "balance_n1", ("D", "E"))):
        acc = {}
        tot_d = tot_c = 0.0
        for a, lib, solde in balance_rows(dossier.get(key)):
            row, how = mapper.row_for(a, solde)
            if solde >= 0:
                tot_d += solde
            else:
                tot_c += -solde
            if row is None:
                if abs(solde) > 0.5:
                    info["non_ventiles"].append((label, a, lib, solde))
                continue
            if how == "approx" and abs(solde) > 0.5:
                info["approx"].append((label, a, lib, row))
            d, c = acc.setdefault(row, [0.0, 0.0])
            if solde >= 0:
                acc[row][0] += solde
            else:
                acc[row][1] += -solde
        # un solde porte du cote que le modele ne reprend pas (amortissement debiteur, immobilisation
        # crediteur, depreciation de stock debitrice...) est presente en diminution du meme poste
        from . import plan
        sens = plan.sensibilite(model)
        lib_row = {r: (ac, lb) for r, ac, lb, _ in model.leaf_info}
        for row, (d, c) in list(acc.items()):
            sr = sens.get(row) or {}
            if d and not sr.get("D") and sr.get("C"):
                info["inverses"].append((label, lib_row[row][0], lib_row[row][1], d, sr["C"][0]))
                acc[row] = [0.0, c - d]
            elif c and not sr.get("C") and sr.get("D"):
                info["inverses"].append((label, lib_row[row][0], lib_row[row][1], -c, sr["D"][0]))
                acc[row] = [d - c, 0.0]
        for row, (d, c) in acc.items():
            if d:
                ev.set(BAL, f"{cols[0]}{row}", round(d, 2))
            if c:
                ev.set(BAL, f"{cols[1]}{row}", round(c, 2))
        info["totaux"][label] = (tot_d, tot_c)

    # ------------------------------------------------------------ identite
    exo = dict(exo)
    try:
        an_ = int(exo.get("annee") or (str(exo.get("fin") or "")[:4]) or 0)
    except ValueError:
        an_ = 0
    if an_:
        exo.setdefault("annee", an_)
        for k_, v_ in (("debut", f"{an_}-01-01"), ("fin", f"{an_}-12-31"), ("prec_fin", f"{an_ - 1}-12-31")):
            if not exo.get(k_):
                exo[k_] = v_
        for k_ in ("duree", "prec_duree"):
            if not exo.get(k_):
                exo[k_] = 12
    for key, lab, grp, sh, addr, typ in FIELDS:
        src = ident if grp == "identite" else exo
        v = src.get(key)
        if v in (None, ""):
            ev.set(sh, addr, None)
            continue
        if typ == "date":
            v = parse_date(v)
        elif typ == "int":
            try:
                v = int(v)
            except (TypeError, ValueError):
                pass
        ev.set(sh, addr, v)
    fin = parse_date(exo.get("fin")) if exo.get("fin") else None
    ev.set(R1, "M5", fin)
    ev.set(R1, "C21", ident.get("denomination"))
    ev.set(R1, "Q21", ident.get("sigle"))
    ev.set(R1, "C27", ident.get("adresse_complete") or ident.get("adresse"))
    for key, lab, addrs in CODE_FIELDS:
        v = str(ident.get(key) or "").strip()
        if not v:
            for a in addrs:
                ev.set(R2, a, None)
            continue
        if key == "premiere_annee":
            v = re.sub(r"\D", "", v)
            if len(v) == 2:
                v = ("19" if int(v) > 50 else "20") + v
            v = v[:4]
        digits = v.zfill(len(addrs))[-len(addrs):]
        for a, ch in zip(addrs, digits):
            ev.set(R2, a, int(ch) if ch.isdigit() else ch)

    # activites (fiche R2)
    acts = [a for a in (dossier.get("activites") or []) if isinstance(a, dict) and (a.get("designation") or a.get("ca"))]
    if acts:
        for k in range(9):
            r = 29 + 3 * k
            a = acts[k] if k < len(acts) else {}
            ev.set(R2, f"A{r}", a.get("designation"))
            ev.set(R2, f"P{r}", a.get("code"))
            ca = a.get("ca")
            if a and (ca in (None, "") or a.get("auto")):
                continue
            ev.set(R2, f"Z{r}", _parse_num(ca) if ca not in (None, "") else None)

    # --------------------------------------------------- immobilisations
    res_immo = immo.apply(ev, dossier, fin)
    info["immo"] = res_immo

    # --------------------------------------------------- parametres fiscaux
    params = dict(DEFAULT_PARAMS)
    for k, v in (dossier.get("params") or {}).items():
        if v not in (None, ""):
            params[k] = v
    from .nombres import parse as _parse
    info["params_invalides"] = []
    for k in list(params):
        if isinstance(params[k], str) and not k.startswith("deficit_annee"):
            f = _parse(params[k])
            if f is None:
                if params[k].strip():
                    info["params_invalides"].append((k, params[k]))
                params[k] = 0.0
            else:
                params[k] = f
    for k in ("taux_imf", "taux_isb", "taux_tcfge"):
        try:
            if float(params.get(k) or 0) > 1:
                params[k] = float(params[k]) / 100
        except (TypeError, ValueError):
            pass
    # anciens dossiers : acomptes saisis comme cellules des pages 73 / 86 -> parametres
    for ref, key in PARAM_CELLS.items():
        v = (dossier.get("cells") or {}).get("!".join(ref))
        if v not in (None, ""):
            f = _parse_num(v) if isinstance(v, str) else v
            if isinstance(f, (int, float)):
                params[key] = f
                params[key + "_manuel"] = True
    # annees des deficits reportables : N-3, N-2, N-1 par defaut
    if an_:
        for i_ in range(3):
            if not str(params.get(f"deficit_annee_{i_}") or "").strip():
                params[f"deficit_annee_{i_}"] = str(an_ - 3 + i_)
    ev.params = params
    # registre des acomptes / precomptes (releves de douane, banques, clients)
    from . import reglements
    info["reglements"] = reglements.apply_params(dossier, params)
    # declarations TAP / TCFGE (calculees depuis la balance et les saisies)
    decl.prepare(ev, dossier, params)
    if params.get("tap_reintegrer") in (True, 1, 1.0, "1", "oui"):
        params["tap_reintegree"] = params.get("tap_total", 0)
    else:
        params["tap_reintegree"] = float(params.get("tap_reintegree_saisie") or 0)
    params["nb_pages"] = dossier.get("_nb_pages") or ""

    # --------------------------------------------------- saisies directes
    overrides = {}
    for ref, v in (dossier.get("cells") or {}).items():
        if "!" not in ref:
            continue
        sh, addr = ref.rsplit("!", 1)
        if (sh, addr) in PARAM_CELLS:
            continue
        if sh not in model.sheets:
            continue
        if isinstance(v, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", v.strip()):
            v = parse_date(v)
        ev.set(sh, addr, v)
        overrides[(sh, addr)] = v
    ev.reset_cache()
    # commentaire de la note 3A redige a partir des montants (le modele contenait des « XXXX »)
    if ("NOTE 3A ", "A34") not in overrides:
        def f(sh, a):
            try:
                return float(ev.get(sh, a) or 0)
            except (TypeError, ValueError):
                return 0.0
        def m(v):
            return f"{round(v):,d}".replace(",", " ")
        N3 = "NOTE 3A "
        corp, corp0, acq = f(N3, "H17"), f(N3, "B17"), f(N3, "C17")
        sorties = f(N3, "F17") + f(N3, "G17")
        inc, fin_ = f(N3, "H13"), f("Bilan modèle 1", "D24")
        txt = ("Les immobilisations sont inscrites au bilan à leur coût d'acquisition (valeur historique) et amorties "
               "selon le mode linéaire. ")
        if corp or corp0:
            txt += f"Les immobilisations corporelles s'élèvent à {m(corp)} F CFA en valeur brute à la clôture, contre {m(corp0)} F CFA à l'ouverture"
            det = []
            if acq:
                det.append(f"des acquisitions de {m(acq)} F CFA")
            if sorties:
                det.append(f"des sorties de {m(sorties)} F CFA")
            txt += (", compte tenu " + " et ".join(det) if det else "") + ". "
        if inc:
            txt += f"Les immobilisations incorporelles représentent {m(inc)} F CFA en valeur brute. "
        if fin_:
            txt += f"Les immobilisations financières (titres, dépôts et cautionnements) s'élèvent à {m(fin_)} F CFA."
        ev.set(N3, "A34", txt.strip())
    # libelles des taux du calcul de l'impot (tableau de passage)
    def _pc(x):
        try:
            return f"{float(x) * 100:.2f}".rstrip("0").rstrip(".").replace(".", ",") + " %"
        except (TypeError, ValueError):
            return ""
    ev.set(PASS_, "C53", f"X   {_pc(params.get('taux_imf'))}   =")
    ev.set(PASS_, "C54", f"X   {_pc(params.get('taux_isb'))}   =")
    ev.set(PASS_, "A54", f"Impôt ISB à {_pc(params.get('taux_isb'))} =")
    ev.set("BORDEREAU", "A54", f"TCFGE {_pc(params.get('taux_tcfge'))}")
    da = parse_date(exo.get("date_arrete")) if exo.get("date_arrete") else None
    if ("NOTE 37", "A9") not in overrides and isinstance(da, datetime.date):
        ev.set("NOTE 37", "A9", f"Date d'arrêté des états financiers : {da.strftime('%d/%m/%Y')}")
    if ("NOTE 27A", "A18") not in overrides:
        def g(a):
            try:
                return float(ev.get("NOTE 27A", a) or 0)
            except (TypeError, ValueError):
                return 0.0
        n, n1 = g("F16"), g("G16")
        mm = lambda v: f"{round(v):,d}".replace(",", " ")
        if n1 and n:
            var = (n - n1) / abs(n1) * 100
            sens = "hausse" if var > 0.5 else "baisse" if var < -0.5 else "stabilité"
            t = (f"Les charges de personnel s'établissent à {mm(n)} F CFA contre {mm(n1)} F CFA pour l'exercice précédent"
                 + (f", soit une {sens} de {abs(var):.1f} %".replace(".", ",") if sens != "stabilité" else ", un niveau stable")
                 + ".")
        elif n:
            t = f"Les charges de personnel s'élèvent à {mm(n)} F CFA."
        else:
            t = ""
        ev.set("NOTE 27A", "A18", t)
    res = Result(ev, overrides, model, dossier, info)
    try:
        from .notes_na import statut
        statut(res)          # fiche R4 : A / N/A selon les notes reellement chiffrees
    except Exception as e:  # pragma: no cover - jamais bloquant
        info.setdefault("avertissements", []).append(f"Fiche R4 : statut des notes non determine ({e})")
    return res


# ---------------------------------------------------------------- controles
BM = "Bilan modèle 1"
CR_CHARGES = ["H11", "H12", "H23", "H24", "H25", "H26", "H27", "H28", "H29", "H30", "H32", "H35", "H40", "H41"]
CHECKS = [
    ("Bilan N : total actif = total passif", lambda r: r.num(BM, "F40"), lambda r: r.num(BM, "K40")),
    ("Bilan N-1 : total actif = total passif", lambda r: r.num(BM, "G40"), lambda r: r.num(BM, "L40")),
    ("TFT : trésorerie nette au 31/12 = trésorerie actif - trésorerie passif", lambda r: r.num("TFT", "H42"),
     lambda r: r.num(BM, "F38") - r.num(BM, "K38")),
    ("TFT : trésorerie au 1er janvier = trésorerie nette N-1", lambda r: r.num("TFT", "H12"),
     lambda r: r.num(BM, "G38") - r.num(BM, "L38")),
    ("Note 3A : brut des immobilisations incorporelles = bilan", lambda r: r.num("NOTE 3A ", "H13"), lambda r: r.num(BM, "D10")),
    ("Note 3A : brut des immobilisations corporelles = bilan", lambda r: r.num("NOTE 3A ", "H17"), lambda r: r.num(BM, "D15")),
    ("Note 3A : ouverture + augmentations - diminutions = clôture", lambda r: r.num("NOTE 3A ", "B31") + r.num("NOTE 3A ", "C31")
     + r.num("NOTE 3A ", "D31") + r.num("NOTE 3A ", "E31") - r.num("NOTE 3A ", "F31") - r.num("NOTE 3A ", "G31"),
     lambda r: r.num("NOTE 3A ", "H31")),
    ("Note 3C : amortissements cumulés = bilan (hors dépréciations 29)", lambda r: r.num("NOTE 3C", "F23"),
     lambda r: r.num(BM, "E10") + r.num(BM, "E15") - sum(r.num("Balance std", f"G{x}") - r.num("Balance std", f"F{x}")
                                                         for x in (213, 214, 215, 216, 217, 227, 228, 239, 240))),
    ("Note 3C : ouverture + dotations - sorties = clôture", lambda r: r.num("NOTE 3C", "B23") + r.num("NOTE 3C", "D23")
     - r.num("NOTE 3C", "E23"), lambda r: r.num("NOTE 3C", "F23")),
    ("Note 3C : dotations = comptes 681", lambda r: r.num("NOTE 3C", "D23"),
     lambda r: r.num("Balance std", "F641") - r.num("Balance std", "G641")),
    ("Note 7 : clients = bilan", lambda r: r.num("NOTE 7", "B17"), lambda r: r.num(BM, "D32")),
    ("Note 8 : autres créances = bilan", lambda r: r.num("NOTE 8", "C22"), lambda r: r.num(BM, "F33")),
    ("Note 11 : disponibilités = bilan", lambda r: r.num("NOTE 11", "F23"), lambda r: r.num(BM, "F37")),
    ("Note 17 : fournisseurs = bilan", lambda r: r.num("NOTE 17", "D19"), lambda r: r.num(BM, "K30")),
    ("Note 18 : dettes fiscales et sociales = bilan", lambda r: r.num("NOTE 18", "C27"), lambda r: r.num(BM, "K31")),
    ("Note 19 : autres dettes = bilan", lambda r: r.num("NOTE 19", "C30"), lambda r: r.num(BM, "K32")),
    ("Note 21 : chiffre d'affaires = compte de résultat", lambda r: r.num("NOTE 21", "F32"), lambda r: r.num("RESULTAT", "H17")),
    ("Note 27A : charges de personnel = compte de résultat", lambda r: r.num("NOTE 27A", "F16"), lambda r: -r.num("RESULTAT", "H32")),
    ("État n°1 : total des charges = compte de résultat", lambda r: r.num("COMP CHARGES", "G276"),
     lambda r: -sum(r.num("RESULTAT", a) for a in CR_CHARGES)),
    ("État n°7 : capitaux propres à la clôture = bilan", lambda r: r.num("EVOLUTION CAPITAUX PROPRES", "H21"),
     lambda r: r.num(BM, "K22")),
    ("Bordereau : total à payer = impôt dû − acomptes − crédit − précomptes + TAP + TCFGE", lambda r: r.num("BORDEREAU", "X57"),
     lambda r: _total_attendu(r)),
    ("Passage : impôt dû = max(ISB, IMF)", lambda r: max(r.num("TABLEAU DE PASSAGE", "F53"), r.num("TABLEAU DE PASSAGE", "F54")),
     lambda r: max(r.num("TABLEAU DE PASSAGE", "D53"), r.num("TABLEAU DE PASSAGE", "D54"), float(r.ev.params.get("imf_minimum") or 0))),
    ("Passage : résultat comptable = compte de résultat", lambda r: r.num("TABLEAU DE PASSAGE", "G12") + r.num("TABLEAU DE PASSAGE", "G13"),
     lambda r: r.num("RESULTAT", "H51") - r.num("RESULTAT", "H50")),
]


def _total_attendu(r):
    P = "TABLEAU DE PASSAGE"
    du = max(r.num(P, "F53"), r.num(P, "F54"))
    ded = sum(r.num(P, a) for a in ("G57", "G58", "G59", "G60", "G61"))
    p = r.ev.params
    autres = float(p.get("tap_total") or 0) + float(p.get("tcfge_montant") or 0)
    if p.get("imputer_credit") in (False, 0, 0.0, "0", "non"):
        return max(0.0, du - ded) + autres
    return max(0.0, du - ded + autres)


def run_checks(res):
    out = []
    t = res.info["totaux"]
    for lab in ("N", "N-1"):
        if lab in t:
            d, c = t[lab]
            out.append((f"Balance {lab} équilibrée (débit = crédit)", d, c, abs(d - c) < 1))
    for label, a, b in CHECKS:
        try:
            va, vb = a(res), b(res)
        except Exception:
            continue
        out.append((label, va, vb, abs(va - vb) < 1))
    nv = res.info["non_ventiles"]
    out.append(("Comptes de la balance tous ventilés", len(nv), 0, len(nv) == 0))
    for c in res.info.get("immo", {}).get("controles", []):
        out.append(c)
    return out


def _chk_val(res, spec):
    try:
        if spec[0] == "=":
            _, sh, a, op, b = spec
            return res.num(sh, a) - res.num(sh, b)
        if spec[0] == "=-":
            return -res.num(spec[1], spec[2])
        return res.num(*spec)
    except Exception:
        return None
