"""Corrections et raccordements apportes au modele d'origine.

Chaque correction est documentee : elle corrige une anomalie de formule constatee dans
le fichier modele ou raccorde une cellule saisie a la main vers une donnee calculee par
l'application (report N-1, TAP, TCFGE, parametres fiscaux)."""

BAL = "'Balance std'"
BM1 = "Bilan modèle 1"
PASS = "TABLEAU DE PASSAGE"
DEF = "TRAITEMENT DE DEFICITS"
EVO = "EVOLUTION CAPITAUX PROPRES"

# Liste lisible des corrections (affichee dans l'application, onglet "A propos")
import re

JOURNAL = []


def fx(model, sheet, addr, text, why=None):
    model.set_formula(sheet, addr, text)
    if why:
        JOURNAL.append((sheet, addr, why))


def apply(model):
    JOURNAL.clear()
    # ------------------------------------------------------------------ BILAN
    # Colonne N-1 : meme calcul que la colonne N, applique a la balance N-1
    # (le modele d'origine melangeait des lignes et des colonnes differentes).
    actif_rows = [11, 12, 13, 14, 16, 18, 20, 21, 22, 23, 25, 26, 28, 29, 31, 32, 33, 35, 36, 37, 39]
    from .model import shift_ast, parse_formula
    colmap = {"Balance std": {"F": "D", "G": "E"}, "RESULTAT": {"H": "I"}}
    sheets = set(colmap)
    # correction prealable du brut des titres de placement (F396-F396 = 0 dans le modele)
    fx(model, BM1, "D35", f"={BAL}!F396", "Titres de placement : le brut etait toujours nul (F396-F396)")
    # Report a nouveau : integre les comptes 13 (resultat N-1 non encore affecte) dans la ligne CH
    # de la balance standard, pour que bilan, note 14 et etat d'evolution des capitaux propres concordent
    for a, b in (("F", "D"), ("G", "E")):
        fx(model, "Balance std", f"{a}31", f"=SUM({a}27:{a}30)+{a}32+{a}33+{a}34")
        fx(model, "Balance std", f"{b}31", f"=SUM({b}27:{b}30)+{b}32+{b}33+{b}34")
        fx(model, "Balance std", f"{a}102", f"={a}9+{a}15+{a}16+{a}17+{a}25+{a}26+{a}31+{a}43+{a}52+{a}75+{a}84+{a}85+{a}99")
    fx(model, "NOTE 14", "F23", f"={BAL}!G31-{BAL}!F31")
    fx(model, "NOTE 14", "G23", f"={BAL}!E31-{BAL}!D31")
    fx(model, BM1, "K16", f"={BAL}!G31-{BAL}!F31",
       "Report a nouveau : les comptes 130/131/139 (resultat N-1 non affecte) sont rattaches au report a nouveau")
    for r in actif_rows:
        d = model.formulas.get((BM1, f"D{r}"))
        e = model.formulas.get((BM1, f"E{r}"))
        if d is None:
            continue
        dn = shift_ast(d, colmap, sheets)
        en = shift_ast(e, colmap, sheets) if e is not None else ("num", 0.0)
        model.formulas[(BM1, f"G{r}")] = ("bin", "-", dn, en)
        model.consts.pop((BM1, f"G{r}"), None)
    JOURNAL.append((BM1, "G11:G39", "Actif net N-1 recalcule a partir de la balance N-1 (brut - amortissements)"))
    passif_rows = [10, 11, 12, 13, 14, 15, 16, 18, 20, 21, 23, 24, 25, 28, 29, 30, 31, 32, 33, 36, 37, 39]
    model.shift_n1(BM1, "K", "L", passif_rows)
    JOURNAL.append((BM1, "L10:L39", "Passif N-1 recalcule avec les memes regles que N"))

    # -------------------------------------------------------- COMPTE RESULTAT
    model.shift_n1("RESULTAT", "H", "I", range(10, 51))
    JOURNAL.append(("RESULTAT", "I10:I50", "Colonne N-1 alignee sur la colonne N (ex. impot : ligne 756 au lieu de 755)"))
    fx(model, "RESULTAT", "H36", "=H33+H34+H35", "Resultat d'exploitation : les transferts de charges financieres (TM) en sont exclus")
    fx(model, "RESULTAT", "I36", "=I33+I34+I35")
    fx(model, "RESULTAT", "H43", "=H36+H42")
    fx(model, "RESULTAT", "I43", "=I36+I42")

    # ----------------------------------------------------------------- NOTE 19
    fx(model, "NOTE 19", "C17", f"={BAL}!G359+{BAL}!G360", "Note 19 : creditrices des comptes 4711 incluses dans les crediteurs divers")
    fx(model, "NOTE 19", "D17", f"={BAL}!E359+{BAL}!E360")
    fx(model, "NOTE 19", "C23", f"={BAL}!G365+{BAL}!G367+{BAL}!G368", "Note 19 : comptes 474, 476 et 477 crediteurs")
    fx(model, "NOTE 19", "D23", f"={BAL}!E365+{BAL}!E367+{BAL}!E368")

    # -------------------------------------------------------------------- TFT
    fx(model, "TFT", "H15",
       "=RESULTAT!H33+RESULTAT!H37+RESULTAT!H39+(" + BAL + "!G731-" + BAL + "!F731+" + BAL + "!G750-" + BAL + "!F750)"
       "-(" + BAL + "!F725-" + BAL + "!G725)+RESULTAT!H40+RESULTAT!H49+RESULTAT!H50",
       "CAFG : signe du compte 88 corrige, transferts de charges financieres inclus")
    # Remboursements d'emprunts : colonnes remboursements de l'etat d'evolution des dettes
    fx(model, "TFT", "H38", f"=-('{EVO}'!D35+'{EVO}'!E35)",
       "Remboursements : echeancier + anticipes (au lieu de l'ecart de conversion passif)")
    # Dividendes verses : deduits de la variation des capitaux propres, sauf saisie
    fx(model, "TFT", "H33",
       f"=IF('{EVO}'!C22<>0,-ABS('{EVO}'!C22),-MAX(0,('{BM1}'!L22-'{BM1}'!L20-'{BM1}'!L21)+('{EVO}'!D11-'{EVO}'!E11)-('{BM1}'!K22-'{BM1}'!K20-'{BM1}'!K21-'{BM1}'!K18)))",
       "Dividendes verses : deduits de la variation des capitaux propres si non saisis")
    fx(model, "TFT", "H30", f"='{EVO}'!D11", "Augmentation de capital : colonne Augmentation (capital)")
    fx(model, "TFT", "H32", f"=-'{EVO}'!E11", "Prelevements sur le capital : colonne Diminution (capital)")

    # ------------------------------------------- EVOLUTION CAPITAUX PROPRES
    # Mouvements par defaut deduits de la balance, modifiables par saisie (cellules forcees)
    for r in (30, 31, 32, 34):
        fx(model, EVO, f"C{r}", f"=MAX(0,K{r}-B{r})")
        fx(model, EVO, f"D{r}", f"=MAX(0,B{r}-K{r})")
        fx(model, EVO, f"G{r}", f"=B{r}+C{r}-D{r}-E{r}+F{r}")
    # colonne K (cloture selon balance) : colonne de travail hors zone d'impression
    fx(model, EVO, "K30", f"={BAL}!G54+{BAL}!G55")
    fx(model, EVO, "K31", f"={BAL}!G53+{BAL}!G56")
    fx(model, EVO, "K32", f"=SUM({BAL}!G57:G74)")
    fx(model, EVO, "K34", f"=SUM({BAL}!G76:G83)")
    fx(model, EVO, "D11", "=MAX(0,H11-B11)", "Augmentation de capital deduite de la balance")
    fx(model, EVO, "E11", "=MAX(0,B11-H11)")

    # ------------------------------------------------- TABLEAU DE PASSAGE
    fx(model, PASS, "G26", "=PARAM(\"tap_reintegree\")", "TAP de l'exercice : reprise de la declaration TAP")
    fx(model, PASS, "G44", "=PARAM(\"tap_n1\")", "TAP N-1 deduite : reprise du dossier N-1")
    fx(model, PASS, "G27", "=PARAM(\"conges_n\")")
    fx(model, PASS, "B53", "=SUM('Fiche R2'!Z55:AF56)",
       "Base de l'IMF : chiffre d'affaires de l'exercice, que le resultat fiscal soit beneficiaire ou deficitaire "
       "(l'impot du est le plus eleve de l'ISB et de l'IMF)")
    fx(model, PASS, "D53", "=ROUND(B53*PARAM(\"taux_imf\"),0)", "Taux IMF parametrable (arrondi au franc)")
    fx(model, PASS, "F53", "=IF(MAX(D53,PARAM(\"imf_minimum\"))>=D54,MAX(D53,PARAM(\"imf_minimum\")),0)",
       "IMF retenu, porte au minimum de perception parametre s'il y a lieu")
    fx(model, PASS, "F54", "=IF(D54>MAX(D53,PARAM(\"imf_minimum\")),D54,0)", "ISB retenu s'il depasse l'IMF et le minimum de perception")
    fx(model, PASS, "D54", "=B54*PARAM(\"taux_isb\")")
    fx(model, PASS, "F62", "=MAX(F53,F54)-G57-G58-G59-G60-G61",
       "Reliquat : impot du (IMF ou ISB) diminue des acomptes, credits et precomptes")
    for r, key in ((57, "acompte1"), (58, "acompte2"), (59, "acompte3"), (60, "credit_impot"), (61, "precomptes")):
        fx(model, PASS, f"G{r}", f"=PARAM(\"{key}\")")
    fx(model, PASS, "G67", "=PARAM(\"factures_sans_nif\")")

    # ----------------------------------------------------- DEFICITS / ARD
    fx(model, DEF, "F23", "=PARAM(\"ard_anterieurs\")", "Amortissements reputes differes anterieurs : repris du dossier N-1")
    for i, r in enumerate((12, 13, 14)):
        fx(model, DEF, f"I{r}", f"=PARAM(\"deficit_orig_{i}\")")
        fx(model, DEF, f"J{r}", f"=PARAM(\"deficit_impute_{i}\")")
        fx(model, DEF, f"H{r}", f"=PARAM(\"deficit_annee_{i}\")&\"\"")
        fx(model, DEF, f"B{r + 2}", f"=PARAM(\"deficit_annee_{i}\")&\"\"")
    fx(model, DEF, "M16", f"=-MIN(0,'{PASS}'!G50)", "Deficit de l'exercice exprime en montant positif (coherence du report)")
    fx(model, DEF, "D37", "=PARAM(\"tap_reintegree\")")
    fx(model, DEF, "F37", "=PARAM(\"tap_n1\")")
    fx(model, DEF, "D32", "=PARAM(\"conges_n\")")
    fx(model, DEF, "F32", "=PARAM(\"conges_n1\")")

    # ---------------------------------------------------------- BORDEREAU
    B = "BORDEREAU"
    fx(model, B, "N27", f"='{PASS}'!D53", "Bordereau : IMF au taux parametre")
    # cases a cocher : impots effectivement dus
    fx(model, B, "G16", f"=IF('{PASS}'!F54>0,\"x\",\"\")", "Bordereau : cases cochees selon les impots dus")
    fx(model, B, "L16", f"=IF('{PASS}'!F53>0,\"x\",\"\")")
    fx(model, B, "Q16", "=IF(PARAM(\"tap_total\")>0,\"x\",\"\")")
    fx(model, B, "W16", "=IF(PARAM(\"tcfge_montant\")>0,\"x\",\"\")")
    # taux de l'IMF coche selon le parametre
    fx(model, B, "C27", "=IF(ABS(PARAM(\"taux_imf\")-0.01)<0.00001,\"X\",\"\")", "Bordereau : taux d'IMF coche selon le parametre")
    fx(model, B, "E27", "=IF(ABS(PARAM(\"taux_imf\")-0.0175)<0.00001,\"X\",\"\")")
    fx(model, B, "G27", "=IF(ABS(PARAM(\"taux_imf\")-0.03)<0.00001,\"X\",\"\")")
    fx(model, B, "I27", "=IF(AND(ABS(PARAM(\"taux_imf\")-0.01)>=0.00001,ABS(PARAM(\"taux_imf\")-0.0175)>=0.00001,ABS(PARAM(\"taux_imf\")-0.03)>=0.00001),\"X\",\"\")")
    fx(model, B, "O30", f"='{PASS}'!F54")
    fx(model, B, "O31", f"='{PASS}'!F53")
    # acomptes : la cellule visible est le coin superieur gauche de chaque zone fusionnee
    fx(model, B, "O32", f"='{PASS}'!G57", "Bordereau : 1er acompte affiche (cellule fusionnee O32:T32 ; le modele lisait F57, vide)")
    model.formulas.pop((B, "P32"), None)
    model.consts.pop((B, "P32"), None)
    # alignement des montants des lignes 30 a 36 dans une meme colonne (O:T)
    sb = model.sheets[B]
    style = sb["cells"].get("O32", {}).get("s")
    for oldm, newm, src in (("O30:S30", "O30:T30", None), ("P33:T33", "O33:T33", "P33"), ("P34:T34", "O34:T34", "P34"),
                            ("P35:T35", "O35:T35", "P35"), ("R36:V36", "O36:T36", "R36")):
        if oldm in sb["merges"]:
            sb["merges"][sb["merges"].index(oldm)] = newm
        if src:
            model.formulas.pop((B, src), None)
            model.consts.pop((B, src), None)
            sb["cells"].pop(src, None)
        tl = newm.split(":")[0]
        sb["cells"].setdefault(tl, {})["s"] = style
    fx(model, B, "O33", f"='{PASS}'!G58")
    fx(model, B, "O34", f"='{PASS}'!G59")
    fx(model, B, "O35", f"='{PASS}'!G60")
    fx(model, B, "O36", f"='{PASS}'!G61")
    sb["cells"].setdefault("O31", {})["s"] = style
    sb["cells"].setdefault("O30", {})["s"] = style
    fx(model, B, "L39", f"='{PASS}'!G57+'{PASS}'!G58+'{PASS}'!G59+'{PASS}'!G60+'{PASS}'!G61",
       "Bordereau : total des deductions = 3 acomptes + credit d'impot + precomptes")
    # Solde IMF/ISB apres deductions : a payer (positif) ou excedent de versement (credit)
    fx(model, B, "J41", f"=IF('{PASS}'!F62<0,\"EXCEDENT\",\"SOLDE A PAYER\")")
    fx(model, B, "T41", f"=ABS('{PASS}'!F62)", "Bordereau : solde IMF/ISB apres les 3 acomptes, le credit d'impot et les precomptes")
    # TAP : frais de formation deduits de la base, puis taux 3 % / 5 % appliques a la base nette
    fx(model, B, "A44", "=IF(PARAM(\"tap_mode\")=\"base\",\"Base nette TAP\",\"Base TAP\")")
    fx(model, B, "K44", "=IF(PARAM(\"tap_mode\")=\"base\",PARAM(\"tap_base_nette\"),PARAM(\"tap_base\"))",
       "Base TAP : remunerations (declaration TAP) diminuees des frais de formation")
    fx(model, B, "A45", "=IF(PARAM(\"tap_mode\")=\"base\",\"TAP 3 % (base nette)\",\"TAP 3 %\")")
    fx(model, B, "K45", "=IF(PARAM(\"tap_mode\")=\"base\",PARAM(\"tap_3_net\"),PARAM(\"tap_3\"))",
       "Bordereau : TAP calculee sur la base diminuee des frais de formation")
    fx(model, B, "A46", "=IF(PARAM(\"tap_mode\")=\"base\",\"TAP 5 % (base nette)\",\"TAP 5 %\")")
    fx(model, B, "K46", "=IF(PARAM(\"tap_mode\")=\"base\",PARAM(\"tap_5_net\"),PARAM(\"tap_5\"))")
    fx(model, B, "K47", "=PARAM(\"tap_ffp\")")
    fx(model, B, "A48", "=IF(PARAM(\"tap_mode\")=\"base\",\"Pour mémoire : formation déduite de la base\",\"Déduction frais de formation\")")
    model.consts.pop((B, "E48"), None)
    fx(model, B, "K48", "=IF(PARAM(\"tap_mode\")=\"base\",PARAM(\"tap_ded_base\"),-PARAM(\"tap_formation\"))",
       "Bordereau : frais de formation deduits de la base TAP")
    fx(model, B, "M50", "=IF(PARAM(\"tap_total\")>0,PARAM(\"tap_total\"),\"NEANT\")")
    fx(model, B, "L53", "=IF(PARAM(\"tcfge_base\")>0,PARAM(\"tcfge_base\"),\"NEANT\")", "Base TCFGE reprise de la declaration TCFGE (NEANT si nulle)")
    fx(model, B, "M54", "=IF(PARAM(\"tcfge_montant\")>0,PARAM(\"tcfge_montant\"),\"NEANT\")")
    # Resume : impot du (ISB ou IMF) - 3 acomptes - credit d'impot - precomptes + TAP nette + TCFGE.
    # Option « imputer_credit » (par defaut) : l'excedent d'ISB/IMF vient en diminution du total a payer ;
    # le reliquat eventuel est un credit reportable.
    fx(model, B, "M59", f"=IF('{PASS}'!F62=0,\"NEANT\",IF(PARAM(\"imputer_credit\"),'{PASS}'!F62,MAX(0,'{PASS}'!F62)))",
       "Resume du bordereau : solde IMF/ISB (negatif = excedent impute sur la TAP et la TCFGE)")
    fx(model, B, "M60", "=IF(PARAM(\"tap_total\")>0,PARAM(\"tap_total\"),\"NEANT\")")
    fx(model, B, "M61", "=IF(PARAM(\"tcfge_montant\")>0,PARAM(\"tcfge_montant\"),\"NEANT\")")
    fx(model, B, "Z90", f"=IF(PARAM(\"imputer_credit\"),'{PASS}'!F62+PARAM(\"tap_total\")+PARAM(\"tcfge_montant\"),"
                         f"MAX(0,'{PASS}'!F62)+PARAM(\"tap_total\")+PARAM(\"tcfge_montant\"))")
    fx(model, B, "X57", "=MAX(0,Z90)",
       "Total a payer = impot du - acomptes - credit - precomptes + TAP nette + TCFGE (credit impute)")
    fx(model, B, "S59", f"=IF(OR(Z90<0,AND(NOT(PARAM(\"imputer_credit\")),'{PASS}'!F62<0)),\"Crédit reportable =\",\"\")")
    fx(model, B, "X59", f"=IF(PARAM(\"imputer_credit\"),IF(Z90<0,-Z90,\"\"),IF('{PASS}'!F62<0,-'{PASS}'!F62,\"\"))")
    sb["cells"].setdefault("S59", {})["s"] = sb["cells"]["S57"]["s"]
    sb["cells"].setdefault("X59", {})["s"] = sb["cells"]["M60"]["s"]
    fx(model, B, "E20", "='Fiche R1'!C30")

    # ------------------------------------------------------------ PAGE DE GARDE
    fx(model, "Page de garde", "F47", "=PARAM(\"nb_exemplaires\")")
    fx(model, "Page de garde", "F46", "=PARAM(\"nb_pages\")")

    # ------------------------------------------ BILAN PASSIF : tresorerie et provisions CT
    fx(model, "Balance std", "G421", "=G420+G393+G394",
       "Provisions pour risques a court terme (DN) : exclusion du compte 498 (depreciation de creances HAO, deja a l'actif BA)")
    fx(model, "Balance std", "F421", "=F420+F393+F394")
    fx(model, "Balance std", "E421", "=E420+E393+E394")
    fx(model, "Balance std", "D421", "=D420+D393+D394")
    fx(model, BM1, "K36", f"={BAL}!G413-{BAL}!F413",
       "Banques, credits d'escompte (DQ) : comptes 564/565 (le modele reprenait le compte 590 de l'actif)")
    fx(model, BM1, "L36", f"={BAL}!E413-{BAL}!D413")
    fx(model, BM1, "K37", f"={BAL}!G412-{BAL}!F412",
       "Banques, credits de tresorerie (DR) : hors credits d'escompte, deja portes en DQ")
    fx(model, BM1, "L37", f"={BAL}!E412-{BAL}!D412")

    # ------------------------------------------ BALANCE STD : sous-totaux absents du modele
    for col in "DEFG":
        fx(model, "Balance std", f"{col}15", f"=SUM({col}10:{col}14)",
           "Primes liees au capital (CD) : sous-total 1051 a 1058 absent du modele" if col == "G" else None)
        fx(model, "Balance std", f"{col}25", f"=SUM({col}18:{col}24)",
           "Reserves indisponibles (CF) : sous-total 111 a 1138 absent du modele" if col == "G" else None)

    # ------------------------------------------ textes types dates en dur
    model.consts[("NOTE 16A", "A39")] = (
        "Les engagements de la société au titre des indemnités de départ à la retraite sont estimés par un calcul "
        "actuariel tenant compte de la rotation du personnel et correspondant à la valeur probable de la dette de "
        "l'entité à l'égard de chacun de ses salariés. Les droits acquis sont déterminés à partir du Code du travail, "
        "de la convention collective interprofessionnelle et des accords en vigueur.\n"
        "L'engagement a été évalué à la date de clôture de l'exercice en retenant les hypothèses suivantes "
        "(à adapter) :\n- Taux d'actualisation financière : …… %\n- Taux de progression des salaires : …… %\n"
        "- Taux de départ des salariés : dégressif selon l'âge\n- Âge de départ à la retraite : 60 ans\n"
        "- Table de mortalité : CIMA")
    model.consts[("Fiche R1", "C59")] = "……/……/……"

    # ------------------------------------------ colonnes « Variation en % » des notes
    # Le modele divisait souvent par l'exercice N au lieu de N-1 (ex. fournisseurs 18,1 M contre 47,7 M : -163 %
    # au lieu de -62 %) et affichait 0 % quand le poste N-1 etait nul. Formule unique : (N - N-1) / |N-1|,
    # case vide si N-1 = 0.
    import re as _re
    pat = _re.compile(r"^=(?:IFERROR\()?\(\+?([A-Z]{1,2})(\d+)-([A-Z]{1,2})(\d+)\)/([A-Z]{1,2})(\d+)(?:,0\))?$")
    done = {(s, a) for s, a, _ in JOURNAL}
    n_var = 0
    for sh, sd in model.sheets.items():
        if not sh.startswith("NOTE"):
            continue
        for addr, c in sd["cells"].items():
            f = (c.get("f") or "").replace("$", "")
            mm = pat.match(f)
            if not mm or (sh, addr) in done:
                continue
            nf = (model.styles[c["s"]].get("nf") or "") if c.get("s") is not None else ""
            if "%" not in nf:
                continue
            cn, rn, c1, r1, cd, rd = mm.groups()
            if not (rn == r1 == rd):
                continue
            model.set_formula(sh, addr, f'=IF({c1}{r1}=0,"",({cn}{rn}-{c1}{r1})/ABS({c1}{r1}))')
            n_var += 1
    JOURNAL.append(("Notes annexes", f"{n_var} cellules",
                    "Variation en % = (N - N-1) / |N-1| (le modele divisait parfois par N) ; case vide si N-1 est nul"))

    # Note 16B : hypotheses actuarielles d'exemple du modele (3 %, 7 %, 100 %) retirees ; a saisir par l'entite
    for a in ("H11", "I11", "H12", "I12", "H14", "I14", "H15", "I15"):
        model.consts.pop(("NOTE 16B", a), None)
    model.consts[("NOTE 11", "A25")] = ("L'état de rapprochement bancaire est établi à chaque fin de mois et à la clôture ; "
                                        "la caisse fait l'objet d'un inventaire physique à la date de clôture.")
    model.consts[("NOTE 37", "A7")] = "NOTE 37 : EVENEMENTS POSTERIEURS A LA CLOTURE DE L'EXERCICE"
    model.consts[("NOTE 38", "A7")] = "NOTE 38 : CHANGEMENTS DE METHODES COMPTABLES, D'ESTIMATIONS ET CORRECTIONS D'ERREURS"

    # ------------------------------------------ EVOLUTION DES CAPITAUX PROPRES (etat n°6)
    E6 = "EVOLUTION CAPITAUX PROPRES"
    st0 = model.sheets[E6]["cells"].get("B11", {}).get("s")
    for r in range(11, 21):
        for col in "DEFG":
            model.sheets[E6]["cells"].setdefault(f"{col}{r}", {})["s"] = st0   # format sans decimales
    fx(model, E6, "D18", "=MAX(0,RESULTAT!H51)", "Etat n°6 : resultat de l'exercice porte en augmentation (ou diminution si perte)")
    fx(model, E6, "E18", "=MAX(0,-RESULTAT!H51)")
    fx(model, E6, "H18", "=B18+C18+D18-E18")
    fx(model, E6, "B19", f"={BAL}!E47-{BAL}!D47")
    for r in (12, 13, 14, 15, 16, 17, 19, 20):
        fx(model, E6, f"F{r}", f"=MAX(0,H{r}-B{r}-C{r}-D{r}+E{r})",
           "Etat n°6 : mouvements des autres postes deduits des soldes (dotations, distributions)" if r == 12 else None)
        fx(model, E6, f"G{r}", f"=MAX(0,B{r}+C{r}+D{r}-E{r}-H{r})")

    # ------------------------------------------ en-tetes et exemples du modele (etats n°9 et n°10)
    fx(model, "DETAIL DES PROVISIONS", "E6", "='Fiche R1'!M5", "En-tete etat n°9 : date de cloture (le modele lisait une cellule vide)")
    fx(model, "LISTE DES PRINC CLIENTS FRS", "H40", "='Fiche R1'!U5", "En-tete etat n°10 : duree de l'exercice")
    fx(model, "LISTE DES PRINC CLIENTS FRS", "H4", "='Fiche R1'!S4")
    fx(model, "LISTE DES PRINC CLIENTS FRS", "G38", "='Fiche R1'!S4")
    PV9 = "DETAIL DES PROVISIONS"
    for a in ("A12", "E12", "A13", "E13", "A16", "E16", "A17", "E17", "A21", "E21", "A24", "E24", "A25", "E25", "A26", "E26", "E27"):
        model.consts.pop((PV9, a), None)   # exemples d'une autre entreprise (ligne PET, DLUO...) retires
    model.consts[(PV9, "A14")] = "Sous-total dotations aux provisions déductibles"
    model.consts[(PV9, "A18")] = "Sous-total dotations aux provisions non déductibles"
    model.consts[(PV9, "A27")] = "Total reprises de provisions non déductibles"

    # Etat n°4 (a) : deficits imputes exprimes en montants positifs, comme les deficits imputables
    fx(model, DEF, "D14", "=-L12", "Etat n°4 : deficits imputes affiches en positif")
    fx(model, DEF, "D15", "=-L13")
    fx(model, DEF, "D16", "=-L14")
    fx(model, DEF, "D17", "=-L15")
    fx(model, PASS, "E62", "=IF(F62<0,\"Excédent versé\",\"Reliquat à payer\")")

    # ------------------------------------------ BALANCE STD : affectation des comptes aux postes
    # (audit compte par compte : chaque compte, au debit et au credit, doit aboutir au bon poste du bilan
    # ou du compte de resultat)
    def fb(row, expr, why=None):
        for c, n1 in (("F", "D"), ("G", "E")):
            fx(model, "Balance std", f"{c}{row}", "=" + expr.replace("{c}", c), why if c == "G" else None)
            fx(model, "Balance std", f"{n1}{row}", "=" + expr.replace("{c}", n1))
    fb(116, "{c}104+{c}105+{c}106+{c}113", "AF : brevets, licences, logiciels ET marques (214), conformement au SYSCOHADA revise")
    fb(117, "{c}107+{c}108", "AG : fonds commercial et droit au bail (215, 216) ; 214 Marques deplace en AF")
    fb(214, "{c}206+{c}207+{c}208", "Depreciations : 2919 (immob. incorporelles en cours) retire de AF")
    fb(216, "{c}211+{c}212", "Depreciations : 2919 rattache a AH avec les autres immobilisations incorporelles")
    fb(228, "{c}221+{c}222+{c}224+{c}226", "Depreciations : 2938 (autres installations et agencements) rattache a AL (etait perdu)")
    fb(249, "{c}204+{c}240", "AN : depreciations du materiel de transport (2945, 2949) ajoutees (etaient perdues)")
    fb(84, "{c}53+{c}54+{c}55+{c}56+{c}57+{c}61+{c}62", "DA : emprunts obligataires 1612, 1613, 1618 (n'apparaissaient nulle part)")
    fb(658, "SUM({c}653:{c}657)", "TB : remises et ristournes 7049 deduites des ventes (etaient perdues)")
    fb(663, "SUM({c}659:{c}662)", "TC : remises et ristournes 7069 deduites des travaux et services (etaient perdues)")
    fb(731, "SUM({c}726:{c}730)+{c}732+{c}733", "TO : transferts de charges HAO (848) et reprises HAO (849) en produits HAO")
    fb(739, "SUM({c}734:{c}738)", "RP : charges HAO hors 848/849")
    # 4997 : provisions pour risques a court terme (financieres) -> DN et non dettes / creances HAO
    fx(model, "Balance std", "G381", "=SUM(G373:G378)", "4997 : provisions pour risques a court terme rattachees a DN")
    fx(model, "Balance std", "E381", "=SUM(E373:E378)")
    fx(model, "Balance std", "F382", "=SUM(F373:F378)")
    fx(model, "Balance std", "D382", "=SUM(D373:D378)")
    for c in "DEFG":
        fx(model, "Balance std", f"{c}421", f"={c}420+{c}393+{c}394+{c}379")

    # ------------------------------------------ ETAT N°1 (detail des charges)
    CC = "COMP CHARGES"
    fx(model, CC, "G19", "=-RESULTAT!H12", "Etat n°1 : variation des stocks de marchandises (signe corrige)")
    fx(model, CC, "H19", "=-RESULTAT!I12")
    fx(model, CC, "G28", "=-RESULTAT!H24", "Etat n°1 : variation des stocks de matieres (signe corrige)")
    fx(model, CC, "H28", "=-RESULTAT!I24")
    fx(model, CC, "G53", "=-RESULTAT!H26", "Etat n°1 : variation des stocks d'autres approvisionnements (le modele reprenait la ligne RD)")
    fx(model, CC, "H53", "=-RESULTAT!I26")
    fx(model, CC, "G190", "='Balance std'!F575-'Balance std'!G575", "Etat n°1 : compte 6598 (absent du modele)")
    fx(model, CC, "H190", "='Balance std'!D575-'Balance std'!E575")
    # chaque ligne du detail des charges reprend le solde du compte (debit - credit) : les rabais, remises
    # et ristournes obtenus (6019, 6029...) et les soldes crediteurs viennent en diminution
    import re as _re2
    n_cc = 0
    for addr, c in list(model.sheets[CC]["cells"].items()):
        f = (c.get("f") or "").replace("$", "")
        mm = _re2.fullmatch(r"=\+?'Balance std'!([FD])(\d+)", f)
        if mm and (CC, addr) not in {(s_, a_) for s_, a_, _ in JOURNAL}:
            col, r = mm.groups()
            other = "G" if col == "F" else "E"
            model.set_formula(CC, addr, f"='Balance std'!{col}{r}-'Balance std'!{other}{r}")
            n_cc += 1
    JOURNAL.append((CC, f"{n_cc} cellules", "Etat n°1 : solde des comptes (debit - credit), remises obtenues en diminution"))

    # ------------------------------------------ NOTE 21 : chiffre d'affaires raccorde au compte de resultat
    N21 = "NOTE 21"
    for col, crc in (("F", "H"), ("G", "I")):
        w = "Note 21 : totaux egaux aux lignes TA, TB, TC, TD du compte de resultat (remises accordees deduites)" if col == "F" else None
        fx(model, N21, f"{col}15", f"=RESULTAT!{crc}10", w)
        fx(model, N21, f"{col}10", f"={col}15-{col}11-{col}12-{col}13-{col}14")
        fx(model, N21, f"{col}21", f"=RESULTAT!{crc}14")
        fx(model, N21, f"{col}16", f"={col}21-{col}17-{col}18-{col}19-{col}20")
        fx(model, N21, f"{col}27", f"=RESULTAT!{crc}15")
        fx(model, N21, f"{col}22", f"={col}27-{col}23-{col}24-{col}25-{col}26")
        fx(model, N21, f"{col}28", f"=RESULTAT!{crc}16")

    # ------------------------------------------ NOTES 3A / 3C / 18 / 27A : raccordement aux postes du bilan
    BS_ = "'Balance std'"

    def net(rows, n1=False, sens=+1):
        """Solde net (debit - credit) d'une liste de lignes de la balance standard (n1 = colonnes D/E)."""
        d, c = ("D", "E") if n1 else ("F", "G")
        parts = []
        for r_, sg in rows:
            a_, b_ = (d, c) if sg * sens > 0 else (c, d)
            parts.append(f"+{BS_}!{a_}{r_}-{BS_}!{b_}{r_}")
        return "=" + "".join(parts).lstrip("+")
    fb(175, "SUM({c}170:{c}172)")
    N3A = "NOTE 3A "
    lignes3a = {14: [(116, 1)], 15: [(117, 1)], 16: [(118, 1), (115, 1)], 18: [(124, 1), (121, -1)], 19: [(121, 1)],
                20: [(136, 1), (126, -1), (127, -1)], 21: [(126, 1), (127, 1)], 22: [(137, 1)], 23: [(156, 1)],
                24: [(157, 1)], 26: [(158, 1)], 27: [(159, 1)], 29: [(161, 1)], 30: [(168, 1)]}
    for r_, rows_ in lignes3a.items():
        fx(model, N3A, f"H{r_}", net(rows_), "Note 3A : brut a la cloture = postes du bilan (AE avec les autres incorporelles, "
           "fonds commercial = 215/216, terrains et batiments complets)" if r_ == 14 else None)
        fx(model, N3A, f"B{r_}", net(rows_, True))
        fx(model, N3A, f"C{r_}", f"=MAX(0,H{r_}-B{r_})")
        fx(model, N3A, f"F{r_}", f"=MAX(0,B{r_}-H{r_})")
    N3C = "NOTE 3C"
    lignes3c = {13: [(176, -1)], 14: [(175, -1)], 15: [(177, -1)], 16: [(180, -1)], 18: [(192, -1)],
                19: [(193, -1), (184, -1)], 20: [(203, -1)], 21: [(204, -1)]}
    for r_, rows_ in lignes3c.items():
        fx(model, N3C, f"F{r_}", net(rows_), "Note 3C : amortissements nets (credit - debit), y compris terrains (282)" if r_ == 13 else None)
        fx(model, N3C, f"B{r_}", net(rows_, True))
        if r_ != 20:
            fx(model, N3C, f"D{r_}", f"=MAX(0,F{r_}-B{r_})")
            fx(model, N3C, f"E{r_}", f"=MAX(0,B{r_}-F{r_})")
    N18 = "NOTE 18"
    for col, (cd, cc_) in (("C", ("G", "F")), ("D", ("E", "D"))):
        g = lambda rr: "+".join(f"{BS_}!{cd}{x}" for x in rr)   # soldes crediteurs (les debiteurs vont en BJ)
        fx(model, N18, f"{col}14", "=" + g([315, 316, 317, 318, 319, 321, 322]),
           "Note 18 : 4281 et 4382 n'etaient plus comptes deux fois ; autres dettes Etat (4486 a 4499) ajoutees" if col == "C" else None)
        fx(model, N18, f"{col}15", "=" + g([323, 324, 329, 331, 332]))
        fx(model, N18, f"{col}25", "=" + g(range(343, 352)))
        fx(model, N18, f"{col}24", "=" + g([341, 342]))
    N27 = "NOTE 27A"
    plages = {9: (577, 592), 10: (593, 597), 11: None, 12: (600, 600), 13: (602, 603), 14: (604, 611)}
    for r_, pl in plages.items():
        for col, (a_, b_) in (("F", ("F", "G")), ("G", ("D", "E"))):
            if pl is None:
                expr = "+".join(f"{BS_}!{a_}{x}-{BS_}!{b_}{x}" for x in (598, 599, 601))
            else:
                expr = f"SUM({BS_}!{a_}{pl[0]}:{a_}{pl[1]})-SUM({BS_}!{b_}{pl[0]}:{b_}{pl[1]})"
            fx(model, N27, f"{col}{r_}", "=" + expr,
               "Note 27A : charges de personnel nettes ; compte 663 (exploitant) n'est plus compte deux fois" if (r_, col) == (9, "F") else None)

    # Etat n°6 : subventions d'investissement (CL) et provisions reglementees (CM) : memes lignes que le bilan
    fx(model, E6, "B19", f"={BAL}!E43-{BAL}!D43", "Etat n°6 : subventions et provisions reglementees lues sur les lignes du bilan (le modele lisait 1618)")
    fx(model, E6, "H19", f"={BAL}!G43-{BAL}!F43")
    fx(model, E6, "B20", f"={BAL}!E52-{BAL}!D52")
    fx(model, E6, "H20", f"={BAL}!G52-{BAL}!F52")

    # ------------------------------------------ NOTE 34 : tableau de bord (audit HOREB PHARMA NIGER)
    N34 = "NOTE 34"
    BMq = "'Bilan modèle 1'"
    for col, R, bc, bal_ in (("E", "H", ("F", "K"), ("F", "G")), ("F", "I", ("G", "L"), ("D", "E"))):
        a_, p_ = bc
        d_, c_ = bal_
        w = (lambda t: t) if col == "E" else (lambda t: None)
        # BFE = actif circulant d'exploitation - passif circulant d'exploitation (hors HAO), sans le fonds de roulement
        fx(model, N34, f"{col}39", f"={BMq}!{a_}34-{BMq}!{a_}28", w("Note 34 : actif circulant d'exploitation = BK - BA (hors HAO)"))
        fx(model, N34, f"{col}40", f"={BMq}!{p_}34-{BMq}!{p_}28", w("Note 34 : passif circulant d'exploitation = DP - DH (hors HAO)"))
        fx(model, N34, f"{col}41", f"={col}39-{col}40", w("Note 34 : BFE = actif circulant d'exploitation - passif circulant d'exploitation (le modele y ajoutait le fonds de roulement)"))
        # CAF : CAF d'exploitation = EBE ; CAFG = ligne FA du TFT
        fx(model, N34, f"{col}22", f"={col}21", w("Note 34 : CAF d'exploitation = EBE (l'impot n'y est pas deduit)"))
        fx(model, N34, f"{col}23", f"=RESULTAT!{R}37+RESULTAT!{R}39")
        fx(model, N34, f"{col}24", f"={BAL}!{c_}731-{BAL}!{d_}731+{BAL}!{c_}750-{BAL}!{d_}750")
        fx(model, N34, f"{col}25", f"=RESULTAT!{R}40-({BAL}!{d_}725-{BAL}!{c_}725)")
        fx(model, N34, f"{col}26", f"=RESULTAT!{R}49+RESULTAT!{R}50")
        fx(model, N34, f"{col}27", f"=SUM({col}22:{col}26)", w("Note 34 : CAFG = CAF d'exploitation + produits - charges financieres et HAO - participation et impot (= ligne FA du TFT)"))
        # rentabilites : non significatives si capitaux propres negatifs ou nuls
        fx(model, N34, f"{col}31", f"=IF({BMq}!{p_}22<=0,\"NS\",IF(({BMq}!{p_}22+{BMq}!{p_}26)=0,\"\",{col}15/({BMq}!{p_}22+{BMq}!{p_}26)))",
           w("Note 34 : rentabilites « NS » quand les capitaux propres sont negatifs"))
        fx(model, N34, f"{col}32", f"=IF({BMq}!{p_}22<=0,\"NS\",{col}19/{BMq}!{p_}22)")
        # endettement financier net = dettes financieres + tresorerie passif - tresorerie actif
        fx(model, N34, f"{col}54", f"={col}35+{BMq}!{p_}38", w("Note 34 : endettement brut = dettes financieres + tresorerie passif ; net = brut - tresorerie actif"))
        fx(model, N34, f"{col}55", f"={BMq}!{a_}38")
        fx(model, N34, f"{col}56", f"={col}54-{col}55")
    for r_ in (31, 32):
        fx(model, N34, f"G{r_}", f"=IF(OR(ISTEXT(E{r_}),ISTEXT(F{r_})),\"\",IF(F{r_}=0,\"\",(E{r_}-F{r_})/ABS(F{r_})))")
    for r_ in (54, 55, 56):
        fx(model, N34, f"G{r_}", f"=IF(F{r_}=0,\"\",(E{r_}-F{r_})/ABS(F{r_}))")
    model.formulas.pop((N34, "G20"), None)
    model.consts[(N34, "A25")] = "- Frais financiers et charges HAO"
    model.consts[(N34, "A26")] = "- Participation des travailleurs et impôts sur le résultat"
    model.consts[(N34, "A54")] = "Endettement financier brut (Dettes financières* + Trésorerie – passif)"

    # ------------------------------------------ NOTE 25 : droits de timbre (6462) avec les droits d'enregistrement
    N25 = "NOTE 25"
    for col, (d_, c_) in (("F", ("F", "G")), ("G", ("D", "E"))):
        s_ = lambda rows: "+".join(f"{BAL}!{d_}{x}-{BAL}!{c_}{x}" for x in rows)
        fx(model, N25, f"{col}9", "=" + s_([541, 542, 543, 544, 545, 546]),
           "Note 25 : impots directs (641) nets" if col == "F" else None)
        fx(model, N25, f"{col}10", "=" + s_([547, 550, 551]),
           "Note 25 : impots indirects = 645, 6463, 6464 (le timbre 6462 et les droits de mutation 6461 en sont retires)" if col == "F" else None)
        fx(model, N25, f"{col}11", "=" + s_([548, 549, 552]),
           "Note 25 : droits d'enregistrement = 6461, 6462 (timbre), 6468" if col == "F" else None)
        fx(model, N25, f"{col}12", "=" + s_([553, 554, 555, 556, 557]))
        fx(model, N25, f"{col}13", "=" + s_([558]))

    # ------------------------------------------ NOTE 31 : masse salariale = comptes 661 a 663
    N31 = "NOTE 31"
    fx(model, N31, "C28", f"=SUM({BAL}!F577:F597)-SUM({BAL}!G577:G597)",
       "Note 31 : masse salariale = remunerations 661 a 663 (hors charges sociales 664)")
    fx(model, N31, "D28", f"=SUM({BAL}!D577:D597)-SUM({BAL}!E577:E597)")
    fx(model, N31, "C29", f"='NOTE 27A'!F11")
    fx(model, N31, "D29", f"='NOTE 27A'!G11")

    # ------------------------------------------ ETAT N°12 : dettes et creances fiscales (Notes 8 et 18)
    EF = "CREANCES DETTES FISC "
    # dettes fiscales (credit des comptes 44 = Note 18) : N (B) et N-1 (C)
    fx(model, EF, "B18", "=" + "+".join(f"{BAL}!G{x}" for x in (337, 338, 341)), "Etat n°12 : dettes fiscales lues sur les comptes 44 (Note 18)")
    fx(model, EF, "C18", "=" + "+".join(f"{BAL}!E{x}" for x in (337, 338, 341)))
    fx(model, EF, "B21", "='NOTE 18'!C26-B18")
    fx(model, EF, "C21", "='NOTE 18'!D26-C18")
    fx(model, EF, "B27", "=SUM(B13:B26)")
    fx(model, EF, "C27", "=SUM(C13:C26)")
    for r_ in (18, 21, 27):
        fx(model, EF, f"D{r_}", f"=B{r_}-C{r_}")
        fx(model, EF, f"E{r_}", f"=IF(C{r_}=0,\"\",(B{r_}-C{r_})/ABS(C{r_}))")
    # creances fiscales (debit des comptes 44 = Note 8, ligne Etat)
    fx(model, EF, "B47", "=" + "+".join(f"{BAL}!F{x}" for x in (337, 338, 339, 340, 341)), "Etat n°12 : creances fiscales lues sur les comptes 44 (Note 8)")
    fx(model, EF, "C47", "=" + "+".join(f"{BAL}!D{x}" for x in (337, 338, 339, 340, 341)))
    fx(model, EF, "B50", "='NOTE 8'!C12-B47")
    fx(model, EF, "C50", "='NOTE 8'!D12-C47")
    fx(model, EF, "B55", "=SUM(B42:B54)")
    fx(model, EF, "C55", "=SUM(C42:C54)")

    # ------------------------------------------ divisions protegees : plus de #DIV/0! (Fiche R2, Note 34, ratios)
    def _safe(node, top):
        if not isinstance(node, tuple):
            return node
        k = node[0]
        if k == "bin":
            op, a, b = node[1], _safe(node[2], False), _safe(node[3], False)
            if op == "/" and not (isinstance(b, tuple) and b[0] == "num" and b[1] != 0):
                return ("fn", "IF", [("bin", "=", b, ("num", 0.0)), ("str", "") if top else ("num", 0.0), ("bin", "/", a, b)])
            return ("bin", op, a, b)
        if k == "fn":
            if node[1] in ("IFERROR", "ISERROR", "ISTEXT", "ISERR", "ISNUMBER"):
                return node
            if node[1] == "IF":
                args_ = list(node[2])
                return ("fn", "IF", [_safe(args_[0], False)] + [_safe(x, top) for x in args_[1:]])
            return ("fn", node[1], [_safe(x, False) for x in node[2]])
        if k == "neg" and len(node) == 2:
            return ("neg", _safe(node[1], False))
        return node
    _n = 0
    for key_, f_ in list(model.formulas.items()):
        g_ = _safe(f_, True)
        if g_ != f_:
            model.formulas[key_] = g_
            _n += 1
    JOURNAL.append(("*", "*", f"{_n} divisions protegees contre la division par zero (#DIV/0! remplace par vide)"))

    # ------------------------------------------ NOTE 19 : colonnes d'echeances lisibles (plus de ####### ni de chiffres minuscules)
    s19 = model.sheets.get("NOTE 19")
    if s19:
        cw = s19["colw"]
        for col_, w_ in (("B", 18.5), ("G", 12.0), ("H", 11.5), ("I", 10.0)):
            if col_ in cw:
                cw[col_]["w"] = w_
        for r_ in range(10, 32):
            src_ = s19["cells"].get(f"C{r_}", {}).get("s")
            if src_ is None:
                continue
            for col_ in "GHI":
                cell_ = s19["cells"].get(f"{col_}{r_}")
                if cell_ is not None or (N19 := "NOTE 19", f"{col_}{r_}") in model.formulas:
                    s19["cells"].setdefault(f"{col_}{r_}", {})["s"] = src_
        model.consts[("NOTE 19", "A33")] = ("Commentaires : toutes variations significatives, indication du taux de rémunération si compte courant "
                                           "rémunéré, des dettes anciennes ; indication du compte transitoire ajustement spécial, de son détail "
                                           "et de la durée restant à courir pour l'apurement.")
        JOURNAL.append(("NOTE 19", "G:I", "Colonnes d'echeances elargies et police normale ; commentaire en double supprime"))
    if model.consts.get(("NOTE DGI", "A46"), "").startswith("XVII"):
        model.consts[("NOTE DGI", "A46")] = "XVI. AUTRES"

    # ------------------------------------------ Etat n°12 : variation en % affichee en pourcentage
    sef = model.sheets.get(EF)
    if sef:
        for r_ in range(13, 28):
            cell_ = sef["cells"].get(f"E{r_}")
            if cell_ and "s" in cell_:
                st_ = dict(model.styles[cell_["s"]])
                if st_.get("nf") != "0%":
                    st_["nf"] = "0%"
                    st_["ha"] = "right"
                    model.styles.append(st_)
                    cell_["s"] = len(model.styles) - 1
    # Note 34 : pas de variation sur la ligne de controle de la tresorerie
    model.formulas.pop(("NOTE 34", "G47"), None)
    model.consts.pop(("NOTE 34", "G47"), None)

    # ------------------------------------------ identite du dossier d'origine du modele retiree (confidentialite)
    for (sh_, a_), v_ in list(model.consts.items()):
        if isinstance(v_, str) and re.search(r"GREMADI|BOBIEL|54526|ZOUBEIROU|GAWADO|20320931", v_):
            nv_ = re.sub(r"\s*(CABINET MEDICAL GREMADI|PHARMACIE GAWADO|54526/R|NIAMEY, BOBIEL|BOBIEL|DR ZOUBEIROU HAOUA|20320931)\s*", "", v_)
            nv_ = re.sub(r"CABINET MEDICAL GR.*$", "", nv_).strip()
            if nv_ and nv_ != v_ and nv_.endswith(":"):
                model.consts[(sh_, a_)] = nv_
            else:
                model.consts.pop((sh_, a_), None)
