"""Declarations annexes : taxe d'apprentissage (TAP) et taxe sur certains frais generaux (TCFGE)."""
import re

# Lignes de la declaration TAP (lettres du formulaire DGI-551-TAP)
TAP_LIGNES = [
    ("A", "Rémunérations principales – montant brut", "661;662"),
    ("B", "Montant cumulé des déductions pour pensions ou retraites", ""),
    ("D", "Indemnités de dépaysement – montant brut", ""),
    ("E", "Montant cumulé des abattements (17 %)", ""),
    ("G", "Rémunérations accessoires ou diverses – montant brut", "663"),
    ("H", "Indemnités de rupture de contrat de travail – montant brut", ""),
    ("I", "Avantages en nature", ""),
    ("J", "Rémunérations versées à certains dirigeants et administrateurs", ""),
]

TCFGE_LIGNES = [
    ("a", "Cadeaux", ""),
    ("b", "Frais de réception", ""),
    ("c", "Frais de congrès et de manifestations assimilées", ""),
    ("d", "Dépenses afférentes aux véhicules et autres biens ou services mis à la disposition de certaines personnes", ""),
    ("e", "Fraction taxable des frais de transport aérien", ""),
]


def num(v):
    from .nombres import num as _num
    return _num(v)


def _rate(v, default):
    """Taux : valeur par defaut si non renseigne ; 0 accepte (exoneration) ; 28 lu comme 28 %."""
    if v in (None, ""):
        return default
    r = num(v)
    return r / 100 if r > 1 else r


def sum_prefixes(entries, prefixes, sign=1):
    """Somme des soldes debiteurs (sign=1) des comptes commencant par l'un des prefixes.
    Un prefixe precede de '-' est exclu."""
    pref = [p.strip() for p in re.split(r"[;,\s]+", prefixes or "") if p.strip()]
    inc = [p for p in pref if not p.startswith("-")]
    exc = [p[1:] for p in pref if p.startswith("-")]
    tot = 0.0
    for e in entries or []:
        a = re.sub(r"\D", "", str(e.get("compte", "")))
        if any(a.startswith(p) for p in inc) and not any(a.startswith(p) for p in exc):
            tot += num(e.get("sd")) - num(e.get("sc"))
    return tot * sign


def compute_tap(dossier, params):
    tap = dossier.get("tap") or {}
    lignes = tap.get("lignes") or {}
    bal = dossier.get("balance_n")
    vals = {}
    for code, lib, defc in TAP_LIGNES:
        l = lignes.get(code) or {}
        if l.get("montant") not in (None, ""):
            vals[code] = num(l.get("montant"))
        else:
            comptes = l.get("comptes") if l.get("comptes") is not None else defc
            vals[code] = sum_prefixes(bal, comptes) if comptes else 0.0
    C = vals["A"] - vals["B"]
    F = vals["D"] - vals["E"]
    K = C + F + vals["G"] + vals["H"] + vals["I"] + vals["J"]
    # base des travailleurs non nigeriens (taux 5 %)
    if tap.get("base_etrangers") not in (None, ""):
        base5 = num(tap.get("base_etrangers"))
    else:
        base5 = sum_prefixes(bal, tap.get("comptes_etrangers", "662"))
    base5 = max(0.0, min(base5, K))
    base3 = K - base5
    t3 = _rate(params.get("taux_tap_nat"), 0.03)
    t5 = _rate(params.get("taux_tap_etr"), 0.05)
    tap3 = round(base3 * t3)
    tap5 = round(base5 * t5)
    L = tap3 + tap5
    form = dict(tap.get("formation") or {})
    frais = dossier.get("formations") or []
    if frais:
        # le detail des frais de formation remplace les montants globaux saisis
        cat = {"A": "frais_formation", "B": "salaires_techniciens", "C": "bourses", "D": "concours"}
        for k in cat.values():
            form[k] = 0.0
        etabs = []
        for f in frais:
            c = (f.get("categorie") or "A").upper()
            if c == "E":
                etabs.append({"nom": f.get("organisme") or f.get("libelle") or "", "adresse": f.get("adresse") or "",
                              "montant": num(f.get("montant"))})
            else:
                key = cat.get(c, "frais_formation")
                form[key] = num(form.get(key)) + num(f.get("montant"))
        # regroupement par etablissement (3 lignes sur l'imprime)
        grp = {}
        for e in etabs:
            g = grp.setdefault(e["nom"], {"nom": e["nom"], "adresse": e["adresse"], "montant": 0.0})
            g["montant"] += e["montant"]
        form["etablissements"] = list(grp.values())
    M = sum(num(form.get(k)) for k in ("frais_formation", "salaires_techniciens", "bourses", "concours"))
    etab_list = form.get("etablissements") or []
    M += sum(num(x.get("montant")) for x in etab_list)
    apprentis = tap.get("apprentis") or []
    M += sum(num(x.get("remuneration")) for x in apprentis if tap.get("apprentis_deductibles"))
    mode = tap.get("mode_formation") or "base"
    if mode == "base":
        # frais de formation deduits de la base imposable, puis application des taux
        ded = min(M, K)
        part3 = ded * (base3 / K) if K else 0.0
        part5 = ded - part3
        net3, net5 = max(0.0, base3 - part3), max(0.0, base5 - part5)
        P = round(net3 * t3) + round(net5 * t5)
        N = L - P
    else:
        # deduction sur la taxe, plafonnee a 50 %
        ded = 0.0
        net3, net5 = base3, base5
        N = min(M, round(L * 0.5))
        P = L - N
    return {"vals": vals, "C": C, "F": F, "K": K, "base3": base3, "base5": base5, "tap3": tap3, "tap5": tap5,
            "L": L, "M": M, "N": N, "P": P, "t3": t3, "t5": t5, "apprentis": apprentis, "form": form,
            "ffp": num(tap.get("ffp")), "mode": mode, "ded_base": ded, "net3": net3, "net5": net5,
            "base_nette": net3 + net5, "tap3_net": round(net3 * t3) if mode == "base" else tap3,
            "tap5_net": round(net5 * t5) if mode == "base" else tap5}


def compute_tcfge(dossier, params):
    t = dossier.get("tcfge") or {}
    lignes = t.get("lignes") or {}
    bal = dossier.get("balance_n")
    out = {}
    total = 0.0
    for code, lib, defc in TCFGE_LIGNES:
        l = lignes.get(code) or {}
        if l.get("brut") not in (None, ""):
            brut = num(l.get("brut"))
        else:
            comptes = l.get("comptes") or defc
            brut = sum_prefixes(bal, comptes) if comptes else 0.0
        ded = num(l.get("deduction"))
        net = max(0.0, brut - ded)
        out[code] = (brut, ded, net)
        total += net
    taux = _rate(params.get("taux_tcfge"), 0.28)
    return {"lignes": out, "base": total, "taux": taux, "montant": round(total * taux)}


def prepare(ev, dossier, params):
    tap = compute_tap(dossier, params)
    tc = compute_tcfge(dossier, params)
    params.update({
        "tap_base": tap["K"], "tap_3": tap["tap3"], "tap_5": tap["tap5"], "tap_ffp": tap["ffp"],
        "tap_formation": tap["N"], "tap_mode": tap["mode"], "tap_ded_base": tap["ded_base"],
        "tap_base_nette": tap["base_nette"], "tap_3_net": tap["tap3_net"], "tap_5_net": tap["tap5_net"],
        "tap_total": tap["P"] + tap["ffp"], "tcfge_base": tc["base"], "tcfge_montant": tc["montant"],
    })
    ev.decl = {"tap": tap, "tcfge": tc}
