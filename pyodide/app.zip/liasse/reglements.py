"""Registre des acomptes, precomptes et credits d'impot (saisie ou import : releves de douane,
releves bancaires, attestations de retenue des clients, quittances d'acomptes)."""
import re
import datetime

TYPES = [
    ("acompte1", "1er acompte provisionnel ISB"),
    ("acompte2", "2e acompte provisionnel ISB"),
    ("acompte3", "3e acompte provisionnel ISB"),
    ("precompte_douane", "Précompte ISB perçu en douane (importations)"),
    ("precompte_client", "Précompte ISB retenu par les clients / l'État"),
    ("precompte_banque", "Précompte ou retenue prélevé par la banque"),
    ("precompte_autre", "Autre précompte / retenue à la source"),
    ("credit_impot", "Crédit d'impôt ou excédent antérieur imputable"),
]
LIB = dict(TYPES)


def num(v):
    from .nombres import num as _num
    return _num(v)


def totaux(dossier):
    t = {k: 0.0 for k, _ in TYPES}
    for r in dossier.get("reglements") or []:
        k = r.get("type")
        if k in t:
            t[k] += num(r.get("montant"))
    t["precomptes"] = t["precompte_douane"] + t["precompte_client"] + t["precompte_banque"] + t["precompte_autre"]
    return t


def apply_params(dossier, params):
    """Le registre, s'il est renseigne, alimente les lignes du tableau de passage et du bordereau."""
    regs = dossier.get("reglements") or []
    if not regs:
        return None
    t = totaux(dossier)
    # un montant saisi directement sur la page 73 ou 86 (« _manuel ») prime sur le registre
    for k in ("acompte1", "acompte2", "acompte3", "credit_impot"):
        if any(r.get("type") == k for r in regs) and not params.get(k + "_manuel"):
            params[k] = t[k]
    if any(str(r.get("type", "")).startswith("precompte") for r in regs) and not params.get("precomptes_manuel"):
        params["precomptes"] = t["precomptes"]
    return t


def guess_type(text, default):
    s = (text or "").lower()
    if "douane" in s or "import" in s or "dédouan" in s or "dedouan" in s:
        return "precompte_douane"
    if "banque" in s or "bancaire" in s:
        return "precompte_banque"
    if "acompte" in s:
        if re.search(r"premi|\b1\s*(er|ère|ere|re|e)?\b", s):
            return "acompte1"
        if re.search(r"deuxi|second|\b2\s*(ème|eme|e|nd)?\b", s):
            return "acompte2"
        if re.search(r"troisi|\b3\s*(ème|eme|e)?\b", s):
            return "acompte3"
    if "client" in s or "retenu" in s or "précompte" in s or "precompte" in s:
        return "precompte_client"
    if "crédit" in s or "credit" in s or "excédent" in s:
        return "credit_impot"
    return default


KW = {
    "date": ["date"],
    "reference": ["référence", "reference", "réf", "n°", "numéro", "numero", "quittance", "déclaration", "declaration", "liquidation"],
    "tiers": ["tiers", "client", "fournisseur", "banque", "bureau", "organisme", "libellé", "libelle", "désignation"],
    "nature": ["nature", "type", "objet"],
    "base": ["base", "valeur", "montant ht", "assiette"],
    "taux": ["taux"],
    "montant": ["précompte", "precompte", "isb", "retenue", "acompte", "montant", "impôt", "impot"],
}


def extract(rows, default_type):
    from .importer import _num
    header = None
    for i, r in enumerate(rows[:25]):
        txt = " ".join(str(x).lower() for x in r if x is not None)
        if sum(1 for k in ("date", "montant", "précompte", "precompte", "isb", "référence", "reference", "base", "n°") if k in txt) >= 2:
            header = i
            break
    if header is None:
        raise ValueError("En-tête non reconnu : prévoir au moins les colonnes Date et Montant (ou Précompte).")
    heads = [str(x or "").strip().lower() for x in rows[header]]
    cols = {}
    # la colonne montant : la derniere colonne correspondant aux mots-cles (precompte prioritaire)
    for key in ("date", "reference", "nature", "tiers", "base", "taux"):
        for j, h in enumerate(heads):
            if j in cols.values():
                continue
            if any(k in h for k in KW[key]):
                cols[key] = j
                break
    for kw in ("précompte", "precompte", "isb", "retenue", "acompte", "montant", "impôt", "impot"):
        cands = [j for j, h in enumerate(heads) if kw in h and j not in cols.values()]
        if cands:
            cols["montant"] = cands[-1]
            break
    if "montant" not in cols:
        raise ValueError("Colonne du montant (précompte / retenue / montant) introuvable.")
    out = []
    for r in rows[header + 1:]:
        def g(k):
            j = cols.get(k)
            return r[j] if j is not None and j < len(r) else None
        m = _num(g("montant"))
        if not m:
            continue
        lab = " ".join(str(g(k) or "") for k in ("nature", "tiers", "reference"))
        if lab.strip().lower().startswith("total"):
            continue
        d = g("date")
        if isinstance(d, datetime.datetime):
            d = d.date()
        if isinstance(d, datetime.date):
            d = d.isoformat()
        t = _num(g("taux"))
        out.append({"type": guess_type(str(g("nature") or ""), default_type) if g("nature") else default_type,
                    "date": d or "", "reference": str(g("reference") or "").strip(),
                    "tiers": str(g("tiers") or "").strip(), "base": _num(g("base")) or "",
                    "taux": (t * 100 if 0 < t <= 1 else t) or "", "montant": m})
    return out
