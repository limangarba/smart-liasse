"""Notes annexes chiffrees / non chiffrees.

Une note est « chiffree » lorsqu'au moins un montant non nul apparait dans son corps (hors en-tete)
ou lorsque l'utilisateur y a saisi une information. Les notes non chiffrees ne sont pas imprimees
(SYSCOHADA, fiche R4, renvoi (1)) et sont cochees N/A dans la fiche R4."""
import re

from .layout import parse_area
from .pages import PLAN

R4 = "Fiche R4"
TOUJOURS = {"note2", "note36a", "note36b"}          # informations obligatoires et table des codes
TEXTE = {"note37": "NOTE 37", "note38": "NOTE 38"}  # notes redactionnelles
PREMIERE_LIGNE = 9                                   # les lignes 1 a 8 portent l'en-tete commun


def _label(pid):
    """note16bis -> 'NOTE 16B BIS', note36a -> 'NOTE 36', note3a -> 'NOTE 3A'."""
    m = re.fullmatch(r"note(\d+)([a-z]*)", pid)
    if not m:
        return None
    num, suf = m.groups()
    if suf == "bis":
        return f"NOTE {num}B BIS"
    if num == "36":
        return "NOTE 36"
    return f"NOTE {num}{suf.upper()}"


def _chiffree(res, sheet, area):
    r1, c1, r2, c2 = parse_area(area)
    ev = res.ev
    for (sh, a) in list(res.model.formulas.keys()) + [k for k in res.overrides]:
        if sh != sheet:
            continue
        m = re.fullmatch(r"([A-Z]+)(\d+)", a)
        if not m:
            continue
        row = int(m.group(2))
        if row < max(r1, PREMIERE_LIGNE) or row > r2:
            continue
        col = 0
        for ch in m.group(1):
            col = col * 26 + ord(ch) - 64
        if not (c1 <= col <= c2):
            continue
        try:
            v = ev.get(sh, a)
        except Exception:
            continue
        if (sh, a) in res.overrides and isinstance(v, str) and v.strip():
            return True
        if isinstance(v, (int, float)) and not isinstance(v, bool) and abs(v) >= 0.5:
            return True
    return False


def statut(res):
    """{pid: True si chiffree} pour chaque page de note annexe, avec mise a jour de la fiche R4."""
    cache = res.__dict__.setdefault("_cache", {})
    if "notes" in cache:
        return cache["notes"]
    textes = (res.dossier.get("textes") or {})
    out = {}
    for pid, sec, title, sheet, area, *_ in PLAN:
        if sec != "Notes annexes":
            continue
        if pid in TOUJOURS:
            out[pid] = True
        elif pid == "note39":
            out[pid] = bool(str(textes.get("note39") or "").strip())
        elif pid in TEXTE:
            out[pid] = any(k[0] == TEXTE[pid] for k in res.overrides) or bool(str(textes.get(pid) or "").strip())
        elif area.startswith(("TEXTE", "CUSTOM")):
            out[pid] = True
        else:
            out[pid] = _chiffree(res, sheet, area)
    # Note 36 : un seul statut pour ses deux pages
    # fiche R4 : A / N/A coherents avec ce qui est imprime
    lignes = {}
    for r in range(9, 62):
        lab = str(res.ev.get(R4, f"A{r}") or "").strip().upper()
        if lab:
            lignes[re.sub(r"\s+", " ", lab)] = r
    for pid, ok in out.items():
        r = lignes.get(_label(pid) or "")
        if r:
            res.ev.set(R4, f"I{r}", "X" if ok else "")
            res.ev.set(R4, f"J{r}", "" if ok else "X")
    res.ev.reset_cache()
    cache["notes"] = out
    return out


def non_chiffrees(res):
    return [pid for pid, ok in statut(res).items() if not ok]
