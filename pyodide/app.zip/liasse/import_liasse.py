"""Import d'une liasse complete (Excel ou PDF) pour verification de conformite, reprise et rapport.

Deux modes :
  A. classeur Excel du meme modele (feuilles « Balance std » et « Fiche R1 ») : reprise integrale
     de la balance standard N et N-1, de l'identite, des parametres fiscaux et des saisies des notes ;
  B. tout autre fichier (PDF de liasse, Excel d'un autre modele) : lecture des etats par leurs
     codes REF (AD..BZ, CA..DZ, TA..XI, ZA..ZH), reconstitution d'une balance equivalente.

Dans les deux cas, les montants declares sont conserves dans dossier["import"]["declare"] et
compares au recalcul de l'application (controles arithmetiques + ecarts poste par poste)."""
import datetime
import io
import re

from .model import get_model, BAL
from . import engine

BM = "Bilan modèle 1"
R1, R2 = "Fiche R1", "Fiche R2"
PASS = "TABLEAU DE PASSAGE"
DEF = "TRAITEMENT DE DEFICITS"

# colonnes de lecture par section (feuille, colonne du code, colonnes des montants)
SECTIONS = {
    "actif": (BM, "A", ["D", "E", "F", "G"], ["Brut", "Amort./dépréc.", "Net N", "Net N-1"]),
    "passif": (BM, "H", ["K", "L"], ["N", "N-1"]),
    "cr": ("RESULTAT", "A", ["H", "I"], ["N", "N-1"]),
    "tft": ("TFT", "A", ["H", "I"], ["N", "N-1"]),
}
SECTION_TITRES = {"actif": "Bilan – actif", "passif": "Bilan – passif", "cr": "Compte de résultat",
                  "tft": "Tableau des flux de trésorerie"}

# sous-totaux SYSCOHADA (charges en negatif dans le compte de resultat)
TOTAUX = {
    "AD": "AE+AF+AG+AH", "AI": "AJ+AK+AL+AM+AN", "AQ": "AR+AS", "AZ": "AD+AI+AP+AQ",
    "BG": "BH+BI+BJ", "BK": "BA+BB+BG", "BT": "BQ+BR+BS", "BZ": "AZ+BK+BT+BU",
    "CP": "CA+CB+CD+CE+CF+CG+CH+CJ+CL+CM", "DD": "DA+DB+DC", "DF": "CP+DD",
    "DP": "DH+DI+DJ+DK+DM+DN", "DT": "DQ+DR", "DZ": "DF+DP+DT+DV",
    "XA": "TA+RA+RB", "XB": "TA+TB+TC+TD",
    "XC": "XB+RA+RB+TE+TF+TG+TH+TI+RC+RD+RE+RF+RG+RH+RI+RJ", "XD": "XC+RK", "XE": "XD+TJ+RL",
    "XF": "TK+TL+TM+RM+RN", "XG": "XE+XF", "XH": "TN+TO+RO+RP", "XI": "XG+XH+RQ+RS",
    "ZB": "FA+FB+FC+FD+FE", "ZC": "FF+FG+FH+FI+FJ", "ZD": "FK+FL+FM+FN", "ZE": "FO+FP+FQ",
    "ZF": "ZD+ZE", "ZG": "ZB+ZC+ZF", "ZH": "ZG+ZA",
}
CHARGES = ["RA", "RB", "RC", "RD", "RE", "RF", "RG", "RH", "RI", "RJ", "RK", "RL", "RM", "RN", "RO", "RP", "RQ", "RS"]

# balance reconstituee (mode B) : code -> (compte brut, compte amortissement)
ACTIF_CPT = {
    "AE": ("211", "2811"), "AF": ("212", "2812"), "AG": ("215", "2815"), "AH": ("218", "2818"),
    "AJ": ("221", "2821"), "AK": ("231", "2831"), "AL": ("234", "2834"), "AM": ("241", "2841"),
    "AN": ("245", "2845"), "AP": ("251", "2951"), "AR": ("261", "2961"), "AS": ("271", "2971"),
    "BA": ("485", "4981"), "BB": ("311", "3911"), "BH": ("409", "4901"), "BI": ("411", "4911"),
    "BJ": ("4491", "4961"), "BQ": ("501", "5901"), "BR": ("511", "5911"), "BS": ("521", "5921"),
    "BU": ("478", None),
}
PASSIF_CPT = {
    "CA": "101", "CB": "109", "CD": "1051", "CE": "106", "CF": "111", "CG": "118", "CH": ("121", "129"),
    "CL": "141", "CM": "151", "DA": "162", "DB": "172", "DC": "191", "DH": "481", "DI": "419",
    "DJ": "401", "DK": "4431", "DM": "4712", "DN": "4991", "DQ": "565", "DR": "5211", "DV": "479",
}
CR_CPT = {
    "TA": "701", "RA": "601", "RB": "6031", "TB": "702", "TC": "706", "TD": "707", "TE": "734", "TF": "721",
    "TG": "711", "TH": "758", "TI": "781", "RC": "602", "RD": "6032", "RE": "604", "RF": "6033", "RG": "612",
    "RH": "622", "RI": "641", "RJ": "658", "RK": "661", "TJ": "791", "RL": "6813", "TK": "771", "TL": "797",
    "TM": "787", "RM": "671", "RN": "697", "TN": "821", "TO": "841", "RO": "811", "RP": "831", "RQ": "871",
    "RS": "891",
}

# cellules fiscales comparees en mode A (liasse du meme modele)
FISCAL = [(PASS, a) for a in ("G12", "G13", "G15", "G16", "G22", "G24", "G26", "G27", "G32", "G34", "G37", "G38",
                              "G44", "G45", "G46", "G48", "G49", "G50", "B53", "D53", "D54", "F53", "F54",
                              "G57", "G58", "G59", "G60", "G61", "F62")]
FISCAL_LIB = {"B53": "Base de l'IMF (chiffre d'affaires)", "D53": "IMF calculé", "D54": "ISB calculé",
              "F53": "IMF dû", "F54": "ISB dû", "F62": "Reliquat à payer", "G57": "1er acompte",
              "G58": "2e acompte", "G59": "3e acompte", "G60": "Crédit d'impôt", "G61": "Précomptes ISB"}

EXCLUS = {BAL, R1, "CONTROLE", "Garde DGI", "Couverture", "TDC 1", "TDC 2", "Conditions"}


# ================================================================ utilitaires
def _n(v):
    """Nombre depuis une cellule ou un texte (formats francais et anglais, parentheses, tirets)."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", " ").replace(" ", " ")
    if s in ("-", "–", "—", ""):
        return 0.0 if s else None
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()").replace(" ", "")
    if s.endswith("-"):
        neg, s = True, s[:-1]
    if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", s):
        s = s.replace(",", "")
    elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+(,\d+)?", s):
        s = s.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d+,\d{1,2}", s):
        s = s.replace(",", ".")
    try:
        f = float(s)
    except ValueError:
        return None
    return -f if neg else f


def _eq(a, b, tol=1.0):
    return abs((a or 0) - (b or 0)) < tol


def _iso(v):
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    if isinstance(v, datetime.date):
        return v.isoformat()
    return v


def code_map():
    """code REF -> (section, feuille, ligne, libelle) d'apres le modele de l'application."""
    m = get_model()
    out = {}
    for sec, (sh, col, cols, _) in SECTIONS.items():
        for (s, a), v in m.consts.items():
            if s != sh or not a.startswith(col) or not a[len(col):].isdigit():
                continue
            if isinstance(v, str) and re.fullmatch(r"[A-Z]{2}", v.strip()):
                r = int(a[len(col):])
                lib = ""
                start = "ABCDEFGHIJ".index(col) + 1
                for c in "ABCDEFGHIJ"[start:start + 3]:
                    t = m.consts.get((sh, f"{c}{r}"))
                    if isinstance(t, str) and len(t.strip()) > 3:
                        lib = re.sub(r"\s+", " ", t.strip())
                        break
                out[v.strip()] = (sec, sh, r, lib)
    return out


def ours(res):
    """Montants recalcules par l'application, par code."""
    out = {}
    for code, (sec, sh, r, lib) in code_map().items():
        out[code] = [round(res.num(sh, f"{c}{r}")) for c in SECTIONS[sec][2]]
    return out


# ================================================================ lecture Excel
def load_xlsx(data):
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter

    def grab(values):
        wb = load_workbook(io.BytesIO(data), data_only=values, read_only=True)
        out = {}
        for ws in wb.worksheets:
            d = {}
            for row in ws.iter_rows():
                for c in row:
                    if getattr(c, "value", None) is not None and hasattr(c, "column"):
                        d[f"{get_column_letter(c.column)}{c.row}"] = c.value
            out[ws.title] = d
        wb.close()
        return out
    return grab(True), grab(False)


def is_modele(V):
    return BAL in V and R1 in V and BM in V


# ================================================================ mode A
def declared_modele(V):
    out = {}
    for code, (sec, sh, r, lib) in code_map().items():
        S = V.get(sh) or {}
        col = SECTIONS[sec][1]
        if str(S.get(f"{col}{r}") or "").strip() != code:
            continue
        out[code] = [_n(S.get(f"{c}{r}")) or 0.0 for c in SECTIONS[sec][2]]
    return out


def dossier_modele(V, F, nom_fichier):
    m = get_model()
    notes = []
    d = {"identite": {}, "exercice": {}, "balance_n": [], "balance_n1": [], "immobilisations": [],
         "params": {}, "cells": {}, "textes": {}, "tap": {}, "tcfge": {}, "options": {}, "mapping": {}}
    # --- balances (lignes elementaires de la balance standard)
    S = V.get(BAL, {})
    seen = {}
    for r, acct, lib, code in m.leaf_info:
        a_theirs = str(S.get(f"A{r}") or "").strip()
        if a_theirs.endswith(".0"):
            a_theirs = a_theirs[:-2]
        k = seen.get(acct, 0)
        seen[acct] = k + 1
        compte = acct if k == 0 else f"{acct}0000{k}"
        vals = {c: _n(S.get(f"{c}{r}")) or 0.0 for c in "DEFG"}
        if k or (a_theirs and a_theirs != acct):
            d["mapping"][compte] = r
        intit = str(S.get(f"B{r}") or lib).strip()
        if a_theirs and a_theirs != acct:
            intit = f"{intit} (compte {a_theirs} du fichier)"
        if vals["F"] or vals["G"]:
            d["balance_n"].append({"compte": compte, "intitule": intit, "sd": round(vals["F"], 2), "sc": round(vals["G"], 2)})
        if vals["D"] or vals["E"]:
            d["balance_n1"].append({"compte": compte, "intitule": intit, "sd": round(vals["D"], 2), "sc": round(vals["E"], 2)})
    # --- identite et exercice
    R = V.get(R1, {})
    for key, lab, grp, sh, addr, typ in engine.FIELDS:
        v = R.get(addr)
        if v in (None, ""):
            continue
        if typ == "date":
            v = _iso(v)
            if isinstance(v, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", v):
                v = v[:10]
        elif typ == "int":
            try:
                v = int(float(v))
            except (TypeError, ValueError):
                continue
        else:
            v = str(v).strip()
        d["identite" if grp == "identite" else "exercice"][key] = v
    exo = d["exercice"]
    if not exo.get("fin") and isinstance(R.get("M5"), (datetime.date, datetime.datetime)):
        exo["fin"] = _iso(R.get("M5"))[:10]
    if exo.get("fin") and not exo.get("annee"):
        exo["annee"] = int(exo["fin"][:4])
    RR = V.get(R2, {})
    for key, lab, addrs in engine.CODE_FIELDS:
        s = "".join(str(int(RR[a]) if isinstance(RR.get(a), (int, float)) else (RR.get(a) or "")).strip() for a in addrs)
        if s.strip():
            d["identite"][key] = s
    # --- parametres fiscaux
    P = V.get(PASS, {})
    FP = F.get(PASS, {})
    p = d["params"]
    for addr, key in (("G57", "acompte1"), ("G58", "acompte2"), ("G59", "acompte3"), ("G60", "credit_impot"),
                      ("G61", "precomptes"), ("G67", "factures_sans_nif"), ("G44", "tap_n1"), ("G27", "conges_n")):
        v = _n(P.get(addr))
        if v:
            p[key] = v
    tap = _n(P.get("G26"))
    if tap is not None:
        p["tap_reintegrer"] = False
        p["tap_reintegree_saisie"] = tap
        notes.append(f"Taxe d'apprentissage réintégrée reprise telle que déclarée ({tap:,.0f} F).".replace(",", " "))
    f53 = str(FP.get("D53") or "")
    mm = re.search(r"\*\s*([\d.,]+)\s*%", f53)
    if mm:
        p["taux_imf"] = float(mm.group(1).replace(",", ".")) / 100
    elif _n(P.get("B53")) and _n(P.get("D53")):
        p["taux_imf"] = round(_n(P.get("D53")) / _n(P.get("B53")), 5)
    if _n(P.get("B54")) and _n(P.get("D54")):
        p["taux_isb"] = round(_n(P.get("D54")) / _n(P.get("B54")), 4)
    D = V.get(DEF, {})
    for addr, key in (("F23", "ard_anterieurs"), ("F32", "conges_n1")):
        v = _n(D.get(addr))
        if v:
            p[key] = v
    for i, r in enumerate((12, 13, 14)):
        o, imp = _n(D.get(f"I{r}")), _n(D.get(f"J{r}"))
        if o:
            p[f"deficit_orig_{i}"] = abs(o)
        if imp:
            p[f"deficit_impute_{i}"] = abs(imp)
        an = None
        for cand in (D.get(f"B{r + 2}"), D.get(f"H{r}")):
            if isinstance(cand, (datetime.date, datetime.datetime)):
                an = str(cand.year)
                break
            c = _n(cand)
            if c and 1990 <= c <= 2100:
                an = str(int(c))
                break
            if isinstance(cand, str) and re.search(r"(19|20)\d\d", cand):
                an = re.search(r"(19|20)\d\d", cand).group(0)
                break
        if an:
            p[f"deficit_annee_{i}"] = an
    pg = _n((V.get("Page de garde") or {}).get("F47"))
    if pg:
        p["nb_exemplaires"] = int(pg)
    # --- saisies des pages (notes, fiches, etats) : cellules d'entree du modele
    skip = {(R2, a) for _, _, addrs in engine.CODE_FIELDS for a in addrs}
    skip |= {(R2, f"Z{29 + 3 * k}") for k in range(9)}
    ecartees = []
    n_cells = 0
    for sh, cells in V.items():
        if sh in EXCLUS or sh not in m.sheets:
            continue
        # alignement : les libelles du modele doivent se retrouver aux memes adresses
        labels = [(a, v) for (s, a), v in m.consts.items() if s == sh and isinstance(v, str) and len(v.strip()) > 3]
        if labels:
            ok = sum(1 for a, v in labels if re.sub(r"\s+", " ", str(cells.get(a) or "")).strip().lower()
                     == re.sub(r"\s+", " ", v).strip().lower())
            if ok / len(labels) < 0.6:
                ecartees.append(sh)
                continue
        for addr, tv in cells.items():
            key = (sh, addr)
            if key in m.formulas or key in skip:
                continue
            oc = m.consts.get(key)
            if isinstance(oc, str) and oc.strip():
                continue
            raw = (m.sheets[sh]["cells"].get(addr) or {}).get("v")
            if raw is not None and (raw == tv or (isinstance(raw, str) and isinstance(tv, str)
                                                  and raw.strip() == tv.strip())):
                continue   # contenu d'origine du modele (exemples), non repris
            tv = _iso(tv)
            if isinstance(tv, str):
                tv = tv.strip()
                if not tv or tv.startswith("="):
                    continue
            if isinstance(oc, (int, float)) and isinstance(tv, (int, float)) and _eq(oc, tv, 0.005):
                continue
            if isinstance(tv, float) and tv.is_integer():
                tv = int(tv)
            d["cells"][f"{sh}!{addr}"] = tv
            n_cells += 1
    if ecartees:
        notes.append("Pages non reprises (structure différente du modèle) : " + ", ".join(ecartees[:12])
                     + (" …" if len(ecartees) > 12 else "") + ".")
    notes.append(f"{len(d['balance_n'])} lignes de balance N, {len(d['balance_n1'])} lignes N-1 et {n_cells} saisies de pages reprises.")
    return d, notes


def fiscal_declare(V):
    P = V.get(PASS, {})
    out = {}
    for sh, a in FISCAL:
        v = _n(P.get(a))
        if v is not None:
            out[f"{sh}!{a}"] = v
    return out


# ================================================================ lecture generique (PDF / autre Excel)
_CHUNK = re.compile(r"\S+(?: \S+)*")
_NUM = re.compile(r"^\(?-?\d{1,3}(?:[   .,]\d{3})*(?:[.,]\d+)?\)?-?$|^\(?-?\d+(?:[.,]\d+)?\)?$|^[-–—]$")


def _tokens_line(text):
    """Decoupe une ligne de texte mis en page en jetons (position de fin, texte, nombre ou None)."""
    toks = []
    for m in re.finditer(r"\S+(?: (?=\S)\S*)*", text):
        chunk = m.group(0)
        # un bloc peut contenir libelle + nombres separes d'un seul espace : on isole les nombres en fin de bloc
        parts = re.split(r"(?<=\S) (?=\S)", chunk)
        # regroupe les milliers separes par un espace (1 234 567)
        merged = []
        for p in parts:
            if merged and re.fullmatch(r"\d{3}(?:[.,]\d+)?\)?", p) and re.fullmatch(r"\(?-?\d{1,3}(?:[   ]\d{3})*", merged[-1]):
                merged[-1] = merged[-1] + " " + p
            else:
                merged.append(p)
        pos = m.start()
        for p in merged:
            i = text.find(p, pos)
            end = i + len(p)
            pos = end
            val = _n(p) if _NUM.match(p) else None
            toks.append((end, p, val))
    return toks


def pages_pdf(data):
    import pypdf
    r = pypdf.PdfReader(io.BytesIO(data))
    pages = []
    for i, pg in enumerate(r.pages):
        try:
            t = pg.extract_text(extraction_mode="layout")
        except TypeError:
            t = pg.extract_text()
        except Exception:
            t = ""
        lines = [_tokens_line(L) for L in (t or "").splitlines()]
        pages.append((f"page {i + 1}", lines, t or ""))
    return pages


def pages_xlsx(V):
    from openpyxl.utils import column_index_from_string
    pages = []
    for sh, cells in V.items():
        rows = {}
        for addr, v in cells.items():
            m = re.fullmatch(r"([A-Z]+)(\d+)", addr)
            rows.setdefault(int(m.group(2)), []).append((column_index_from_string(m.group(1)), v))
        lines, text = [], []
        for r in sorted(rows):
            toks = []
            for c, v in sorted(rows[r]):
                if isinstance(v, datetime.datetime):
                    v = v.strftime("%d/%m/%Y")
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    toks.append((c * 10, str(v), float(v)))
                else:
                    s = str(v).strip()
                    if not s:
                        continue
                    if s.startswith("="):
                        continue
                    toks.append((c * 10, s, _n(s) if _NUM.match(s) else None))
            lines.append(toks)
            text.append("   ".join(t[1] for t in toks))
        pages.append((sh, lines, "\n".join(text)))
    return pages


def _segments(lines, codes):
    """Segments (code, [(pos, valeur)]) : un code en debut de ligne ou juste apres des montants."""
    segs = []
    for toks in lines:
        cur, prev = None, None
        for pos, txt, val in toks:
            if txt in codes and prev in (None, "num"):
                cur = [txt, []]
                segs.append(cur)
                prev = "code"
                continue
            if val is not None:
                if cur is not None:
                    cur[1].append((pos, val))
                prev = "num"
            else:
                prev = "txt"
    return segs


def extract_codes(pages):
    """Lit les montants par code REF dans les pages ; retourne (declare, sources, conflits)."""
    cm = code_map()
    by_sec = {}
    for c, (sec, *_) in cm.items():
        by_sec.setdefault(sec, set()).add(c)
    found, sources, conflits = {}, {}, []
    for name, lines, _ in pages:
        segs_all = _segments(lines, set(cm))
        for sec, codes in by_sec.items():
            k = len(SECTIONS[sec][2])
            segs = [s for s in segs_all if s[0] in codes]
            if len({s[0] for s in segs}) < max(4, 0.4 * len(codes)):
                continue
            allpos = [p for s in segs for p, _ in s[1]]
            tol = 5 if all(p % 10 == 0 for p in allpos) else 15
            groups = []
            for p in sorted(allpos):
                if groups and p - groups[-1][-1] <= tol:
                    groups[-1].append(p)
                else:
                    groups.append([p])
            if not groups:
                continue
            mx = max(len(g) for g in groups)
            strong = [g for g in groups if len(g) >= 0.3 * mx]
            if len(strong) < k:
                continue
            cols = [sorted(g)[len(g) // 2] for g in strong[-k:]]
            gap = min([cols[j + 1] - cols[j] for j in range(k - 1)] or [40])
            width = max(gap * 0.45, 4)
            page_vals = {}
            for code, nums in segs:
                vals = [None] * k
                for p, v in nums:
                    j = min(range(k), key=lambda j: abs(cols[j] - p))
                    if abs(cols[j] - p) <= width:
                        vals[j] = v
                if all(v is None for v in vals):
                    continue
                if code not in page_vals:
                    page_vals[code] = [v or 0.0 for v in vals]
            for code, vals in page_vals.items():
                if code in found:
                    if any(not _eq(a, b) for a, b in zip(found[code], vals)):
                        conflits.append((code, sources[code], found[code], name, vals))
                    continue
                found[code] = vals
                sources[code] = name
    return found, sources, conflits


def _conv_charges(dec):
    """Ramene les charges du compte de resultat en negatif si la liasse les presente en positif."""
    def xi_err(sign):
        vals = {c: (v[0] * (sign if c in CHARGES and c not in ("RB", "RD", "RF") else 1)) for c, v in dec.items() if c in CR_CPT or c.startswith("X")}
        calc = sum(vals.get(c, 0) for c in CR_CPT)
        return abs(calc - vals.get("XI", 0))
    if "XI" not in dec:
        return False
    pos = [dec[c][0] for c in CHARGES if c in dec and c not in ("RB", "RD", "RF") and dec[c][0]]
    if pos and all(v > 0 for v in pos) and xi_err(-1) < xi_err(1):
        for c in CHARGES:
            if c in dec and c not in ("RB", "RD", "RF"):
                dec[c] = [-v for v in dec[c]]
        return True
    return False


def identite_texte(text):
    ident, exo = {}, {}
    t = text.replace(" ", " ")

    def grab(pat, need_digit=False):
        for m in re.finditer(pat + r"\s*:\s*(\S.*?)(?:\s{3,}|$)", t, re.I | re.M):
            v = m.group(1).strip()
            if v and (not need_digit or re.search(r"\d", v)) and not v.endswith(":"):
                return v
        return ""
    den = grab(r"D[ÉE]NOMINATION SOCIALE(?: DE L'ENTIT[ÉE])?")
    if den:
        ident["denomination"] = den
    nif = grab(r"(?:Num[ée]ro d'Identification\s*\(NIF\)|\bNIF\b)", True)
    if nif:
        ident["nif"] = nif
    adr = grab(r"\bADRESSE")
    if adr:
        ident["adresse"] = adr
    sig = grab(r"SIGLE USUEL")
    if sig and len(sig) < 40 and sig not in ("0", "-"):
        ident["sigle"] = sig
    m = re.search(r"clos le\s*:?\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})", t, re.I)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        day, mon = (a, b) if b <= 12 else (b, a)
        if mon > 12:
            day, mon = b, a
        exo["fin"] = f"{y}-{mon:02d}-{day:02d}"
    else:
        ys = re.findall(r"31/12/(20\d\d)|31 d[ée]cembre (20\d\d)|12/31/(20\d\d)", t, re.I)
        yy = [int(next(x for x in g if x)) for g in ys]
        if yy:
            y = max(set(yy), key=yy.count)
            exo["fin"] = f"{y}-12-31"
    if exo.get("fin"):
        y = int(exo["fin"][:4])
        exo.update({"annee": y, "debut": f"{y}-01-01", "duree": 12, "prec_fin": f"{y - 1}-12-31", "prec_duree": 12})
    return ident, exo


def dossier_codes(dec, ident, exo):
    """Balance equivalente reconstituee a partir des montants declares (mode B)."""
    d = {"identite": dict(ident), "exercice": dict(exo), "balance_n": [], "balance_n1": [], "immobilisations": [],
         "params": {}, "cells": {}, "textes": {}, "tap": {}, "tcfge": {}, "options": {}, "mapping": {}}
    d["identite"].setdefault("pays_siege", "06")
    lib = {c: x[3] for c, x in code_map().items()}
    for idx, key in ((0, "balance_n"), (1, "balance_n1")):
        B = {}

        def put(acc, solde, code):
            if abs(solde) < 0.5:
                return
            e = B.setdefault(acc, {"compte": acc, "intitule": f"{lib.get(code, code)} [{code}]", "sd": 0.0, "sc": 0.0})
            if solde > 0:
                e["sd"] += solde
            else:
                e["sc"] += -solde
        for code, (cb, ca) in ACTIF_CPT.items():
            v = dec.get(code)
            if not v:
                continue
            if idx == 0:
                put(cb, v[0], code)
                if ca:
                    put(ca, -v[1], code)
                elif v[1]:
                    put(cb, -v[1], code)
            elif v[3] < 0 and ca:
                put(ca, v[3], code)
            else:
                put(cb, v[3], code)
        for code, acc in PASSIF_CPT.items():
            v = dec.get(code)
            if not v:
                continue
            val = v[idx]
            if isinstance(acc, tuple):
                acc = acc[0] if val >= 0 else acc[1]
            put(acc, -val, code)
        for code, acc in CR_CPT.items():
            v = dec.get(code)
            if v:
                put(acc, -v[idx], code)
        for e in B.values():
            e["sd"], e["sc"] = round(e["sd"], 2), round(e["sc"], 2)
        d[key] = sorted(B.values(), key=lambda e: e["compte"])
    # tableau des flux : colonne N-1 reprise ; flux d'investissement et de financement N repris tels que
    # declares (le detail des acquisitions, cessions et emprunts n'est pas deductible des seuls soldes)
    m = get_model()
    for code, (sec, sh, r, _) in code_map().items():
        if sec != "tft" or code not in dec:
            continue
        if (sh, f"I{r}") not in m.formulas:
            d["cells"][f"TFT!I{r}"] = dec[code][1]
        if code in ("FF", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ"):
            d["cells"][f"TFT!H{r}"] = dec[code][0]
    return d


# ================================================================ controles
def controles_declares(dec, fisc=None):
    """Controles arithmetiques de la liasse telle que deposee."""
    out = []

    def g(c, i=0):
        v = dec.get(c)
        return (v[i] if v and i < len(v) else 0.0) or 0.0

    def add(lib, a, b, niveau="anomalie"):
        out.append({"libelle": lib, "a": round(a), "b": round(b), "ecart": round(a - b), "ok": _eq(a, b, 1.5),
                    "niveau": niveau})
    if "BZ" in dec and "DZ" in dec:
        add("Bilan N : total actif (BZ) = total passif (DZ)", g("BZ", 2), g("DZ", 0), "critique")
        add("Bilan N-1 : total actif (BZ) = total passif (DZ)", g("BZ", 3), g("DZ", 1), "critique")
    for code in sorted(c for c in dec if c in ACTIF_CPT or c in TOTAUX and c < "C"):
        v = dec[code]
        if len(v) >= 3 and (v[0] or v[1]):
            if not _eq(v[0] - v[1], v[2], 1.5):
                add(f"Actif {code} : brut − amortissements = net", v[0] - v[1], v[2])
        if len(v) >= 3 and v[2] < -0.5:
            out.append({"libelle": f"Actif {code} : valeur nette négative", "a": round(v[2]), "b": 0, "ecart": round(v[2]),
                        "ok": False, "niveau": "anomalie"})
    for tot, formule in TOTAUX.items():
        if tot not in dec:
            continue
        parts = formule.split("+")
        if not any(p in dec for p in parts):
            continue
        n = len(dec[tot])
        cols = [0, 1, 2, 3] if n == 4 else [0, 1]
        for i in cols:
            calc = sum(g(p, i) for p in parts)
            if not _eq(calc, g(tot, i), 1.5):
                col = SECTIONS["actif"][3][i] if n == 4 else ("N" if i == 0 else "N-1")
                add(f"Sous-total {tot} ({col}) = {formule.replace('+', ' + ')}", g(tot, i), calc)
    if "CJ" in dec and "XI" in dec:
        add("Résultat du bilan (CJ) = résultat net du compte de résultat (XI) – N", g("CJ", 0), g("XI", 0), "critique")
        add("Résultat du bilan (CJ) = résultat net du compte de résultat (XI) – N-1", g("CJ", 1), g("XI", 1))
    if "ZH" in dec and "BT" in dec:
        add("TFT : trésorerie nette au 31/12 (ZH) = trésorerie actif (BT) − trésorerie passif (DT)", g("ZH", 0),
            g("BT", 2) - g("DT", 0), "critique")
    if "ZA" in dec and "BT" in dec:
        add("TFT : trésorerie au 1er janvier (ZA) = trésorerie nette N-1 du bilan", g("ZA", 0), g("BT", 3) - g("DT", 1))
    if "ZA" in dec and "ZH" in dec and len(dec["ZH"]) > 1 and g("ZH", 1):
        add("TFT : trésorerie d'ouverture N (ZA) = trésorerie de clôture N-1 (ZH N-1)", g("ZA", 0), g("ZH", 1))
    if "CA" in dec and "CP" in dec and g("CA") > 0 and g("CP") < g("CA") / 2:
        out.append({"libelle": "Capitaux propres (CP) inférieurs à la moitié du capital (CA) – AUSCGIE art. 371 (SARL) / 664 (SA)",
                    "a": round(g("CP")), "b": round(g("CA") / 2), "ecart": round(g("CP") - g("CA") / 2), "ok": False,
                    "niveau": "anomalie"})
    if fisc:
        f = lambda a: fisc.get(f"{PASS}!{a}") or 0.0
        if f"{PASS}!D53" in fisc and f("B53"):
            add("Passage : IMF = base × taux déclaré", f("D53"), f("B53") * (f("D53") / f("B53")))
        if f"{PASS}!F62" in fisc:
            add("Passage : reliquat = impôt dû − acomptes − crédit − précomptes", f("F62"),
                max(f("F53"), f("F54")) - f("G57") - f("G58") - f("G59") - f("G60") - f("G61"))
            if f("F62") < -0.5:
                out.append({"libelle": "Passage : reliquat négatif (excédent de versement à justifier ou à reporter en crédit d'impôt)",
                            "a": round(f("F62")), "b": 0, "ecart": round(f("F62")), "ok": False, "niveau": "imperfection"})
    return out


def ecarts(dec, res, fisc=None):
    """Ecarts entre la liasse importee et le recalcul de l'application."""
    cm = code_map()
    calc = ours(res)
    out = []
    for code in sorted(dec, key=lambda c: (list(SECTIONS).index(cm[c][0]), cm[c][2]) if c in cm else (9, 0)):
        if code not in cm or code not in calc:
            continue
        sec, sh, r, lib = cm[code]
        for i, colname in enumerate(SECTIONS[sec][3]):
            if i >= len(dec[code]):
                continue
            a, b = dec[code][i] or 0.0, calc[code][i] or 0.0
            if not _eq(a, b, 1.5):
                out.append({"section": SECTION_TITRES[sec], "code": code, "libelle": lib, "colonne": colname,
                            "declare": round(a), "recalcule": round(b), "ecart": round(a - b)})
    if fisc:
        for key, a in fisc.items():
            sh, addr = key.split("!")
            b = res.num(sh, addr)
            if not _eq(a, b, 1.5):
                m = get_model()
                r = int(addr[1:])
                lib = FISCAL_LIB.get(addr) or next((str(m.consts.get((sh, f"{c}{r}"))).strip() for c in "BCE"
                                                    if isinstance(m.consts.get((sh, f"{c}{r}")), str)), addr)
                out.append({"section": "Tableau de passage / impôt", "code": addr, "libelle": lib, "colonne": "N",
                            "declare": round(a), "recalcule": round(b), "ecart": round(a - b)})
    return out


def verifier(dossier, res=None):
    """Rapport de conformite a jour (a relancer apres modification du dossier)."""
    from . import alertes
    imp = dossier.get("import") or {}
    dec = {k: list(v) for k, v in (imp.get("declare") or {}).items()}
    fisc = imp.get("fiscal") or {}
    if res is None:
        res = engine.compute(dossier)
    ctrl = controles_declares(dec, fisc)
    ec = ecarts(dec, res, fisc)
    al = alertes.compute(res)
    ko = [c for c in ctrl if not c["ok"]]
    niveau = {"critique": 0, "anomalie": 0, "imperfection": 0, "manquement": 0}
    for c in ko:
        niveau[c["niveau"]] = niveau.get(c["niveau"], 0) + 1
    if any(c["niveau"] == "critique" for c in ko):
        verdict = ("non conforme", "La liasse déposée présente des déséquilibres bloquants : elle serait jugée irrecevable en l'état.")
    elif ko or len(ec) > 0:
        verdict = ("conforme avec réserves", "Les états sont équilibrés, mais des écarts ou incohérences doivent être corrigés ou justifiés avant dépôt.")
    else:
        verdict = ("conforme", "Aucune anomalie arithmétique ni écart de recalcul n'a été relevé sur les états principaux.")
    return {"controles": ctrl, "ecarts": ec, "alertes": al, "verdict": verdict[0], "commentaire": verdict[1],
            "nb_codes": len(dec), "conflits": imp.get("conflits") or [], "notes": imp.get("notes") or [],
            "fichier": imp.get("fichier"), "mode": imp.get("mode"), "date": imp.get("date")}


# ================================================================ point d'entree
def importer(filename, data):
    name = (filename or "").lower()
    notes = []
    fisc = {}
    conflits = []
    if name.endswith(".pdf") or data[:5] == b"%PDF-":
        pages = pages_pdf(data)
        txt = "\n".join(p[2] for p in pages)
        if len(txt.strip()) < 200:
            raise ValueError("Le PDF ne contient pas de texte exploitable (document numérisé). "
                             "Importer la version Excel ou un PDF généré par un logiciel.")
        dec, sources, conflits = extract_codes(pages)
        ident, exo = identite_texte(txt)
        mode = "PDF – lecture des états par codes REF"
    elif name.endswith((".xlsx", ".xlsm")):
        V, F = load_xlsx(data)
        if is_modele(V):
            dossier, notes = dossier_modele(V, F, filename)
            dec = declared_modele(V)
            fisc = fiscal_declare(V)
            mode = "Excel – modèle de liasse identique (reprise intégrale)"
            dossier["import"] = {}
            ident = exo = None
        else:
            pages = pages_xlsx(V)
            dec, sources, conflits = extract_codes(pages)
            ident, exo = identite_texte("\n".join(p[2] for p in pages))
            mode = "Excel – autre présentation, lecture des états par codes REF"
    else:
        raise ValueError("Format non pris en charge : importer un fichier .xlsx ou .pdf.")
    if len(dec) < 20:
        raise ValueError(f"Seuls {len(dec)} postes ont pu être lus. Le fichier ne semble pas contenir de bilan et de compte "
                         "de résultat au format SYSCOHADA (codes AD…BZ, CA…DZ, TA…XI).")
    if ident is not None:
        if _conv_charges(dec):
            notes.append("Charges présentées en valeurs positives dans le fichier : signe rétabli pour les contrôles.")
        manq = [c for c in ("BZ", "DZ", "XI", "CJ") if c not in dec]
        if manq:
            notes.append("Postes clés non lus : " + ", ".join(manq) + ".")
        dossier = dossier_codes(dec, ident, exo)
        notes.append(f"{len(dec)} postes lus ; balance équivalente reconstituée ({len(dossier['balance_n'])} comptes N, "
                     f"{len(dossier['balance_n1'])} comptes N-1). Paramètres fiscaux (acomptes, précomptes, déficits) à compléter.")
        if conflits:
            notes.append(f"{len(conflits)} poste(s) présentent des montants différents d'une page à l'autre.")
    if not dossier["identite"].get("denomination"):
        dossier["identite"]["denomination"] = re.sub(r"\.(xlsx|xlsm|pdf)$", "", filename or "Liasse importée", flags=re.I)
    dossier["import"] = {
        "fichier": filename, "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "mode": mode,
        "declare": dec, "fiscal": fisc, "notes": notes,
        "conflits": [{"code": c, "page1": p1, "valeurs1": v1, "page2": p2, "valeurs2": v2} for c, p1, v1, p2, v2 in conflits][:40],
    }
    return dossier
