"""Rendu HTML d'une page (apercu a l'ecran, cellules modifiables)."""
import html

from .pdf import page_size, MARGIN, compute_edges

PX = 96 / 72
BW = {"hair": 0.5, "thin": 1, "dotted": 1, "dashed": 1, "dashDot": 1, "dashDotDot": 1, "medium": 2,
      "mediumDashed": 2, "mediumDashDot": 2, "mediumDashDotDot": 2, "slantDashDot": 2, "thick": 3, "double": 3}
BS = {"dotted": "dotted", "dashed": "dashed", "mediumDashed": "dashed", "double": "double",
      "dashDot": "dashed", "dashDotDot": "dashed", "mediumDashDot": "dashed"}


def grid_html(g, zoom=1.0, editable=True):
    pw, ph = page_size(g.orient)
    tw, th = g.size()
    aw, ah = pw - 2 * MARGIN, ph - 2 * MARGIN
    s = min(aw / tw, ah / th, 1.0) if tw and th else 1.0
    k = s * PX * zoom
    W, H = pw * PX * zoom, ph * PX * zoom
    left = (MARGIN + (aw - tw * s) / 2) * PX * zoom
    top = MARGIN * PX * zoom
    H_, V_ = compute_edges(g)
    merge_idx = g.merge_at()
    out = [f'<div class="a4 {"land" if g.orient == "L" else "port"}" style="width:{W:.0f}px;height:{H:.0f}px">']
    out.append(f'<div class="sheet" style="left:{left:.1f}px;top:{top:.1f}px;width:{tw * k:.1f}px;height:{th * k:.1f}px">')
    xs = [0]
    for w in g.cols:
        xs.append(xs[-1] + w * k)
    ys = [0]
    for h in g.rows:
        ys.append(ys[-1] + h * k)
    # cellules (positionnement absolu : fidele a la grille, debordement du texte autorise)
    occupied = {pos for pos, c in g.cells.items() if c.text} | set(merge_idx)
    for (i, j), c in g.cells.items():
        m = merge_idx.get((i, j))
        if m and (i, j) != (m[0], m[1]):
            continue
        i2, j2 = (m[2], m[3]) if m else (i, j)
        st = c.st
        x, y, w, h = xs[j], ys[i], xs[j2 + 1] - xs[j], ys[i2 + 1] - ys[i]
        styles = [f"left:{x:.1f}px;top:{y:.1f}px;width:{w:.1f}px;height:{h:.1f}px",
                  f"font-size:{st.get('size', 10) * k:.2f}px"]
        if st.get("b"):
            styles.append("font-weight:700")
        if st.get("i"):
            styles.append("font-style:italic")
        if st.get("u"):
            styles.append("text-decoration:underline")
        if st.get("bg"):
            styles.append(f"background:#{st['bg']}")
        ha = st.get("ha") or ("right" if c.num else "left")
        if ha == "general":
            ha = "right" if c.num else "left"
        if ha in ("centerContinuous", "distributed"):
            ha = "center"
        if ha not in ("left", "right", "center"):
            ha = "left"
        va = st.get("va") or "bottom"
        cls = ["c", "h" + ha[0], "v" + ("t" if va == "top" else "m" if va in ("center", "distributed", "justify") else "b")]
        wrap = st.get("wrap") or ("\n" in (c.text or "") and not c.num)
        if wrap:
            cls.append("w")
        elif c.text and not c.num and not m:
            # debordement possible si les voisines sont vides
            if ha == "left":
                kk = j2 + 1
                while kk < len(g.cols) and (i, kk) not in occupied:
                    kk += 1
                styles.append(f"--ow:{xs[kk] - xs[j]:.1f}px")
                cls.append("ov")
        rot = st.get("rot") or 0
        if rot in (90, 255):
            cls.append("r90")
        attrs = ""
        if editable and c.ref:
            ref = f"{c.ref[0]}!{c.ref[1]}"
            attrs = f' data-ref="{html.escape(ref)}"'
            cls.append("e")
            if c.formula:
                cls.append("f")
            if c.forced:
                cls.append("forced")
            raw = c.value
            if raw is not None and not hasattr(raw, "code"):
                attrs += f' data-raw="{html.escape(str(raw))}"'
        text = html.escape(c.text or "").replace("\n", "<br>")
        out.append(f'<div class="{" ".join(cls)}" style="{";".join(styles)}"{attrs}><span>{text}</span></div>')
    # cellules vides modifiables (saisie dans les tableaux)
    # bordures
    for (i, j), style in H_.items():
        if i >= len(ys) or j + 1 >= len(xs):
            continue
        bw = BW.get(style, 1)
        out.append(f'<div class="bh" style="left:{xs[j]:.1f}px;top:{ys[i] - bw / 2:.1f}px;width:{xs[j + 1] - xs[j]:.1f}px;'
                   f'border-top:{bw}px {BS.get(style, "solid")} #000"></div>')
    for (i, j), style in V_.items():
        if i + 1 >= len(ys) or j >= len(xs):
            continue
        bw = BW.get(style, 1)
        out.append(f'<div class="bv" style="left:{xs[j] - bw / 2:.1f}px;top:{ys[i]:.1f}px;height:{ys[i + 1] - ys[i]:.1f}px;'
                   f'border-left:{bw}px {BS.get(style, "solid")} #000"></div>')
    for (x, y, w, h, path) in g.images:
        import os
        name = os.path.basename(path)
        out.append(f'<img class="im" src="static/{name}" style="left:{x * k:.1f}px;top:{y * k:.1f}px;width:{w * k:.1f}px;height:{h * k:.1f}px">')
    for tb in g.textboxes:
        paras = "".join(
            f'<p style="{"font-weight:700;" if p.get("b", tb.get("bold")) else ""}{"font-style:italic;" if p.get("i") else ""}'
            f'font-size:{tb.get("size", 9) * p.get("k", 1) * k:.2f}px;margin:0 0 {p.get("gap", tb.get("gap", 3)) * k:.1f}px 0;'
            f'text-align:{"justify" if p.get("align", tb.get("align")) == "justify" else p.get("align", tb.get("align", "left"))}">'
            f'{html.escape(p["t"])}</p>' for p in tb["paras"])
        border = f"border:{tb['border'] * k:.1f}px solid #000;" if tb.get("border") else ""
        bg = f"background:#{tb['bg']};" if tb.get("bg") else ""
        jc = "display:flex;flex-direction:column;justify-content:center;" if tb.get("valign") == "center" else ""
        out.append(f'<div class="tb" style="left:{tb["x"] * k:.1f}px;top:{tb["y"] * k:.1f}px;width:{tb["w"] * k:.1f}px;'
                   f'height:{tb["h"] * k:.1f}px;padding:{tb.get("pad", 4) * k:.1f}px;{border}{bg}{jc}">{paras}</div>')
    out.append("</div></div>")
    return "".join(out)


def empty_cells_html(g):
    return ""
