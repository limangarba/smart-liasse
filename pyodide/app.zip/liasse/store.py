"""Base locale SQLite : un enregistrement par dossier (societe + exercice)."""
import json
import os
import sqlite3
import datetime
import threading

_LOCK = threading.Lock()


def db_path():
    base = os.environ.get("SMART_LIASSE_DATA") or os.path.join(os.path.expanduser("~"), "SmartLiasse")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "smart_liasse.db")


def connect():
    con = sqlite3.connect(db_path())
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS dossiers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        societe TEXT, annee INTEGER, nom TEXT, data TEXT,
        cree TEXT, modifie TEXT)""")
    return con


def now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")


def list_dossiers():
    with _LOCK, connect() as con:
        rows = con.execute("SELECT id, societe, annee, nom, cree, modifie FROM dossiers ORDER BY societe, annee DESC").fetchall()
        return [dict(r) for r in rows]


def get(did):
    with _LOCK, connect() as con:
        r = con.execute("SELECT * FROM dossiers WHERE id=?", (did,)).fetchone()
        if not r:
            return None
        d = json.loads(r["data"])
        d["id"] = r["id"]
        return d


def save(d):
    d = dict(d)
    did = d.pop("id", None)
    ident = d.get("identite", {})
    societe = ident.get("denomination") or "Nouvelle société"
    annee = (d.get("exercice") or {}).get("annee")
    try:
        annee = int(annee) if annee not in (None, "") else None
    except ValueError:
        annee = None
    nom = f"{societe} – {annee or ''}"
    data = json.dumps(d, ensure_ascii=False, default=str)
    with _LOCK, connect() as con:
        if did:
            con.execute("UPDATE dossiers SET societe=?, annee=?, nom=?, data=?, modifie=? WHERE id=?",
                        (societe, annee, nom, data, now(), did))
        else:
            cur = con.execute("INSERT INTO dossiers (societe, annee, nom, data, cree, modifie) VALUES (?,?,?,?,?,?)",
                              (societe, annee, nom, data, now(), now()))
            did = cur.lastrowid
        con.commit()
    return did


def delete(did):
    with _LOCK, connect() as con:
        con.execute("DELETE FROM dossiers WHERE id=?", (did,))
        con.commit()
