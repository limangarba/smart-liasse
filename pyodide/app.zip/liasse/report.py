"""Ouverture de l'exercice suivant : reprise automatique des donnees N-1 (report a nouveau, deficits,
amortissements reputes differes, TAP deduite, historique sur cinq ans, colonne N-1 du TFT)."""
import copy
import datetime

from .engine import compute
from .immobilisations import to_date


def _shift_year(d):
    d = to_date(d)
    if not d:
        return None
    try:
        return d.replace(year=d.year + 1)
    except ValueError:
        return d + datetime.timedelta(days=365)


def next_year(dossier):
    res = compute(dossier)
    num = res.num
    old = dossier
    new = {
        "identite": copy.deepcopy(old.get("identite") or {}),
        "activites": copy.deepcopy(old.get("activites") or []),
        "mapping": copy.deepcopy(old.get("mapping") or {}),
        "options": copy.deepcopy(old.get("options") or {}),
        "textes": copy.deepcopy(old.get("textes") or {}),
        "tap": copy.deepcopy(old.get("tap") or {}),
        "tcfge": copy.deepcopy(old.get("tcfge") or {}),
        "immobilisations": [],
        "balance_n": [],
        "balance_n1": copy.deepcopy(old.get("balance_n") or []),
        "cells": {},
    }
    # TAP / TCFGE : seuls les reglages (comptes retenus) sont repris ; les montants saisis,
    # l'etat des apprentis et les depenses de formation sont propres a chaque exercice
    tap_old, tc_old = new["tap"], new["tcfge"]
    new["tap"] = {"lignes": {c: {"comptes": l.get("comptes")} for c, l in (tap_old.get("lignes") or {}).items()
                             if isinstance(l, dict) and l.get("comptes") not in (None, "")}}
    if tap_old.get("mode_formation"):
        new["tap"]["mode_formation"] = tap_old["mode_formation"]
    if tap_old.get("comptes_etrangers"):
        new["tap"]["comptes_etrangers"] = tap_old["comptes_etrangers"]
    new["tcfge"] = {"lignes": {c: {"comptes": l.get("comptes")} for c, l in (tc_old.get("lignes") or {}).items()
                               if isinstance(l, dict) and l.get("comptes") not in (None, "")}}
    for a in new["activites"]:
        a.pop("ca", None)
    exo = old.get("exercice") or {}
    fin = to_date(exo.get("fin"))
    annee = int(exo.get("annee") or (fin.year if fin else datetime.date.today().year))
    debut_new = (fin + datetime.timedelta(days=1)) if fin else datetime.date(annee + 1, 1, 1)
    fin_new = _shift_year(fin) if fin else datetime.date(annee + 1, 12, 31)
    new["exercice"] = {"annee": annee + 1, "debut": debut_new.isoformat(), "fin": fin_new.isoformat(),
                       "duree": 12, "prec_fin": fin.isoformat() if fin else "", "prec_duree": exo.get("duree") or 12}
    # immobilisations : on conserve les biens non sortis, avec leurs amortissements cumules
    reg = {l.get("_idx"): l for l in ((res.info.get("immo") or {}).get("lignes") or [])}
    for idx, a in enumerate(old.get("immobilisations") or []):
        if not (a.get("designation") or a.get("valeur")):
            continue
        a2 = copy.deepcopy(a)
        ces = to_date(a.get("date_cession"))
        if ces and fin and ces <= fin:
            continue
        match = reg.get(idx)   # ligne calculee du meme bien (correspondance par position, pas par libelle)
        if match:
            a2["amort_anterieur"] = match["cum_clot"]
        new["immobilisations"].append(a2)

    p_old = old.get("params") or {}
    params = {k: v for k, v in p_old.items() if k in ("taux_imf", "taux_isb", "imf_minimum", "taux_tcfge",
                                                        "tap_reintegrer", "nb_exemplaires", "taux_tap_nat", "taux_tap_etr")}
    # TAP de l'exercice reintegree -> deduite l'exercice suivant ; conges payes idem
    params["tap_n1"] = num("TABLEAU DE PASSAGE", "G26")
    params["conges_n1"] = num("TABLEAU DE PASSAGE", "G27")
    # amortissements reputes differes restant a imputer
    params["ard_anterieurs"] = num("TRAITEMENT DE DEFICITS", "F26")
    # deficits : decalage d'une annee (le deficit N-3 non impute est perdu)
    D = "TRAITEMENT DE DEFICITS"
    years = [p_old.get("deficit_annee_1"), p_old.get("deficit_annee_2"), annee]
    params["deficit_annee_0"], params["deficit_annee_1"], params["deficit_annee_2"] = years
    params["deficit_orig_0"] = num(D, "I13")
    params["deficit_impute_0"] = num(D, "J13") - num(D, "L13")
    params["deficit_orig_1"] = num(D, "I14")
    params["deficit_impute_1"] = num(D, "J14") - num(D, "L14")
    params["deficit_orig_2"] = num(D, "M16")
    params["deficit_impute_2"] = 0
    # excedent de versement de l'exercice clos : credit d'impot imputable sur l'exercice suivant
    credit = num("BORDEREAU", "X59") if isinstance(res.value("BORDEREAU", "X59"), (int, float)) else 0.0
    if credit:
        params["credit_impot"] = round(credit)
    new["params"] = params
    # TFT : colonne N-1 = colonne N de l'exercice clos
    for r in (12, 15, 16, 17, 18, 19, 23, 24, 25, 26, 27, 30, 31, 32, 33, 36, 37, 38):
        new["cells"][f"TFT!I{r}"] = num("TFT", f"H{r}")
    # Note 31 : historique sur cinq exercices (N -> N-1 -> N-2 ...), lignes calculees et saisies
    from .model import get_model
    mdl = get_model()
    for r in range(10, 31):
        for src_col, dst_col in (("C", "D"), ("D", "E"), ("E", "F"), ("F", "G")):
            if ("NOTE 31", f"{dst_col}{r}") in mdl.formulas:
                continue
            v = res.value("NOTE 31", f"{src_col}{r}")
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v:
                new["cells"][f"NOTE 31!{dst_col}{r}"] = v
    # saisies textuelles reprises (dirigeants, domiciliations bancaires, commentaires...)
    for ref, v in (old.get("cells") or {}).items():
        if isinstance(v, str) and v.strip() and not ref.startswith(("TFT!", "NOTE 31!")):
            new["cells"][ref] = v
    return new
